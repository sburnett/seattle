""" 
Author: Justin Cappos
Edited: Alan Loh

Module: A shell for Seattle called seash (pronounced see-SHH).   It's not meant
        to be the perfect shell, but it should be good enough for v0.1

Start date: September 18th, 2008

This is an example experiment manager for Seattle.   It allows a user to 
locate vessels they control and manage those vessels.

The design goals of this version are to be secure, simple, and reliable (in 
that order).   

Note: I've written this assuming that repy <-> python integration is perfect
and transparent (minus the bit of mess that fixes this).   As a result this
code may change significantly in the future.


Editor's Note: A large portion of seash's code has been separated into
different files. The only code remaining is the command loop that handles the 
user's input and the exception handling.

Command functions have been moved to command_callbacks.py. 

Helper functions and functions that operate on a target have been moved to 
seash_helper.py.

The newly implemented command dictionary, input parsing, and command dispatching 
have been moved to seash_dictionary.py.

Certain global variables are now kept track in seash_global_variables.py.

Besides the restructuring, the main change that has been made on seash is 
command input are now parsed according to the command dictionary. In addition,
with a structured database of sorts for commands, it should now be easier to 
implement new functions into seash as long as the correct format is followed in
implementing new commands.
"""


# Let's make sure the version of python is supported
import checkpythonversion
checkpythonversion.ensure_python_version_is_supported()

# Warnings are turned on to display the tab completion warning
import warnings
warnings.simplefilter("default")

# simple client.   A better test client (but nothing like what a real client
# would be)

### Integration fix here...
from repyportability import *


tabcompletion = True
try:
  # Even we can import the readline module successfully, we still disable tab
  # completion in Windows, in response to Ticket #891.
  import os
  if os.name == 'nt':
    raise ImportError

  # Required for the tab completer. It works on Linux and Mac. It does not work
  # on Windows. See http://docs.python.org/library/readline.html for details. 
  import readline
  import tab_completer
except ImportError:
  tabcompletion = False
  

# Needed for parsing user commands and executing command functions
import seash_dictionary

# To be able to catch certain exceptions thrown throughout the program
import seash_exceptions

import seash_helper

import repyhelper

repyhelper.translate_and_import("time.repy")

import traceback

import os.path    # fix path names when doing upload, loadkeys, etc.

import sys



def command_loop(test_command_list):
  
  # If a test command list is passed, filter the tab completion warning
  if test_command_list:
    warnings.filterwarnings("ignore", "Auto tab completion is off, because it is not available on your operating system.",
                            ImportWarning)


  # Things that may be set herein and used in later commands.
  # Contains the local variables of the original command loop.
  # Keeps track of the user's state in seash. Referenced 
  # during command executions by the command_parser.
  environment_dict = {
    'host': None, 
    'port': None, 
    'expnum': None,
    'filename': None,
    'cmdargs': None,
    'defaulttarget': None,
    'defaultkeyname': None,
    'currenttarget': None,
    'currentkeyname': None,
    'autosave': False,
    'handleinfo': {}
    }

  

  # Set up the tab completion environment (Added by Danny Y. Huang)
  if tabcompletion:
    # Initializes seash's tab completer
    completer = tab_completer.Completer()
    readline.parse_and_bind("tab: complete")
    # Determines when a new tab complete instance should be initialized,
    # which, in this case, is never, so the tab completer will always take
    # the entire user's string into account
    readline.set_completer_delims("")
    # Sets the completer function that readline will utilize
    readline.set_completer(completer.complete)
  else:
    warnings.warn("Auto tab completion is off, because it is not available on your operating system.",ImportWarning)


  # If passed a list of commands, do not prompt for user input
  if test_command_list:
    time_updatetime(34612)
    # Iterates through test_command_list in sequential order
    for command_strings in test_command_list:
      # Saving state after each command? (Added by Danny Y. Huang)
      if environment_dict['autosave'] and environment_dict['defaultkeyname']:
        try:
          # State is saved in file "autosave_username", so that user knows which
          # RSA private key to use to reload the state.
          autosavefn = "autosave_" + str(environment_dict['defaultkeyname'])
          seash_helper.savestate(autosavefn, environment_dict['handleinfo'], environment_dict['host'], 
                                 environment_dict['port'], environment_dict['expnum'], 
                                 environment_dict['filename'], environment_dict['cmdargs'], 
                                 environment_dict['defaulttarget'], environment_dict['defaultkeyname'], 
                                 environment_dict['autosave'], environment_dict['defaultkeyname'])
        except Exception, error:
          raise seash_exceptions.UserError("There is an error in autosave: '" + str(error) + "'. You can turn off autosave using the command 'set autosave off'.")

      # Returns the dictionary of dictionaries that correspond to the
      # command string
      cmd_input = seash_dictionary.parse_command(command_strings)
      
      # by default, use the target specified in the prompt
      environment_dict['currenttarget'] = environment_dict['defaulttarget']
      
      # by default, use the identity specified in the prompt
      environment_dict['currentkeyname'] = environment_dict['defaultkeyname']

      # calls the command_dispatch method of seash_dictionary to execute the callback
      # method associated with the command the user inputed
      seash_dictionary.command_dispatch(cmd_input, environment_dict)



  # Otherwise launch into command loop, exit via return
  else:
    while True:
      try:
        if tabcompletion:
          # Updates the list of variable values in the tab complete class
          completer.set_target_list()
          completer.set_keyname_list()
          
        # Saving state after each command? (Added by Danny Y. Huang)
        if environment_dict['autosave'] and environment_dict['defaultkeyname']:
          try:
            # State is saved in file "autosave_username", so that user knows which
            # RSA private key to use to reload the state.
            autosavefn = "autosave_" + str(environment_dict['defaultkeyname'])
            seash_helper.savestate(autosavefn, environment_dict['handleinfo'], environment_dict['host'], 
                                   environment_dict['port'], environment_dict['expnum'], 
                                   environment_dict['filename'], environment_dict['cmdargs'], 
                                   environment_dict['defaulttarget'], environment_dict['defaultkeyname'], 
                                   environment_dict['autosave'], environment_dict['defaultkeyname'])
          except Exception, error:
            raise seash_exceptions.UserError("There is an error in autosave: '" + str(error) + "'. You can turn off autosave using the command 'set autosave off'.")


        prompt = ''
        if environment_dict['defaultkeyname']:
          prompt = seash_helper.fit_string(environment_dict['defaultkeyname'],20)+"@"

        # display the thing they are acting on in their prompt (if applicable)
        if environment_dict['defaulttarget']:
          prompt = prompt + seash_helper.fit_string(environment_dict['defaulttarget'],20)

        prompt = prompt + " !> "
        # the prompt should look like: justin@good !> 
        
        # get the user input
        userinput = raw_input(prompt)
        
        if len(userinput)==0:
          continue
      
        # Returns the dictionary of dictionaries that correspond to the
        # command the user inputted
        cmd_input = seash_dictionary.parse_command(userinput)
      
      
        # by default, use the target specified in the prompt
        environment_dict['currenttarget'] = environment_dict['defaulttarget']
        
        # by default, use the identity specified in the prompt
        environment_dict['currentkeyname'] = environment_dict['defaultkeyname']

        # calls the command_dispatch method of seash_dictionary to execute the callback
        # method associated with the command the user inputed
        seash_dictionary.command_dispatch(cmd_input, environment_dict)


 

# handle errors
      except KeyboardInterrupt:
        # print or else their prompt will be indented
        print
        # Make sure the user understands why we exited
        print 'Exiting due to user interrupt'
        return
      except EOFError:
        # print or else their prompt will be indented
        print
        # Make sure the user understands why we exited
        print 'Exiting due to EOF (end-of-file) keystroke'
        return

      except seash_exceptions.ParseError, error_detail:
        print 'Invalid command input:', error_detail
      except seash_exceptions.DispatchError, error_detail:
        print error_detail
      except seash_exceptions.UserError, error_detail: 
        print error_detail
      except SystemExit:
        # exits command loop
        return
      except:
        traceback.print_exc()
      
  
  
if __name__=='__main__':
  time_updatetime(34612)
  # For general usage, empty list is passed to prompt for user input
  command_loop([])
