print "foo"
