fo = open("foo.out","w")
fo.write("foooooooo")
fo.close()
