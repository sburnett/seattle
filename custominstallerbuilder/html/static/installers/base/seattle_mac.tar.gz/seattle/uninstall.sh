#!/bin/sh

cd "`echo $0 | sed 's/uninstall.sh/seattle_repy/'`"
./uninstall.sh $*