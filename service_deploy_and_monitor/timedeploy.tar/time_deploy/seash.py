""" 
Author: Justin Cappos

Module: A shell for Seattle called seash (pronounced see-SHH).   It's not meant
        to be the perfect shell, but it should be good enough for v0.1

Start date: September 18th, 2008

This is an example experiment manager for Seattle.   It allows a user to 
locate vessels they control and manage those vessels.

The design goals of this version are to be secure, simple, and reliable (in 
that order).   

Note: I've written this assuming that repy <-> python integration is perfect
and transparent (minus the bit of mess that fixes this).   As a result this
code may change significantly in the future.

This module is a mess.   The big problem is that we have ~ 30 lines of input
parsing for everything the user does followed by ~ 5 lines of code.   I'm not
sure how to fix this or structure this module to make it cleaner...
"""


# Let's make sure the version of python is supported
import checkpythonversion
checkpythonversion.ensure_python_version_is_supported()

# Armon: Prevent all warnings
import warnings
# Ignores all warnings
warnings.simplefilter("ignore")

# simple client.   A better test client (but nothing like what a real client
# would be)

### Integration fix here...
from repyportability import *

try:
  # Add smarter history / command substitution if possible
  import readline
except ImportError:
  pass


#begin include nmclient.repy
""" 
Author: Justin Cappos

Module: Routines that interact with a node manager to perform actions on
        nodes.   A simple front end can be added to make this a functional
        experiment manager.

Start date: September 7th 2008

The design goals of this version are to be secure, simple, and reliable (in 
that order).   

"""

# for signing the data we send to the node manager
#begin include signeddata.repy
""" Justin Cappos -- routines that create and verify signatures and prevent
replay / freeze / out of sequence / misdelivery attacks

Replay attack:   When someone provides information you signed before to try
to get you to perform an old action again.   For example, A sends messages to
the node manager to provide a vessel to B (B intercepts this traffic).   Later 
A acquires the vessel again.   B should not be able to replay the messages A 
sent to the node manager to have the vessel transferred to B again.

Freeze attack:   When an attacker can act as a man-in-the-middle and provide
stale information to an attacker.   For example, B can intercept all traffic
between the node manager and A.   If C makes a change on the node manager, then
B should not be able to prevent A from seeing the change (at least within 
some time bound).

Out of sequence attack:   When someone can skip sending some messages but
deliver others.   For example, A wants to stop the current program, upload
a new copy of the program, and start the program again.   It should be possible
for A to specify that these actions must be performed in order and without 
skipping any of the prior actions (regardless of failures, etc.).

Misdelivery attack:   Messages should only be acted upon by the nodes that 
the user intended.   A malicious party should not be able to "misdeliver" a
message and have a different node perform the action.



I have support for "sequence numbers" which will require that intermediate 
events are not skipped.    The sequence numbers are a tuple: (tag, version)

"""


#begin include sha.repy
#!/usr/bin/env python
# -*- coding: iso-8859-1

"""A sample implementation of SHA-1 in pure Python.

   Adapted by Justin Cappos from the version at: http://codespeak.net/pypy/dist/pypy/lib/sha.py

   Framework adapted from Dinu Gherman's MD5 implementation by
   J. Hall`en and L. Creighton. SHA-1 implementation based directly on
   the text of the NIST standard FIPS PUB 180-1.

date    = '2004-11-17'
version = 0.91 # Modernised by J. Hall`en and L. Creighton for Pypy
"""



# ======================================================================
# Bit-Manipulation helpers
#
#   _long2bytes() was contributed by Barry Warsaw
#   and is reused here with tiny modifications.
# ======================================================================

def _sha_long2bytesBigEndian(n, thisblocksize=0):
    """Convert a long integer to a byte string.

    If optional blocksize is given and greater than zero, pad the front
    of the byte string with binary zeros so that the length is a multiple
    of blocksize.
    """

    # Justin: I changed this to avoid using pack. I didn't test performance, etc
    s = ''
    while n > 0:
        #original: 
        # s = struct.pack('>I', n & 0xffffffffL) + s
        # n = n >> 32
        s = chr(n & 0xff) + s
        n = n >> 8

    # Strip off leading zeros.
    for i in range(len(s)):
        if s[i] <> '\000':
            break
    else:
        # Only happens when n == 0.
        s = '\000'
        i = 0

    s = s[i:]

    # Add back some pad bytes. This could be done more efficiently
    # w.r.t. the de-padding being done above, but sigh...
    if thisblocksize > 0 and len(s) % thisblocksize:
        s = (thisblocksize - len(s) % thisblocksize) * '\000' + s

    return s


def _sha_bytelist2longBigEndian(list):
    "Transform a list of characters into a list of longs."

    imax = len(list)/4
    hl = [0L] * imax

    j = 0
    i = 0
    while i < imax:
        b0 = long(ord(list[j])) << 24
        b1 = long(ord(list[j+1])) << 16
        b2 = long(ord(list[j+2])) << 8
        b3 = long(ord(list[j+3]))
        hl[i] = b0 | b1 | b2 | b3
        i = i+1
        j = j+4

    return hl


def _sha_rotateLeft(x, n):
    "Rotate x (32 bit) left n bits circularly."

    return (x << n) | (x >> (32-n))


# ======================================================================
# The SHA transformation functions
#
# ======================================================================

# Constants to be used
sha_K = [
    0x5A827999L, # ( 0 <= t <= 19)
    0x6ED9EBA1L, # (20 <= t <= 39)
    0x8F1BBCDCL, # (40 <= t <= 59)
    0xCA62C1D6L  # (60 <= t <= 79)
    ]

class sha:
    "An implementation of the MD5 hash function in pure Python."

    def __init__(self):
        "Initialisation."
        
        # Initial message length in bits(!).
        self.length = 0L
        self.count = [0, 0]

        # Initial empty message as a sequence of bytes (8 bit characters).
        self.inputdata = []

        # Call a separate init function, that can be used repeatedly
        # to start from scratch on the same object.
        self.init()


    def init(self):
        "Initialize the message-digest and set all fields to zero."

        self.length = 0L
        self.inputdata = []

        # Initial 160 bit message digest (5 times 32 bit).
        self.H0 = 0x67452301L
        self.H1 = 0xEFCDAB89L
        self.H2 = 0x98BADCFEL
        self.H3 = 0x10325476L
        self.H4 = 0xC3D2E1F0L

    def _transform(self, W):

        for t in range(16, 80):
            W.append(_sha_rotateLeft(
                W[t-3] ^ W[t-8] ^ W[t-14] ^ W[t-16], 1) & 0xffffffffL)

        A = self.H0
        B = self.H1
        C = self.H2
        D = self.H3
        E = self.H4

        """
        This loop was unrolled to gain about 10% in speed
        for t in range(0, 80):
            TEMP = _sha_rotateLeft(A, 5) + sha_f[t/20] + E + W[t] + sha_K[t/20]
            E = D
            D = C
            C = _sha_rotateLeft(B, 30) & 0xffffffffL
            B = A
            A = TEMP & 0xffffffffL
        """

        for t in range(0, 20):
            TEMP = _sha_rotateLeft(A, 5) + ((B & C) | ((~ B) & D)) + E + W[t] + sha_K[0]
            E = D
            D = C
            C = _sha_rotateLeft(B, 30) & 0xffffffffL
            B = A
            A = TEMP & 0xffffffffL

        for t in range(20, 40):
            TEMP = _sha_rotateLeft(A, 5) + (B ^ C ^ D) + E + W[t] + sha_K[1]
            E = D
            D = C
            C = _sha_rotateLeft(B, 30) & 0xffffffffL
            B = A
            A = TEMP & 0xffffffffL

        for t in range(40, 60):
            TEMP = _sha_rotateLeft(A, 5) + ((B & C) | (B & D) | (C & D)) + E + W[t] + sha_K[2]
            E = D
            D = C
            C = _sha_rotateLeft(B, 30) & 0xffffffffL
            B = A
            A = TEMP & 0xffffffffL

        for t in range(60, 80):
            TEMP = _sha_rotateLeft(A, 5) + (B ^ C ^ D)  + E + W[t] + sha_K[3]
            E = D
            D = C
            C = _sha_rotateLeft(B, 30) & 0xffffffffL
            B = A
            A = TEMP & 0xffffffffL


        self.H0 = (self.H0 + A) & 0xffffffffL
        self.H1 = (self.H1 + B) & 0xffffffffL
        self.H2 = (self.H2 + C) & 0xffffffffL
        self.H3 = (self.H3 + D) & 0xffffffffL
        self.H4 = (self.H4 + E) & 0xffffffffL
    

    # Down from here all methods follow the Python Standard Library
    # API of the sha module.

    def update(self, inBuf):
        """Add to the current message.

        Update the md5 object with the string arg. Repeated calls
        are equivalent to a single call with the concatenation of all
        the arguments, i.e. m.update(a); m.update(b) is equivalent
        to m.update(a+b).

        The hash is immediately calculated for all full blocks. The final
        calculation is made in digest(). It will calculate 1-2 blocks,
        depending on how much padding we have to add. This allows us to
        keep an intermediate value for the hash, so that we only need to
        make minimal recalculation if we call update() to add more data
        to the hashed string.
        """

        leninBuf = long(len(inBuf))

        # Compute number of bytes mod 64.
        index = (self.count[1] >> 3) & 0x3FL

        # Update number of bits.
        self.count[1] = self.count[1] + (leninBuf << 3)
        if self.count[1] < (leninBuf << 3):
            self.count[0] = self.count[0] + 1
        self.count[0] = self.count[0] + (leninBuf >> 29)

        partLen = 64 - index

        if leninBuf >= partLen:
            self.inputdata[index:] = list(inBuf[:partLen])
            self._transform(_sha_bytelist2longBigEndian(self.inputdata))
            i = partLen
            while i + 63 < leninBuf:
                self._transform(_sha_bytelist2longBigEndian(list(inBuf[i:i+64])))
                i = i + 64
            else:
                self.inputdata = list(inBuf[i:leninBuf])
        else:
            i = 0
            self.inputdata = self.inputdata + list(inBuf)


    def digest(self):
        """Terminate the message-digest computation and return digest.

        Return the digest of the strings passed to the update()
        method so far. This is a 16-byte string which may contain
        non-ASCII characters, including null bytes.
        """

        H0 = self.H0
        H1 = self.H1
        H2 = self.H2
        H3 = self.H3
        H4 = self.H4
        inputdata = [] + self.inputdata
        count = [] + self.count

        index = (self.count[1] >> 3) & 0x3fL

        if index < 56:
            padLen = 56 - index
        else:
            padLen = 120 - index

        padding = ['\200'] + ['\000'] * 63
        self.update(padding[:padLen])

        # Append length (before padding).
        bits = _sha_bytelist2longBigEndian(self.inputdata[:56]) + count

        self._transform(bits)

        # Store state in digest.
        digest = _sha_long2bytesBigEndian(self.H0, 4) + \
                 _sha_long2bytesBigEndian(self.H1, 4) + \
                 _sha_long2bytesBigEndian(self.H2, 4) + \
                 _sha_long2bytesBigEndian(self.H3, 4) + \
                 _sha_long2bytesBigEndian(self.H4, 4)

        self.H0 = H0 
        self.H1 = H1 
        self.H2 = H2
        self.H3 = H3
        self.H4 = H4
        self.inputdata = inputdata 
        self.count = count 

        return digest


    def hexdigest(self):
        """Terminate and return digest in HEX form.

        Like digest() except the digest is returned as a string of
        length 32, containing only hexadecimal digits. This may be
        used to exchange the value safely in email or other non-
        binary environments.
        """
        return ''.join(['%02x' % ord(c) for c in self.digest()])

    def copy(self):
        """Return a clone object. (not implemented)

        Return a copy ('clone') of the md5 object. This can be used
        to efficiently compute the digests of strings that share
        a common initial substring.
        """
        raise Exception, "not implemented"


# ======================================================================
# Mimic Python top-level functions from standard library API
# for consistency with the md5 module of the standard library.
# ======================================================================

# These are mandatory variables in the module. They have constant values
# in the SHA standard.

sha_digest_size = sha_digestsize = 20
sha_blocksize = 1

def sha_new(arg=None):
    """Return a new sha crypto object.

    If arg is present, the method call update(arg) is made.
    """

    crypto = sha()
    if arg:
        crypto.update(arg)

    return crypto


# gives the hash of a string
def sha_hash(string):
    crypto = sha()
    crypto.update(string)
    return crypto.digest()


# gives the hash of a string
def sha_hexhash(string):
    crypto = sha()
    crypto.update(string)
    return crypto.hexdigest()

#end include sha.repy
#begin include rsa.repy
"""
<Program Name>
  random.repy

<Started>
  2008-04-23

<Author>
  Modified by Anthony Honstain from the following code:
    PyCrypto which is authored by Dwayne C. Litzenberger
    
    Seattle's origional rsa.repy which is Authored by:
      Adapted by Justin Cappos from the version by:
        author = "Sybren Stuvel, Marloes de Boer and Ivo Tamboer"

<Purpose>
  This is the main interface for using the ported RSA implementation.
    
<Notes on port>
  The random function can not be defined with the initial construction of
  the RSAImplementation object, it is hard coded into number_* functions.
    
"""

#begin include random.repy
""" 
<Program Name>
  random.repy

<Author>
  Justin Cappos: random_sample

  Modified by Anthony Honstain
    random_nbit_int and random_long_to_bytes is modified from 
    Python Cryptography Toolkit and was part of pycrypto which 
    is maintained by Dwayne C. Litzenberger
    
    random_range, random_randint, and random_int_below are modified 
    from the Python 2.6.1 random.py module. Which was:
    Translated by Guido van Rossum from C source provided by
    Adrian Baddeley.  Adapted by Raymond Hettinger for use with
    the Mersenne Twister  and os.urandom() core generators.  

<Purpose>
  Random routines (similar to random module in Python)
  
  
<Updates needed when emulmisc.py adds randombytes function>
  TODO-
    random_nbit_int currently uses random_randombytes as a source 
    of random bytes, this is not a permanent fix (the extraction 
    of random bytes from the float is not portable). The change will
    likely be made to random_randombytes (since calls os.urandom will
    likely be restricted to a limited number of bytes).  
  TODO - 
    random_randombytes will remained but serve as a helper function
    to collect the required number of bytes. Calls to randombytes
    will be restricted to a set number of bytes at a time, since
    allowing an arbitrary request to os.urandom would circumvent 
    performance restrictions. 
  TODO - 
    _random_long_to_bytes will no longer be needed.  
      
"""

#begin include math.repy
""" Justin Cappos -- substitute for a few python math routines"""

def math_ceil(x):
  xint = int(x)
  
  # if x is positive and not equal to itself truncated then we should add 1
  if x > 0 and x != xint:
    xint = xint + 1

  # I return a float because math.ceil does
  return float(xint)



def math_floor(x):
  xint = int(x)
  
  # if x is negative and not equal to itself truncated then we should subtract 1
  if x < 0 and x != xint:
    xint = xint - 1

  # I return a float because math.ceil does
  return float(xint)



math_e = 2.7182818284590451
math_pi = 3.1415926535897931

# stolen from a link off of wikipedia (http://en.literateprograms.org/Logarithm_Function_(Python)#chunk use:logN.py)
# MIT license
#
# hmm, math_log(4.5,4)      == 1.0849625007211561
# Python's math.log(4.5,4)  == 1.0849625007211563
# I'll assume this is okay.
def math_log(X, base=math_e, epsilon=1e-16):
  # log is logarithm function with the default base of e
  integer = 0
  if X < 1 and base < 1:
    # BUG: the cmath implementation can handle smaller numbers...
    raise ValueError, "math domain error"
  while X < 1:
    integer -= 1
    X *= base
  while X >= base:
    integer += 1
    X /= base
  partial = 0.5               # partial = 1/2 
  X *= X                      # We perform a squaring
  decimal = 0.0
  while partial > epsilon:
    if X >= base:             # If X >= base then a_k is 1 
      decimal += partial      # Insert partial to the front of the list
      X = X / base            # Since a_k is 1, we divide the number by the base
    partial *= 0.5            # partial = partial / 2
    X *= X                    # We perform the squaring again
  return (integer + decimal)


#end include math.repy

def random_randombytes(num_bytes, random_float=None):
  """
   <Purpose>
     Return a string of length num_bytes, made of random bytes 
     suitable for cryptographic use (because randomfloat draws
     from a os provided random source).
      
     *WARNING* If python implements float as a C single precision
     floating point number instead of a double precision then
     there will not be 53 bits of data in the coefficient.

   <Arguments>
     num_bytes:
               The number of bytes to request from os.urandom. 
               Must be a positive integer value.
     random_float:
                  Should not be used, available only for testing
                  so that predetermined floats can be provided.
    
   <Exceptions>
     None

   <Side Effects>
     This function results in one or more calls to randomfloat 
     which uses a OS source of random data which is metered.

   <Returns>
     A string of num_bytes random bytes suitable for cryptographic use.
  """
  # To ensure accurate testing, this allows the source
  # of random floats to be supplied.
  if random_float is None: 
    random_float = randomfloat()
  
  randombytes = ''
  
  # num_bytes/6 + 1 is used because at most a single float
  # can only result in 6 bytes of random data. So an additional
  # 6 bytes is added and them trimmed to the desired size.
  for byte in range(num_bytes/6 + 1):
    
    # Convert the float back to a integer by multiplying
    # it by 2**53, 53 is used because the expected precision
    # of a python float will be a C type double with a 53 bit 
    # coefficient, this will still depend on the implementation
    # but the standard is to expect 53 bits.
    randomint = int(random_float * (2**53)) 
    # 53 bits trimmed down to 48bits
    # and 48bits is equal to 6 bytes
    randomint = randomint >> 5  
    
    # Transform the randomint into a byte string, 6 bytes were
    # used to create this integer, but several of the leading 
    # bytes could have been trimmed off in the process.
    sixbytes = _random_long_to_bytes(randomint)
    
    # Add on the zeroes that should be there.
    if len(sixbytes) < 6: 
      # pad additions binary zeroes that were lost during 
      # the floats creation.
      sixbytes = '\x00'*(6-len(sixbytes)) + sixbytes 
    randombytes += sixbytes
  
  return randombytes[6 - num_bytes % 6:]
  
  
  
def _random_long_to_bytes(long_int):
  """
  <Purpose>
    Convert a long integer to a byte string.   
    Used by random_randombytes to convert integers recovered
    from random floats into its byte representation.
    Used by random_randombytes, random_randombytes is responsible
    for padding any required binary zeroes that are lost in the
    conversion process.     
  """

  long_int = long(long_int)
  byte_string = ''
  temp_int = 0
  
  # Special case to ensure that a non-empty string
  # is always returned.
  if long_int == 0:
    return '\000'
  
  while long_int > 0:
    # Use a bitwise AND to get the last 8 bits from the long.
    #    long_int  -->   1010... 010000001 (base 2)
    #    0xFF      -->            11111111
    #              _______________________
    #  Bitwise AND result -->     10000001
    tmp_int = long_int & 0xFF
    # Place the new character at the front of the string.
    byte_string = "%s%s" % (chr(tmp_int), byte_string)
    # Bitshift the long because the trailing 8 bits have just been read.
    long_int = long_int >> 8
      
  return byte_string



def random_nbit_int(num_bits):  
  """
  <Purpose>
    Returns an random integer that was constructed with
    num_bits many random bits. The result will be an
    integer [0, 2**(num_bits) - 1] inclusive.
     
    For Example:
     If a 10bit number is needed, random_nbit_int(10).
     Min should be greater or equal to 0
     Max should be less than or equal to 1023

    TODO-
      This function currently uses random_randombytes as a source 
      of random bytes, this is not a permanent fix (the extraction 
      of random bytes from the float is not portable). The change will
      likely be made to random_randombytes (since calls os.urandom will
      likely be restricted to a limited number of bytes).

  <Arguments>
    num_bits:
             The number of random bits to be used for construction
             of the random integer to be returned.

  <Exceptions>
    TypeError if non-integer values for num_bits.
      Will accept floats of the type 1.0, 2.0, ...
    
    ValueError if the num_bits is negative or 0.

  <Side Effects>
    This function results in one or more calls to randomfloat 
    which uses a OS source of random data which is metered.

  <Returns>
    Returns a random integer between [0, 2**(num_bits) - 1] inclusive.
  
  <Walkthrough of functions operation>
    This will be a step by step walk through of the key operations
    defined in this function, with the largest possible
    10 bit integer returned.
    
    num_bits = 10
    
    randstring = random_randombytes(10/8)  for our example we
    will suppose that the byte returned was '\xff' (which is the
    same as chr(255)).
    
    odd_bits = 10 % 8 = 2
    Once again we assume that random_randombytes(1) returns the
    maximum possible, which is '\xff'  
    chr = ord('\xff') >> (8 - odd_bits)
    -> chr = 255 >> (8 - 2)
    -> chr = 255 >> 6 = 3   Note 3 is the largest 2 bit number
    chr(3) is appended to randstring resulting in
    randstring = '\x03\xff' 
    
    value = 0
    length = 2
    
    STEP 1 (i = 0):
      value = value << 8 
      -> value = 0
      value = value + ord(randstring[0])
      -> value = 3
    
    STEP 2 (i = 1):
      value = value << 8
      -> value = 768
      value = value + ord(randstring[1])
      -> value = 1023
    
    return 1023
    This is the maximum possible 10 bit integer.
  """
  if num_bits <= 0:
    raise ValueError('number of bits must be greater than zero')
  if num_bits != int(num_bits):
    raise TypeError('number of bits should be an integer')
  
  # The number of bits requested may not be a multiple of
  # 8, then an additional byte will trimmed down.
  randstring = random_randombytes(num_bits/8)

  odd_bits = num_bits % 8
  # A single random byte be converted to an integer (which will
  # be an element of [0,255]) it will then be shifted to the required
  # number of bits.
  # Example: if odd_bits = 3, then the 8 bit retrieved from the 
  # single byte will be shifted right by 5.
  if odd_bits != 0:
    char = ord(random_randombytes(1)) >> (8 - odd_bits)
    randstring = chr(char) + randstring
  
  # the random bytes in randstring will be read from left to right
  result = 0L
  length = len(randstring)
  for i in range(0, length):
    # While result = 0, the bitshift left will still result in 0
    # Since we are dealing with integers, this does not result
    # in the loss of any information.
    result = (result << 8) 
    result = result + ord(randstring[i]) 
  
  assert(result < (2 ** num_bits))
  assert(result >= 0)

  return result



def random_int_below(upper_bound):
  """
  <Purpose>
    Returns an random integer in the range [0,upper_bound)
    
    Handles the case where upper_bound has more bits than returned
    by a single call to the underlying generator.
     
    For Example:
     For a 10bit number, random_int_below(10).
     results would be an element in of the set 0,1,2,..,9.
     
    NOTE: This function is a port from the random.py file in 
    python 2.6.2. For large numbers I have experienced inconsistencies
    when using a naive logarithm function to determine the
    size of a number in bits.  

  <Arguments>
    upper_bound:
           The random integer returned will be in [0, upper_bound).
           Results will be integers less than this argument.

  <Exceptions>
    TypeError if non-integer values for upper_bound.
    ValueError if the upper_bound is negative or 0.

  <Side Effects>
    This function results in one or more calls to randomfloat 
    which uses a OS source of random data which is metered.

  <Returns>
    Returns a random integer between [0, upper_bound).
  
  """
  if upper_bound <= 0:
    raise ValueError('number must be greater than zero')
  if upper_bound != int(upper_bound):
    raise TypeError('number should be an integer')
  
  k = int(1.00001 + math_log(upper_bound - 1, 2.0))   # 2**k > n-1 > 2**(k-2)
  r = random_nbit_int(k)
  while r >= upper_bound:
    r = random_nbit_int(k)
  return r

 

def random_randrange(start, stop=None, step=1):
  """
  <Purpose>
    Choose a random item from range(start, stop[, step]).
    
  <Arguments>
    start:
      The random integer returned will be greater than
      or equal to start. 
  
    stop:
      The random integer returned will be less than stop.
      Results will be integers less than this argument.

    step:
      Determines which elements from the range will be considered.
     
  <Exceptions>
    ValueError:
      Non-integer for start or stop argument
      Empty range, if start < 0 and stop is None
      Empty range
      Zero or non-integer step for range

  <Side Effects>
    This function results in one or more calls to randomfloat 
    which uses a OS source of randomdata which is metered.
  
  <Returns>
    Random item from (start, stop[, step]) 'exclusive'
    
  <Notes on port>
    This fixes the problem with randint() which includes the
    endpoint; in Python this is usually not what you want.
    
    Anthony -I removed these since they do not apply
      int=int, default=None, maxwidth=1L<<BPF
      Do not supply the 'int', 'default', and 'maxwidth' arguments.
  """
  maxwidth = 1L<<53

  # This code is a bit messy to make it fast for the
  # common case while still doing adequate error checking.
  istart = int(start)
  if istart != start:
    raise ValueError, "non-integer arg 1 for randrange()"
  if stop is None:
    if istart > 0:
      if istart >= maxwidth:
        return random_int_below(istart)
      return int(randomfloat() * istart)
    raise ValueError, "empty range for randrange()"

  # stop argument supplied.
  istop = int(stop)
  if istop != stop:
    raise ValueError, "non-integer stop for randrange()"
  width = istop - istart
  if step == 1 and width > 0:
    # Note that
    #     int(istart + self.random()*width)
    # instead would be incorrect.  For example, consider istart
    # = -2 and istop = 0.  Then the guts would be in
    # -2.0 to 0.0 exclusive on both ends (ignoring that random()
    # might return 0.0), and because int() truncates toward 0, the
    # final result would be -1 or 0 (instead of -2 or -1).
    #     istart + int(self.random()*width)
    # would also be incorrect, for a subtler reason:  the RHS
    # can return a long, and then randrange() would also return
    # a long, but we're supposed to return an int (for backward
    # compatibility).

    if width >= maxwidth:
      return int(istart + random_int_below(width))
    return int(istart + int(randomfloat()*width))
  if step == 1:
    raise ValueError, "empty range for randrange() (%d,%d, %d)" % (istart, istop, width)

  # Non-unit step argument supplied.
  istep = int(step)
  if istep != step:
    raise ValueError, "non-integer step for randrange()"
  if istep > 0:
    n = (width + istep - 1) // istep
  elif istep < 0:
    n = (width + istep + 1) // istep
  else:
    raise ValueError, "zero step for randrange()"

  if n <= 0:
    raise ValueError, "empty range for randrange()"

  if n >= maxwidth:
    return istart + istep*random_int_below(n)
  return istart + istep*int(randomfloat() * n)



def random_randint(lower_bound, upper_bound):
  """
  <Purpose>
    Return random integer in range [lower_bound, upper_bound], 
    including both end points.
    
  <Arguments>
    upper_bound:
      The random integer returned will be less than upper_bound.
    lower_bound:
      The random integer returned will be greater than
      or equal to the lower_bound.

  <Exceptions>
    None

  <Side Effects>
    This function results in one or more calls to randomfloat 
    which uses a OS source of randomdata which is metered.
  
  <Returns>
    Random integer from [lower_bound, upper_bound] 'inclusive'  
  """
  return random_randrange(lower_bound, upper_bound+1)



def random_sample(population, k):
  """
  <Purpose>
    To return a list containing a random sample from the population.
    
  <Arguments>
    population:
               The elements to be sampled from.
    k: 
      The number of elements to sample
      
  <Exceptions>
    ValueError is sampler larger than population.
    
  <Side Effects>
    This function results in one or more calls to randomfloat 
    which uses a OS source of randomdata which is metered.
    
  <Returns>
    A list of len(k) with random elements from the population.
    
  """
  
  newpopulation = population[:]
  if len(population) < k:
    raise ValueError, "sample larger than population"

  retlist = []
  populationsize = len(population)-1

  for num in range(k):
    pos = random_randint(0,populationsize-num)
    retlist.append(newpopulation[pos])
    del newpopulation[pos]

  return retlist

#end include random.repy
#begin include pycryptorsa.repy
"""
<Program Name>
  pycrypto.repy

<Started>
  2009-01

<Author>
  Modified by Anthony Honstain from the following code:
    PyCrypto which is authored by Dwayne C. Litzenberger
    
<Purpose>
  This file provides the encryption functionality for rsa.repy.
  This code has been left as close to origional as possible with
  the notes about changes made to enable for easier modification
  if pycrypto is updated. 
  
  It contains:
    pubkey.py
    RSA.py 
    _RSA.py
    _slowmath.py
    number.py

"""

#
#   pubkey.py : Internal functions for public key operations
#
#  Part of the Python Cryptography Toolkit
#
# Distribute and use freely; there are no restrictions on further
# dissemination and usage except those imposed by the laws of your
# country of residence.  This software is provided "as is" without
# warranty of fitness for use or suitability for any purpose, express
# or implied. Use at your own risk or not at all.
#

"""
<Modified>
  Anthony
  
  Apr 7:
    Modified behavior of _verify to maintain backwards compatibility.
  Apr 18:
    Adjusted sign to return a long instead of bytes.
    Adjusted verify to accept a long instead of bytes.
  Apr 27:
    Modified encrypt to return a long.
    Modified decrypt to accept a long as its cipher text argument.
    Large change, dropped out behavior for taking tuples, since
    it will never be used in this way for RSA, pubkey has that 
    behavior because of DSA and ElGamal.
    
  NEW ARGUEMENT TYPE AND RETURN TYPE OF
  ENCRYPT DECRYPT SIGN and VERIFY:
  
           Argument Type        Return Type
  --------------------------------------------
  encrypt  |  byte                (long,)
  decrypt  |  long                byte
  sign     |  byte                (long,)
  verify   |  long                byte  

"""

# Anthony stage1
#__revision__ = "$Id$"

# Anthony stage 2, allusage of types.StringType or types.TupleType
# were replaced with type("") and type((1,1))
#import types

# Anthony stage 2, removed the warning completely
#import warnings

# Anthony stage1
#from number import *
#import number  #stage 2

#JAC: Need to include random.repy because random_nbit_int() is used...
#begin include random.repy
#already included random.repy
#end include random.repy

# Basic public key class
class pubkey_pubkey:
    def __init__(self):
        pass

    # Anthony - removed because we are not using pickle
    #def __getstate__(self):
    #    """To keep key objects platform-independent, the key data is
    #    converted to standard Python long integers before being
    #    written out.  It will then be reconverted as necessary on
    #    restoration."""
    #    d=self.__dict__
    #    for key in self.keydata:
    #        if d.has_key(key): d[key]=long(d[key])
    #    return d
    #
    #def __setstate__(self, d):
    #    """On unpickling a key object, the key data is converted to the big
    #    number representation being used, whether that is Python long
    #    integers, MPZ objects, or whatever."""
    #    for key in self.keydata:
    #        if d.has_key(key): self.__dict__[key]=bignum(d[key])

    def encrypt(self, plaintext, K):
        """encrypt(plaintext:string|long, K:string|long) : tuple
        Encrypt the string or integer plaintext.  K is a random
        parameter required by some algorithms.
        """
        # Anthony - encrypt now simply returns the ciphertext
        # as a long.
        wasString=0
        if isinstance(plaintext, type("")):
            # Anthony stage1 added number.bytes_to_long(
            plaintext=number_bytes_to_long(plaintext) ; wasString=1
        #if isinstance(K, type("")):
        #    # Anthony stage1 added number.bytes_to_long(
        #    K=number_bytes_to_long(K)
        ciphertext=self._encrypt(plaintext, K)
        # Anthony stage1 added number.long_to_bytes(
        #if wasString: return tuple(map(number_long_to_bytes, ciphertext))
        #else: return ciphertext
        return ciphertext

    def decrypt(self, ciphertext):
        """decrypt(ciphertext:tuple|string|long): string
        Decrypt 'ciphertext' using this key.
        """
        # Anthony - decrypt now accepts the arguement ciphertext
        # as a long.
        #wasString=0
        #if not isinstance(ciphertext, type((1,1))):
        #    ciphertext=(ciphertext,)
        #if isinstance(ciphertext[0], type("")):
        #    # Anthony stage1 added number.bytes_to_long
        #    ciphertext=tuple(map(number_bytes_to_long, ciphertext)) ; wasString=1
        plaintext=self._decrypt(ciphertext)
        ## Anthony stage1 added number.long_to_bytes(
        #if wasString: return number_long_to_bytes(plaintext)
        #else: return plaintext
        return number_long_to_bytes(plaintext)

    def sign(self, M, K):
        """sign(M : string|long, K:string|long) : tuple
        Return a tuple containing the signature for the message M.
        K is a random parameter required by some algorithms.
        """
        if (not self.has_private()):
            raise error, 'Private key not available in this object'
        # Anthony stage1 added number.bytes_to_long(
        if isinstance(M, type("")): M=number_bytes_to_long(M)
        if isinstance(K, type("")): K=number_bytes_to_long(K)
        # Anthony - modified to provide backwards compatability - required for
        # pycrypto unittest.
        #return self._sign(M, K)
        # Anthony - Apr18 adjusted to return a long instead of bytes
        #return (number_long_to_bytes(self._sign(M, K)[0]),)
        return (self._sign(M, K)[0], )

    def verify(self, signature):    
    # Anthony - modified to provide backwards compatability - required for 
    # pycrypto unittest.
    #def verify (self, M, signature):
    #    """verify(M:string|long, signature:tuple) : bool
    #    Verify that the signature is valid for the message M;
    #    returns true if the signature checks out.
    #    """
    #    ## Anthony stage1 added number.bytes_to_long(
    #    if isinstance(M, type("")): M=number_bytes_to_long(M)
    #    return self._verify(M, signature)
    
        # Anthony - Apr18 adjusted to return a long instead of bytes    
        #return number_long_to_bytes(self._verify(number_bytes_to_long(signature)))
        return number_long_to_bytes(self._verify(signature))
        
    # Anthony stage 2, removing warnings import.
    # alias to compensate for the old validate() name
    #def validate (self, M, signature):
    #    warnings.warn("validate() method name is obsolete; use verify()",
    #                  DeprecationWarning)

    def blind(self, M, B):
        """blind(M : string|long, B : string|long) : string|long
        Blind message M using blinding factor B.
        """
        wasString=0
        if isinstance(M, type("")):
            # Anthony stage1 added number.bytes_to_long(
            M=number_bytes_to_long(M) ; wasString=1
        # Anthony stage1 added number.bytes_to_long(
        if isinstance(B, type("")): B=number_bytes_to_long(B)
        blindedmessage=self._blind(M, B)
        # Anthony stage1 added number.long_to_bytes(
        if wasString: return number_long_to_bytes(blindedmessage)
        else: return blindedmessage

    def unblind(self, M, B):
        """unblind(M : string|long, B : string|long) : string|long
        Unblind message M using blinding factor B.
        """
        wasString=0
        if isinstance(M, type("")):
            # Anthony stage1 added number.bytes_to_long(
            M=number_bytes_to_long(M) ; wasString=1
        # Anthony stage1 added number.bytes_to_long(
        if isinstance(B, type("")): B=number_bytes_to_long(B)
        unblindedmessage=self._unblind(M, B)
        # Anthony stage1 added number.long_to_bytes(
        if wasString: return number_long_to_bytes(unblindedmessage)
        else: return unblindedmessage


    # The following methods will usually be left alone, except for
    # signature-only algorithms.  They both return Boolean values
    # recording whether this key's algorithm can sign and encrypt.
    def can_sign (self):
        """can_sign() : bool
        Return a Boolean value recording whether this algorithm can
        generate signatures.  (This does not imply that this
        particular key object has the private information required to
        to generate a signature.)
        """
        return 1

    def can_encrypt (self):
        """can_encrypt() : bool
        Return a Boolean value recording whether this algorithm can
        encrypt data.  (This does not imply that this
        particular key object has the private information required to
        to decrypt a message.)
        """
        return 1

    def can_blind (self):
        """can_blind() : bool
        Return a Boolean value recording whether this algorithm can
        blind data.  (This does not imply that this
        particular key object has the private information required to
        to blind a message.)
        """
        return 0

    # The following methods will certainly be overridden by
    # subclasses.

    def size (self):
        """size() : int
        Return the maximum number of bits that can be handled by this key.
        """
        return 0

    def has_private (self):
        """has_private() : bool
        Return a Boolean denoting whether the object contains
        private components.
        """
        return 0

    def publickey (self):
        """publickey(): object
        Return a new key object containing only the public information.
        """
        return self
    
    # Anthony - removed, not using pickle
    #def __eq__ (self, other):
    #    """__eq__(other): 0, 1
    #    Compare us to other for equality.
    #    """
    #    return self.__getstate__() == other.__getstate__()
        # -*- coding: utf-8 -*-
#
#  PublicKey/RSA.py : RSA public key primitive
#
# Copyright (C) 2008  Dwayne C. Litzenberger <dlitz@dlitz.net>
#
# =======================================================================
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# =======================================================================

"""RSA public-key cryptography algorithm."""

"""
<Modified>  
  Anthony 
  Feb 9:
    removed the import of Crypto.Util.python_compat, dont need 
    to support python 2.1 ..
  
    Removed _fastmath import and Crypto Random
  
  Feb 15:
    removed code that set a Random function.
    
  Apr 7:
    Modified behavior of _verify to maintain backwars compatibility.
  Apr 27:
    Modified decrypt to accept a long as its cipher text argument.
    Large change, dropped out behavior for taking tuples, since
    it will never be used in this way for RSA, pubkey has that 
    behavior because of DSA and ElGamal.

"""
# Anthony stage 1
#__revision__ = "$Id$"

# Anthony stage 2
#__all__ = ['generate', 'construct', 'error']

# Anthony
#from Crypto.Util.python_compat import *

# Anthony removing all imports for stage 2
#import _RSA    
#import _slowmath
#import pubkey

# Anthony - not porting Random package yet.
#from Crypto import Random

# Anthony
#try:
#    from Crypto.PublicKey import _fastmath
#except ImportError:
#    _fastmath = None

class RSA_RSAobj(pubkey_pubkey):
    keydata = ['n', 'e', 'd', 'p', 'q', 'u']

    def __init__(self, implementation, key):        
        self.implementation = implementation
        self.key = key
    
    # Anthony - these were assigned in place of the behavior provided
    # by the __getattr__ function which is not supported in repy.    
        try:
            self.n = getattr(self.key, 'n')
        except AttributeError:
            pass
        try:
            self.e = getattr(self.key, 'e')
        except AttributeError:
            pass
        try:
            self.d = getattr(self.key, 'd')
        except AttributeError:
            pass
        try:
            self.p = getattr(self.key, 'p')
        except AttributeError:
            pass
        try:
            self.q = getattr(self.key, 'q')
        except AttributeError:
            pass
        try:
            self.u = getattr(self.key, 'u')
        except AttributeError:
            pass
        
          
    # Anthony - not allowed in repy 
    #def __getattr__(self, attrname):
    #    if attrname in self.keydata:
    #        # For backward compatibility, allow the user to get (not set) the
    #        # RSA key parameters directly from this object.
    #        return getattr(self.key, attrname)
    #    else:
    #        raise AttributeError("%s object has no %r attribute" % (self.__class__.__name__, attrname,))

    def _encrypt(self, c, K):
        return (self.key._encrypt(c),)

    def _decrypt(self, c):
        #(ciphertext,) = c
        #(ciphertext,) = c[:1]  # HACK - We should use the previous line
                               # instead, but this is more compatible and we're
                               # going to replace the Crypto.PublicKey API soon
                               # anyway.
        #return self.key._decrypt(ciphertext)
        return self.key._decrypt(c)

    def _blind(self, m, r):
        return self.key._blind(m, r)

    def _unblind(self, m, r):
        return self.key._unblind(m, r)

    def _sign(self, m, K=None):
        return (self.key._sign(m),)
        
    def _verify(self, sig):
    # Anthony - modified to provide backwards compatability
    #def _verify(self, m, sig):
    #    #(s,) = sig
    #    (s,) = sig[:1]  # HACK - We should use the previous line instead, but
    #                    # this is more compatible and we're going to replace
    #                    # the Crypto.PublicKey API soon anyway.
    #    # Anthony - modified to provide backwars compatability
    #    return self.key._verify(m, s)
        return self.key._verify(sig)

    def has_private(self):
        return self.key.has_private()

    def size(self):
        return self.key.size()

    def can_blind(self):
        return True

    def can_encrypt(self):
        return True

    def can_sign(self):
        return True

    def publickey(self):
        return self.implementation.construct((self.key.n, self.key.e))

    # Anthony - removing this functionality, not allowed in repy
    """
    def __getstate__(self):
        d = {}
        for k in self.keydata:
            try:
                d[k] = getattr(self.key, k)
            except AttributeError:
                pass
        return d

    def __setstate__(self, d):
        if not hasattr(self, 'implementation'):
            self.implementation = RSAImplementation()
        t = []
        for k in self.keydata:
            if not d.has_key(k):
                break
            t.append(d[k])
        self.key = self.implementation._math.rsa_construct(*tuple(t))

    def __repr__(self):
        attrs = []
        for k in self.keydata:
            if k == 'n':
                attrs.append("n(%d)" % (self.size()+1,))
            elif hasattr(self.key, k):
                attrs.append(k)
        if self.has_private():
            attrs.append("private")
        return "<%s @0x%x %s>" % (self.__class__.__name__, id(self), ",".join(attrs))
    """
class RSA_RSAImplementation(object):
    def __init__(self, **kwargs):
        
      
        #Anthony - removed this code, never going to use fast_math
        # 
        ## 'use_fast_math' parameter:
        ##   None (default) - Use fast math if available; Use slow math if not.
        ##   True - Use fast math, and raise RuntimeError if it's not available.
        ##   False - Use slow math.
        #use_fast_math = kwargs.get('use_fast_math', None)
        #if use_fast_math is None:   # Automatic
        #    if _fastmath is not None:
        #        self._math = _fastmath
        #    else:
        #        self._math = _slowmath
        #
        #elif use_fast_math:     # Explicitly select fast math
        #    if _fastmath is not None:
        #        self._math = _fastmath
        #    else:
        #        raise RuntimeError("fast math module not available")
        #
        #else:   # Explicitly select slow math
        #    self._math = _slowmath
        
        #Anthony - added to set _slowmath by default.
        # stage 2, there is no add _slowmath module to the object
        # since we no longer can choose _fastmath
        #self._math = _slowmath
        
        # Anthony stage 2
        #self.error = self._math.error
        self.error = _slowmath_error

        # 'default_randfunc' parameter:
        #   None (default) - use Random.new().read
        #   not None       - use the specified function
        self._default_randfunc = kwargs.get('default_randfunc', None)
        self._current_randfunc = None

    def _get_randfunc(self, randfunc):
        # Anthony - Adjusting to get a random function working
        #if randfunc is not None:
        #    return randfunc
        #elif self._current_randfunc is None:
        #    self._current_randfunc = Random.new().read
        return self._current_randfunc

    def generate(self, bits, randfunc=None, progress_func=None):
        rf = self._get_randfunc(randfunc)
        obj = _RSA_generate_py(bits, rf, progress_func)    # TODO: Don't use legacy _RSA module
        key = _slowmath_rsa_construct(obj.n, obj.e, obj.d, obj.p, obj.q, obj.u)
        return RSA_RSAobj(self, key)

    def construct(self, tup):
        key = _slowmath_rsa_construct(*tup)
        return RSA_RSAobj(self, key)

# Anthony these will not be used in repy.
#_impl = RSAImplementation()
#generate = _impl.generate
#construct = _impl.construct
#error = _impl.error




#
#   RSA.py : RSA encryption/decryption
#
#  Part of the Python Cryptography Toolkit
#
# Distribute and use freely; there are no restrictions on further
# dissemination and usage except those imposed by the laws of your
# country of residence.  This software is provided "as is" without
# warranty of fitness for use or suitability for any purpose, express
# or implied. Use at your own risk or not at all.
#


# Anthony, not allowed for REPY
#__revision__ = "$Id$"

"""
<Modified> 
  Anthony - Feb 24 
  full conversion to stage2 repy port
  
  Anthony - Jun 1
  _RSA_generate_py will no longer generate a p and q such that 
  GCD( e, (p-1)(q-1)) != 1. The old behavior resulted in an invalid
  key when d was computed (it resulted in d = 1).

"""

# Anthony stage2
#import pubkey
#import number

def _RSA_generate_py(bits, randfunc, progress_func=None):
    """generate(bits:int, randfunc:callable, progress_func:callable)

    Generate an RSA key of length 'bits', using 'randfunc' to get
    random data and 'progress_func', if present, to display
    the progress of the key generation.
    
    <Modified>
      Anthony - Because e is fixed, it is possible that a p or q
      is generated such that (p-1)(q-1) is not relatively prime to e.
      A check after p and q are generated will result in p and q
      discarded if either (p-1) or (q-1) is congruent to 0 modulo e.
      
    """
    obj=_RSA_RSAobj()

    # Generate the prime factors of n
    if progress_func:
        progress_func('p,q\n')
        
    p = q = 1L
    while number_size(p*q) < bits:
        # Note that q might be one bit longer than p if somebody specifies an odd
        # number of bits for the key. (Why would anyone do that?  You don't get
        # more security.)
        
        # Anthony stage1 - because pubkey is not using a 
        # 'from number import *' we will call getPrime from
        # number instead
        #p = pubkey.getPrime(bits/2, randfunc)
        #q = pubkey.getPrime(bits - (bits/2), randfunc)
        p = number_getPrime(bits/2, randfunc)
        q = number_getPrime(bits - (bits/2), randfunc)
        
        # Anthony - This is an new modification to the scheme, it is
        # very unlikely that p-1 or q-1 will be a multiple of 65537.
        if ((p - 1) % 65537 == 0) or ((q - 1) % 65537 == 0):
          p = q = 1L


    # p shall be smaller than q (for calc of u)
    if p > q:
        (p, q)=(q, p)
    obj.p = p
    obj.q = q

    if progress_func:
        progress_func('u\n')
        
    # Anthony stage1 - pubkey no longer imports inverse()   
    obj.u = number_inverse(obj.p, obj.q)
    obj.n = obj.p*obj.q

    obj.e = 65537L
    if progress_func:
        progress_func('d\n')
    # Anthony stage1 - pubkey no longer imports inverse()    
    obj.d=number_inverse(obj.e, (obj.p-1)*(obj.q-1))

    assert bits <= 1+obj.size(), "Generated key is too small"
    
    return obj

class _RSA_RSAobj(pubkey_pubkey):

    def size(self):
        """size() : int
        Return the maximum number of bits that can be handled by this key.
        """
        return number_size(self.n) - 1

#
#   number.py : Number-theoretic functions
#
#  Part of the Python Cryptography Toolkit
#
# Distribute and use freely; there are no restrictions on further
# dissemination and usage except those imposed by the laws of your
# country of residence.  This software is provided "as is" without
# warranty of fitness for use or suitability for any purpose, express
# or implied. Use at your own risk or not at all.
#

# Anthony
#__revision__ = "$Id$"

# Anthony - no globals
#bignum = long

# New functions
# Anthony stage 1 - since its not called locally might as well remove it
#from _number_new import *

# Anthony stage2 random will be the repy package we use for random
# number untill we are able complete the port. For stage1 I will
# be using python's random.random(). Now stage2 using repy's random

# Commented out and replaced with faster versions below
## def long2str(n):
##     s=''
##     while n>0:
##         s=chr(n & 255)+s
##         n=n>>8
##     return s

## import types
## def str2long(s):
##     if type(s)!=types.StringType: return s   # Integers will be left alone
##     return reduce(lambda x,y : x*256+ord(y), s, 0L)

def number_size (N):
    """size(N:long) : int
    Returns the size of the number N in bits.
    """
    bits, power = 0,1L
    while N >= power:
        bits += 1
        power = power << 1
    return bits

#def number_getRandomNumber(N, randfunc=None):
#    """getRandomNumber(N:int, randfunc:callable):long
#    Return an N-bit random number.
#
#    If randfunc is omitted, then Random.new().read is used.
#    
#    Anthony - This function is not called by anything.
#    """
#    
#    # Anthony stage1 - This code has been removed because we
#    # are not using the pycrypto PRNG
#    """
#    if randfunc is None:
#        _import_Random()
#        randfunc = Random.new().read
#
#    S = randfunc(N/8)
#    odd_bits = N % 8
#    if odd_bits != 0:
#        char = ord(randfunc(1)) >> (8-odd_bits)
#        S = chr(char) + S
#    value = bytes_to_long(S)
#    value |= 2L ** (N-1)                # Ensure high bit is set
#    assert size(value) >= N
#    return value
#    """
#    # Anthony stage2 repy random is included
#    return random_randint(2**(N-1), 2**N - 1)
  

def number_GCD(x,y):
    """GCD(x:long, y:long): long
    Return the GCD of x and y.
    """
    x = abs(x) ; y = abs(y)
    while x > 0:
        x, y = y % x, x
    return y

def number_inverse(u, v):
    """inverse(u:long, u:long):long
    Return the inverse of u mod v.
    """
    u3, v3 = long(u), long(v)
    u1, v1 = 1L, 0L
    while v3 > 0:
        q=u3 / v3
        u1, v1 = v1, u1 - v1*q
        u3, v3 = v3, u3 - v3*q
    while u1<0:
        u1 = u1 + v
    return u1

# Given a number of bits to generate and a random generation function,
# find a prime number of the appropriate size.

def number_getPrime(N, randfunc=None):
    """getPrime(N:int, randfunc:callable):long
    Return a random N-bit prime number.

    If randfunc is omitted, then Random.new().read is used.
    """
    # Anthony stage1 removing existing random package
    #if randfunc is None:
    #    _import_Random()
    #    randfunc = Random.new().read

    # Anthony stage2 - using repy random for now
    # for N-bit number, max will be (2^N) - 1
    # and min will be 2^(N-1)
    # This will use a bitwise OR to ensure the number is odd
    #origional: number=getRandomNumber(N, randfunc) | 1
    
    # Anthony - changed this again, now that random.repy
    # includes a function to get a random N bit number
    # that can be used instead.
    #number = random_randint(2**(N-1), 2**N - 1) | 1
    number = random_nbit_int(N) | 1
    
    number |= 2L ** (N-1) # ensure high bit is set 
    
    while (not number_isPrime(number, randfunc=randfunc)):
        number=number+2
    return number

def number_isPrime(N, randfunc=None):
    """isPrime(N:long, randfunc:callable):bool
    Return true if N is prime.

    If randfunc is omitted, then Random.new().read is used.
    """
    
    # Anthony stage1 removing the existing random package
    # does not appear that this code is even used in this method.
    """
    _import_Random()
    if randfunc is None:
        randfunc = Random.new().read

    randint = StrongRandom(randfunc=randfunc).randint
    """
    
    sieve = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
       61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
       131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193,
       197, 199, 211, 223, 227, 229, 233, 239, 241, 251]
 
    if N == 1:
        return 0
    if N in sieve:
        return 1
    for i in sieve:
        if (N % i)==0:
            return 0
    
    # Anthony - not going to use _fastmath ever
    # Use the accelerator if available
    #if _fastmath is not None:
    #    return _fastmath.isPrime(N)

    # Compute the highest bit that's set in N
    N1 = N - 1L
    n = 1L
    while (n<N):
        n=n<<1L
    n = n >> 1L

    # Rabin-Miller test
    for c in sieve[:7]:
        a=long(c) ; d=1L ; t=n
        while (t):  # Iterate over the bits in N1
            x=(d*d) % N
            if x==1L and d!=1L and d!=N1:
                return 0  # Square root of 1 found
            if N1 & t:
                d=(x*a) % N
            else:
                d=x
            t = t >> 1L
        if d!=1L:
            return 0
    return 1

# Small primes used for checking primality; these are all the primes
# less than 256.  This should be enough to eliminate most of the odd
# numbers before needing to do a Rabin-Miller test at all.


# Improved conversion functions contributed by Barry Warsaw, after
# careful benchmarking



def number_long_to_bytes(n, blocksize=0):
    """long_to_bytes(n:long, blocksize:int) : string
    Convert a long integer to a byte string.

    If optional blocksize is given and greater than zero, pad the front of the
    byte string with binary zeros so that the length is a multiple of
    blocksize.
    
    Anthony - THIS WILL STRIP OFF LEADING '\000' of a string!
           comes in '\000\xe8\...' and will come out of
           long_to_bytes as '\xe8\..'   
    
    """
    s = ''
    n = long(n)
    tmp = 0
    #pack = struct.pack
    while n > 0:
        # Anthony removed the use of struct module
        #s = pack('>I', n & 0xff ff ff ffL) + s
        s = "%s%s" % (chr(n & 0xFF), s)
        n = n >> 8
    # strip off leading zeros
    for i in range(len(s)):
        if s[i] != '\000':
            break
    else:
        # only happens when n == 0
        s = '\000'
        i = 0
        
    s = s[i:]    
    # add back some pad bytes.  this could be done more efficiently w.r.t. the
    # de-padding being done above, but sigh...    
    if blocksize > 0 and len(s) % blocksize:
        s = (blocksize - len(s) % blocksize) * '\000' + s
    return s

def number_bytes_to_long(s):
    """bytes_to_long(string) : long
    Convert a byte string to a long integer.

    This is (essentially) the inverse of long_to_bytes().
    """
    
    acc = 0L
    length = len(s)
    if length % 4:
        extra = (4 - length % 4)
        s = '\000' * extra + s
        length = length + extra
    
    for i in range(0, length):
        # Anthony - replaced struct module functionality.
        #acc = (acc << 32) + unpack('>I', s[i:i+4])[0]
        acc = (acc << 8) 
        acc = acc + ord(s[i])
    return acc


# For backwards compatibility...
# Anthony Feb 14 
# removed long2str str2long and _import_Random()
"""
import warnings
def long2str(n, blocksize=0):
    warnings.warn("long2str() has been replaced by long_to_bytes()")
    return long_to_bytes(n, blocksize)
def str2long(s):
    warnings.warn("str2long() has been replaced by bytes_to_long()")
    return bytes_to_long(s)

def _import_Random():
    # This is called in a function instead of at the module level in order to avoid problems with recursive imports
    global Random, StrongRandom
    from Crypto import Random
    from Crypto.Random.random import StrongRandom
"""# -*- coding: utf-8 -*-
#
#  PubKey/RSA/_slowmath.py : Pure Python implementation of the RSA portions of _fastmath
#
# Copyright (C) 2008  Dwayne C. Litzenberger <dlitz@dlitz.net>
#
# =======================================================================
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# =======================================================================

"""Pure Python implementation of the RSA-related portions of Crypto.PublicKey._fastmath."""

"""
<Modified> 
  Anthony - Feb 9 
    removed the import of Crypto.Util.python_compat, dont need 
    to support python 2.1 ..
  Anthony - April 7
    Changed return of _verify to coincide with seattle's origional rsa behavior.
  Anthony - April 30
    Changed _slowmath_rsa_construct to allow user to create
    a _slowmath_RSAKey without a public key
  Anthony - May 9
    Modified _slowmath_rsa_construct to allow type int in 
    addition to long.
"""

# Anthony removing globals, looks like this one can go.
#__revision__ = "$Id$"

# Anthony stage 2
#__all__ = ['rsa_construct']

# Anthony - see above for reason
#from Crypto.Util.python_compat import *

# Anthony Stage 1
#from number import size, inverse

# Anthony stage 2
#import number

class _slowmath_error(Exception):
    pass

class _slowmath_RSAKey(object):
    def _blind(self, m, r):
        # compute r**e * m (mod n)
        return m * pow(r, self.e, self.n)

    def _unblind(self, m, r):
        # compute m / r (mod n)
        
        # Anthony stage 1
        return number_inverse(r, self.n) * m % self.n

    def _decrypt(self, c):
        # compute c**d (mod n)
        if not self.has_private():
            raise _slowmath_error("No private key")
        return pow(c, self.d, self.n) # TODO: CRT exponentiation

    def _encrypt(self, m):
        # compute m**d (mod n)
        if not self.has_public():
            raise _slowmath_error("No public key")
        return pow(m, self.e, self.n)

    def _sign(self, m):   # alias for _decrypt
        if not self.has_private():
            raise _slowmath_error("No private key")
        return self._decrypt(m)

    # Anthony - modified to provide backwards compatability with
    # existing procedure. Pycrypto returned a boolean, and the
    # existing repy code requires the encryped signature.
    def _verify(self, sig):
        if not self.has_public():
            raise _slowmath_error("No public key")
    #def _verify(self, m, sig):       
    #    return self._encrypt(sig) == m
        return self._encrypt(sig)

    def has_private(self):
        # Anthony because repy builds private keys that
        # do no have public key data, an additional requirement
        # was added.
        #return hasattr(self, 'd')
        return hasattr(self, 'd') and hasattr(self, 'n')
      
    def has_public(self):
        # Anthony because repy builds private keys that
        # do no have public key data, an additional requirement
        # was added.
        return hasattr(self, 'n') and hasattr(self, 'e')  

    def size(self):
        """Return the maximum number of bits that can be encrypted"""
        # Anthony stage 2
        return number_size(self.n) - 1

# Anthony - changed to allow user to create a private key
# without the public keys
def _slowmath_rsa_construct(n=None, e=None, d=None, p=None, q=None, u=None):
#def _slowmath_rsa_construct(n, e, d=None, p=None, q=None, u=None):
    """Construct an RSAKey object"""
    # Anthony - changed to allow user to create a private key
    # without the public keys
    #assert isinstance(n, long)
    #assert isinstance(e, long)
    # Anthony - modified May 9 to allow type int for each arguement.
    assert isinstance(n, (int, long, type(None)))
    assert isinstance(e, (int, long, type(None)))
    assert isinstance(d, (int, long, type(None)))
    assert isinstance(p, (int, long, type(None)))
    assert isinstance(q, (int, long, type(None)))
    assert isinstance(u, (int, long, type(None)))
    obj = _slowmath_RSAKey()
    # Anthony - changed to allow user to create a private key
    # without the public keys
    #obj.n = n
    #obj.e = e
    if n is not None: obj.n = n
    if e is not None: obj.e = e
    if d is not None: obj.d = d
    if p is not None: obj.p = p
    if q is not None: obj.q = q
    if u is not None: obj.u = u
    return obj

#end include pycryptorsa.repy
    
     
        
def rsa_gen_pubpriv_keys(bitsize):
  """
  <Purpose>
    Will generate a new key object with a key size of the argument
    bitsize and return it. A recommended value would be 1024.
   
  <Arguments>
    bitsize:
           The number of bits that the key should have. This
           means the modulus (publickey - n) will be in the range
           [2**(bitsize - 1), 2**(bitsize) - 1]           

  <Exceptions>
    None

  <Side Effects>
    Key generation will result in call to metered function for
    random data.

  <Return>
    Will return a key object that rsa_encrypt, rsa_decrypt, rsa_sign,
    rsa_validate can use to preform their tasts.
  """

  rsa_implementation = RSA_RSAImplementation()
  
  # The key returned is of type RSA_RSAobj which is derived 
  # from pubkey_pubkey, and wraps a _slowmath_RSAKey object
  rsa_key = rsa_implementation.generate(bitsize)
  
  return ({'e':rsa_key.e, 'n':rsa_key.n },
          {'d':rsa_key.d, 'p':rsa_key.p, 'q':rsa_key.q })
  


def _rsa_keydict_to_keyobj(publickey = None, privatekey = None):
  """
  <Purpose>
    Will generate a new key object using the data from the dictionary
    passed. This is used because the pycrypto scheme uses
    a key object but we want backwards compatibility which
    requires a dictionary. 
  
  <Arguments>
    publickey:
              Must be a valid publickey dictionary of 
              the form {'n': 1.., 'e': 6..} with the keys
              'n' and 'e'.
    privatekey:
               Must be a valid privatekey dictionary of 
               the form {'d':1.., 'p':1.. 'q': 1..} with
               the keys 'd', 'p', and 'q'
  <Exceptions>
    TypeError if neither argument is provided.
    ValueError if public or private key is invalid.
    
  <Side Effects>
    None  
    
  <Return>
    Will return a key object that rsa_encrypt, rsa_decrypt, rsa_sign,
    rsa_validate will use.
  """
  if publickey is not None:
    if not rsa_is_valid_publickey(publickey):
      raise ValueError, "Invalid public key"
  
  if privatekey is not None:    
    if not rsa_is_valid_privatekey(privatekey):
      raise ValueError, "Invalid private key"
    
  if publickey is None and privatekey is None:
    raise TypeError("Must provide either private or public key dictionary")

  if publickey is None: 
    publickey = {}
  if privatekey is None: 
    privatekey = {}
  
  n = None 
  e = None
  d = None
  p = None
  q = None
  
  if 'd' in privatekey: 
    d = long(privatekey['d'])
  if 'p' in privatekey: 
    p = long(privatekey['p'])
  if 'q' in privatekey: 
    q = long(privatekey['q'])  
  
  if 'n' in publickey: 
    n = long(publickey['n'])
  # n is needed for a private key even thought it is not
  # part of the standard public key dictionary.
  else: n = p*q  
  if 'e' in publickey: 
    e = long(publickey['e'])
  
  rsa_implementation = RSA_RSAImplementation()
  rsa_key = rsa_implementation.construct((n,e,d,p,q))
  
  return rsa_key


def rsa_encrypt(message, publickey):
  """
  <Purpose>
    Will use the key to encrypt the message string.
    
    If the string is to large to be encrypted it will be broken 
    into chunks that are suitable for the keys modulus, 
    by the _rsa_chopstring function.
  
  <Arguments>
    message:
            A string to be encrypted, there is no restriction on size.
      
    publickey:
              Must be a valid publickey dictionary of 
              the form {'n': 1.., 'e': 6..} with the keys
              'n' and 'e'.
      
  <Exceptions>
    ValueError if public key is invalid.
    
    _slowmath_error if the key object lacks a public key 
    (elements 'e' and 'n').
  

  <Side Effects>
    None
    
  <Return>
    Will return a string with the cypher text broken up and stored 
    in the seperate integer representation. For example it might
    be similar to the string " 1422470 3031373 65044827" but with
    much larger integers.
  """
  
  # A key object is created to interact with the PyCrypto
  # encryption suite. The object contains key data and
  # the necessary rsa functions.
  temp_key_obj = _rsa_keydict_to_keyobj(publickey)
  
  return _rsa_chopstring(message, temp_key_obj, temp_key_obj.encrypt)



def rsa_decrypt(cypher, privatekey):
  """
  <Purpose>
    Will use the private key to decrypt the cypher string.
    
    
    If the plaintext string was to large to be encrypted it will 
    use _rsa_gluechops and _rsa_unpicklechops to reassemble the
    origional plaintext after the individual peices are decrypted. 
  
  <Arguments>
    cypher:
           The encrypted string that was returned by rsa_encrypt.
           Example:
             Should have the form " 142247030 31373650 44827705"
    
    privatekey:
               Must be a valid privatekey dictionary of 
               the form {'d':1.., 'p':1.. 'q': 1..} with
               the keys 'd', 'p', and 'q'
    
  <Exceptions>
    ValueError if private key is invalid.
    
    _slowmath_error if the key object lacks a private key 
    (elements 'd' and 'n').
      
  <Return>
    This will return the plaintext string that was encrypted
    with rsa_encrypt.
  
  """
    
  # A key object is created to interact with the PyCrypto
  # encryption suite. The object contains key data and
  # the necessary rsa functions.
  temp_key_obj = _rsa_keydict_to_keyobj(privatekey = privatekey)  
  
  return _rsa_gluechops(cypher, temp_key_obj, temp_key_obj.decrypt)
  


def rsa_sign(message, privatekey):
  """
  <Purpose>
    Will use the key to sign the plaintext string.
        
  <None>
    If the string is to large to be encrypted it will be broken 
    into chunks that are suitable for the keys modulus, 
    by the _rsa_chopstring function. 
  
  <Arguments>
    message:
            A string to be signed, there is no restriction on size.
      
    privatekey:
               Must be a valid privatekey dictionary of 
               the form {'d':1.., 'p':1.. 'q': 1..} with
               the keys 'd', 'p', and 'q'
      
  <Exceptions>
    ValueError if private key is invalid.
    
    _slowmath_error if the key object lacks a private key 
    (elements 'd' and 'n').

  <Side Effects>
    None
    
  <Return>
    Will return a string with the cypher text broken up and stored 
    in the seperate integer representation. For example it might
    be similar to the string " 1422470 3031373 65044827" but with
    much larger integers.
    
  """
  
  # A key object is created to interact with the PyCrypto
  # encryption suite. The object contains key data and
  # the necessary rsa functions.
  temp_key_obj = _rsa_keydict_to_keyobj(privatekey = privatekey) 
  
  return _rsa_chopstring(message, temp_key_obj, temp_key_obj.sign)



def rsa_verify(cypher, publickey):
  """
  <Purpose>
    Will use the private key to decrypt the cypher string.
    
    
    If the plaintext string was to large to be encrypted it will 
    use _rsa_gluechops and _rsa_unpicklechops to reassemble the
    origional plaintext after the individual peices are decrypted. 
  
  <Arguments>
    cypher:
           The signed string that was returned by rsa_sign.
           
           Example:
             Should have the form " 1422470 3031373 65044827"
    
    publickey:
              Must be a valid publickey dictionary of 
              the form {'n': 1.., 'e': 6..} with the keys
              'n' and 'e'.
    
  <Exceptions>
    ValueError if public key is invalid.
    
    _slowmath_error if the key object lacks a public key 
    (elements 'e' and 'n').    
    
  <Side Effects>
    None
    
  <Return>
    This will return the plaintext string that was signed by
    rsa_sign.
    
  """
  
  # A key object is created to interact with the PyCrypto
  # encryption suite. The object contains key data and
  # the necessary rsa functions.  
  temp_key_obj = _rsa_keydict_to_keyobj(publickey)
  
  return _rsa_gluechops(cypher, temp_key_obj, temp_key_obj.verify)  
  


def _rsa_chopstring(message, key, function):
  """
  <Purpose>
    Splits 'message' into chops that are at most as long as 
    (key.size() / 8 - 1 )bytes. 
    
    Used by 'encrypt' and 'sign'.
    
  <Notes on chopping>
    If a 1024 bit key was used, then the message would be
    broken into length x, where 1<= x <= 126.
    (1023 / 8) - 1 = 126
    After being converted to a long, the result would
    be at most 1009 bits and at least 9 bits.
    
      maxstring = chr(1) + chr(255)*126
      minstring = chr(1) + chr(0)
      number_bytes_to_long(maxstring) 
      => 2**1009 - 1
      number_bytes_to_long(minstring)
      => 256
    
    Given the large exponent used by default (65537)
    this will ensure that small message are okay and that
    large messages do not overflow and cause pycrypto to 
    silently fail (since its behavior is undefined for a 
    message greater then n-1 (where n in the key modulus).   
    
    WARNING: key.encrypt could have undefined behavior
    in the event a larger message is encrypted.
  
  """
  
  msglen = len(message)
  
  # the size of the key in bits, minus one
  # so if the key was a 1024 bits, key.size() returns 1023
  nbits = key.size() 
  
  # JAC: subtract a byte because we're going to add an extra char on the front
  # to properly handle leading \000 bytes and ensure no loss of information.
  nbytes = int(nbits / 8) - 1
  blocks = int(msglen / nbytes)
  
  if msglen % nbytes > 0:
    blocks += 1

  # cypher will contain the integers returned from either
  # sign or encrypt.
  cypher = []
    
  for bindex in range(blocks):
    offset = bindex * nbytes
    block = message[offset:offset+nbytes]
    # key.encrypt will return a bytestring
    # IMPORTANT: The block is padded with a '\x01' to ensure
    # that no information is lost when the key transforms the block
    # into its long representation prior to encryption. It is striped
    # off in _rsa_gluechops.
    # IMPORTANT: both rsa_encrypt and rsa_sign which use _rsa_chopstring
    # will pass the argument 'function' a reference to encrypt or
    # sign from the baseclass publickey.publickey, they will return
    # the cypher as a tuple, with the first element being the desired
    # integer result.  
    # Example result :   ( 1023422341232124123212 , )
    # IMPORTANT: the second arguement to function is ignored
    # by PyCrypto but required for different algorithms.
    cypher.append( function(chr(1) + block, '0')[0])

  return _rsa_picklechops(cypher)



def _rsa_gluechops(chops, key, function):
  """
  Glues chops back together into a string. Uses _rsa_unpicklechops to
  get a list of cipher text blocks in byte form, then key.decrypt
  is used and the '\x01' pad is striped.
  
  Example 
    chops=" 126864321546531240600979768267740190820"
    after _rsa_unpicklechops(chops)
    chops=['\x0b\xed\xf5\x0b;G\x80\xf4\x06+\xff\xd3\xf8\x1b\x8f\x9f']
  
  Used by 'decrypt' and 'verify'.
  """
  message = ""

  # _rsa_unpicklechops returns a list of the choped encrypted text
  # Will be a list with elements of type long
  chops = _rsa_unpicklechops(chops)    
  for cpart in chops:
    # decrypt will return the plaintext message as a bytestring   
    message += function(cpart)[1:] # Remove the '\x01'
        
  return message



def _rsa_picklechops(chops):
  """previously used to pickles and base64encodes it's argument chops"""
  
  retstring = ''
  for item in chops:  
    # the elements of chops will be of type long
    retstring = retstring + ' ' + str(item)
  return retstring



def _rsa_unpicklechops(string):
  """previously used to base64decode and unpickle it's argument string"""
  
  retchops = []
  for item in string.split():
    retchops.append(long(item))
  return retchops



def rsa_is_valid_privatekey(key):
  """
  <Purpose>
     This tries to determine if a key is valid.   If it returns False, the
     key is definitely invalid.   If True, the key is almost certainly valid
  
  <Arguments>
    key:
        A dictionary of the form {'d':1.., 'p':1.. 'q': 1..} 
        with the keys 'd', 'p', and 'q'    
                  
  <Exceptions>
    None

  <Side Effects>
    None
    
  <Return>
    If the key is valid, True will be returned. Otherwise False will
    be returned.
     
  """
  # must be a dict
  if type(key) is not dict:
    return False

  # missing the right keys
  if 'd' not in key or 'p' not in key or 'q' not in key:
    return False

  # has extra data in the key
  if len(key) != 3:
    return False

  for item in ['d', 'p', 'q']:
    # must have integer or long types for the key components...
    if type(key[item]) is not int and type(key[item]) is not long:
      return False

  if number_isPrime(key['p']) and number_isPrime(key['q']):
    # Seems valid...
    return True
  else:
    return False



def rsa_is_valid_publickey(key):
  """
  <Purpose>
    This tries to determine if a key is valid.   If it returns False, the
    key is definitely invalid.   If True, the key is almost certainly valid
  
  <Arguments>
    key:
        A dictionary of the form {'n': 1.., 'e': 6..} with the 
        keys 'n' and 'e'.  
                  
  <Exceptions>
    None

  <Side Effects>
    None
    
  <Return>
    If the key is valid, True will be returned. Otherwise False will
    be returned.
    
  """
  # must be a dict
  if type(key) is not dict:
    return False

  # missing the right keys
  if 'e' not in key or 'n' not in key:
    return False

  # has extra data in the key
  if len(key) != 2:
    return False

  for item in ['e', 'n']:
    # must have integer or long types for the key components...
    if type(key[item]) is not int and type(key[item]) is not long:
      return False

  if key['e'] < key['n']:
    # Seems valid...
    return True
  else:
    return False
  
  

def rsa_publickey_to_string(publickey):
  """
  <Purpose>
    To convert a publickey to a string. It will read the
    publickey which should a dictionary, and return it in
    the appropriate string format.
  
  <Arguments>
    publickey:
              Must be a valid publickey dictionary of 
              the form {'n': 1.., 'e': 6..} with the keys
              'n' and 'e'.
    
  <Exceptions>
    ValueError if the publickey is invalid.

  <Side Effects>
    None
    
  <Return>
    A string containing the publickey. 
    Example: if the publickey was {'n':21, 'e':3} then returned
    string would be "3 21"
  
  """
  if not rsa_is_valid_publickey(publickey):
    raise ValueError, "Invalid public key"

  return str(publickey['e'])+" "+str(publickey['n'])


def rsa_string_to_publickey(mystr):
  """
  <Purpose>
    To read a private key string and return a dictionary in 
    the appropriate format: {'n': 1.., 'e': 6..} 
    with the keys 'n' and 'e'.
  
  <Arguments>
    mystr:
          A string containing the publickey, should be in the format
          created by the function rsa_publickey_to_string.
          Example if e=3 and n=21, mystr = "3 21"
          
  <Exceptions>
    ValueError if the string containing the privateky is 
    in a invalid format.

  <Side Effects>
    None
    
  <Return>
    Returns a publickey dictionary of the form 
    {'n': 1.., 'e': 6..} with the keys 'n' and 'e'.
  
  """
  if len(mystr.split()) != 2:
    raise ValueError, "Invalid public key string"
  
  return {'e':long(mystr.split()[0]), 'n':long(mystr.split()[1])}



def rsa_privatekey_to_string(privatekey):
  """
  <Purpose>
    To convert a privatekey to a string. It will read the
    privatekey which should a dictionary, and return it in
    the appropriate string format.
  
  <Arguments>
    privatekey:
               Must be a valid privatekey dictionary of 
               the form {'d':1.., 'p':1.. 'q': 1..} with
               the keys 'd', 'p', and 'q'    
                  
  <Exceptions>
    ValueError if the privatekey is invalid.

  <Side Effects>
    None
    
  <Return>
    A string containing the privatekey. 
    Example: if the privatekey was {'d':21, 'p':3, 'q':7} then returned
    string would be "21 3 7"
  
  """
  if not rsa_is_valid_privatekey(privatekey):
    raise ValueError, "Invalid private key"

  return str(privatekey['d'])+" "+str(privatekey['p'])+" "+str(privatekey['q'])



def rsa_string_to_privatekey(mystr):
  """
  <Purpose>
    To read a private key string and return a dictionary in 
    the appropriate format: {'d':1.., 'p':1.. 'q': 1..} 
    with the keys 'd', 'p', and 'q' 
  
  <Arguments>
    mystr:
          A string containing the privatekey, should be in the format
          created by the function rsa_privatekey_to_string.
          Example mystr = "21 7 3"
             
  <Exceptions>
    ValueError if the string containing the privateky is 
    in a invalid format.

  <Side Effects>
    None
    
  <Return>
    Returns a privatekey dictionary of the form 
    {'d':1.., 'p':1.. 'q': 1..} with the keys 'd', 'p', and 'q'.
  
  """
  if len(mystr.split()) != 3:
    raise ValueError, "Invalid private key string"
  
  return {'d':long(mystr.split()[0]), 'p':long(mystr.split()[1]), 'q':long(mystr.split()[2])}



def rsa_privatekey_to_file(key,filename):
  """
  <Purpose>
    To write a privatekey to a file. It will convert the
    privatekey which should a dictionary, to the appropriate format
    and write it to a file, so that it can be read by
    rsa_file_to_privatekey.
  
  <Arguments>
    privatekey:
               Must be a valid privatekey dictionary of 
               the form {'d':1.., 'p':1.. 'q': 1..} with
               the keys 'd', 'p', and 'q'
    filename:
             The string containing the name for the desired
             publickey file.
                  
  <Exceptions>
    ValueError if the privatekey is invalid.

    IOError if the file cannot be opened.

  <Side Effects>
    file(filename, "w") will be written to.
    
  <Return>
    None
  
  """
  
  if not rsa_is_valid_privatekey(key):
    raise ValueError, "Invalid private key"

  fileobject = file(filename,"w")
  fileobject.write(rsa_privatekey_to_string(key))
  fileobject.close()



def rsa_file_to_privatekey(filename):
  """
  <Purpose>
    To read a file containing a key that was created with 
    rsa_privatekey_to_file and return it in the appropriate 
    format: {'d':1.., 'p':1.. 'q': 1..} with the keys 'd', 'p', and 'q' 
  
  <Arguments>
    filename:
             The name of the file containing the privatekey.
             
  <Exceptions>
    ValueError if the file contains an invalid private key string.
    
    IOError if the file cannot be opened.

  <Side Effects>
    None
    
  <Return>
    Returns a privatekey dictionary of the form 
    {'d':1.., 'p':1.. 'q': 1..} with the keys 'd', 'p', and 'q'.
  
  """
  fileobject = file(filename,'r')
  privatekeystring = fileobject.read()
  fileobject.close()

  return rsa_string_to_privatekey(privatekeystring)



def rsa_publickey_to_file(publickey, filename):
  """
  <Purpose>
    To write a publickey to a file. It will convert the
    publickey which should a dictionary, to the appropriate format
    and write it to a file, so that it can be read by
    rsa_file_to_publickey.
  
  <Arguments>
    publickey:
              Must be a valid publickey dictionary of 
              the form {'n': 1.., 'e': 6..} with the keys
              'n' and 'e'.
    filename:
             The string containing the name for the desired
             publickey file.
         
  <Exceptions>
    ValueError if the publickey is invalid.
    
    IOError if the file cannot be opened.

  <Side Effects>
    file(filename, "w") will be written to.
    
  <Return>
    None
  
  """
  
  if not rsa_is_valid_publickey(publickey):
    raise ValueError, "Invalid public key"

  fileobject = file(filename,"w")
  fileobject.write(rsa_publickey_to_string(publickey))
  fileobject.close()



def rsa_file_to_publickey(filename):
  """
  <Purpose>
    To read a file containing a key that was created with 
    rsa_publickey_to_file and return it in the appropriate 
    format:  {'n': 1.., 'e': 6..} with the keys 'n' and 'e'.
  
  <Arguments>
    filename:
             The name of the file containing the publickey.
             
  <Exceptions>
    ValueError if the file contains an invalid public key string.
    
    IOError if the file cannot be opened.

  <Side Effects>
    None
    
  <Return>
    Returns a publickey dictionary of the form 
    {'n': 1.., 'e': 6..} with the keys 'n' and 'e'.
  
  """
  fileobject = file(filename,'r')
  publickeystring = fileobject.read()
  fileobject.close()

  return rsa_string_to_publickey(publickeystring)


def rsa_matching_keys(privatekey, publickey):
  """
  <Purpose>
    Determines if a pair of public and private keys match and allow 
    for encryption/decryption.
  
  <Arguments>
    privatekey: The private key*
    publickey:  The public key*
    
    * The dictionary structure, not the string or file name
  <Returns>
    True, if they can be used. False otherwise.
  """
  # We will attempt to encrypt then decrypt and check that the message matches
  testmessage = "A quick brown fox."
  
  # Encrypt with the public key
  encryptedmessage = rsa_encrypt(testmessage, publickey)

  # Decrypt with the private key
  try:
    decryptedmessage = rsa_decrypt(encryptedmessage, privatekey)
  except TypeError:
    # If there was an exception, assume the keys are to blame
    return False
  except OverflowError:
    # There was an overflow while decrypting, blame the keys
    return False  
  
  # Test for a match
  return (testmessage == decryptedmessage)
#end include rsa.repy
#begin include time.repy
"""
<Program Name>
  time.repy

<Author>
  Eric Kimbrel

<Started>
  Jul 2, 2009

<Purpose>
  Provide a framework to run any implementation of a ntp time service that
  follows the interface provided here.

  Any implementation must provide update method that takes a localport 
  as an argument.

  Implementers will set a mapping to their functions by adding a line
  at the BOTTOM of their implementation, such as 
  TIME_IMP_DICT['my_implementation'] = {'update':update_func}. This forms a sort
  of "nested dictionary" where the highest level contains keys to all of the
  implementations, and the values for the implementation keys are themselves
  dictionaries containing the names of all the functions linked to that
  that implementation which can be used for replacing regular or default
  functions.

  USE:
  
  To use this module, first make a call to time_updatetime(localport),where
  localport is a valid UDP port that you can send and receive on (note that
  this port may not be used depending on the implementation.)

  Then, to get the actual time, call time_gettime() which will return
  the current time (in seconds).

  ADVANCED USE:

  If you want to explicitly set how time.repy will execute you can use
  time_set_pref(pref_list) to override the default values.  Miss use of
  this feature can easily cause unexpected / undefined behavior

"""


# dictionary for time implementers to store their information
# the settime method is passed in for use by implementers
# this is nessicary to make time.repy work with repyhelper
mycontext['TIME_IMP_DICT'] = {}

# include implementations
#begin include ntp_time.repy
"""
   Author: Justin Cappos
     Edited by Eric Kimbrel

   Start Date: 8 August 2008

   Description:

   This IS NOT A STAND ALONE module, it is used as an extension to time.repy

   This module handles getting the time from an external source, via UDP.
   It gets the remote time once and then uses the offset from the local 
   clock from then on
   to return the current time.

   To use this module, first make a call to time_updatetime(localport) with a
   local UDP port that you have permission to send/recv on. This will
   contact some random subset of NTP servers to get and store the local time.

   Then, to get the actual time, call time_gettime() which will return
   the current time (in seconds). time_gettime() can be called at any point
   after having called time_updatetime(localport) since time_gettime() simply
   calculates how much time has elapsed since the local time was originally 
   acquired from one of the NTP servers.

   Note that time_gettime() will raise TimeError if no NTP server responded or
   if time_updatetime(localport) was never previously called.  If time_gettime()
   fails, then time_updatetime(localport) can be called again to sample time
   from another random set of NTP servers.
"""


# Use for random sampling...
#begin include random.repy
#already included random.repy
#end include random.repy


class TimeError(Exception):
  pass





#BUG: Do I need to compensate for the time taken to contact the time server?    (#353)
def ntp_time_updatetime(localport):
  """
   <Purpose>
    Obtains and stores the local time from a subset of NTP servers.

   <Arguments>
    localport:
             The local port to be used when contacting the NTP server(s).

   <Exceptions>
    TimeError when getmyip() fails or one of the subset of NTP servers will not
    respond.

   <Side Effects>
    time_settime(currenttime) is called as the subprocess of a subprocess, which
    adjusts the current time.

   <Returns>
    None.
  """

  try:
    ip = getmyip()
  except Exception, e:
    raise TimeError, str(e)

  timeservers = ["time-a.nist.gov", "time-b.nist.gov", "time-a.timefreq.bldrdoc.gov", "time-b.timefreq.bldrdoc.gov", "time-c.timefreq.bldrdoc.gov", "utcnist.colorado.edu", "time.nist.gov", "time-nw.nist.gov", "nist1.symmetricom.com", "nist1-dc.WiTime.net", "nist1-ny.WiTime.net", "nist1-sj.WiTime.net", "nist1.aol-ca.symmetricom.com", "nist1.aol-va.symmetricom.com", "nist1.columbiacountyga.gov", "nist.expertsmi.com", "nist.netservicesgroup.com"]

  listenhandle = recvmess(ip,localport, time_decode_NTP_packet)
  mycontext['ntp_time_got_time'] = False
  # always close the handle before returning...
  try: 
    # try five random servers times...
    for servername in random_sample(timeservers,5):

      # this sends a request, version 3 in "client mode"
      ntp_request_string = chr(27)+chr(0)*47
      try: 
        sendmess(servername,123, ntp_request_string, ip, localport) # 123 is the NTP port
      except Exception:
        # most likely a lookup error...
        continue

      # wait for 5 seconds for a response before retrying
      for junkiterations in range(10):
        sleep(.5)

        if mycontext['ntp_time_got_time']:
          # If we've had a response, we're done!
          return
    
    
  finally:
    stopcomm(listenhandle)

  # Failure, tried servers without luck...
  raise TimeError, "Time Server update failed.  Perhaps retry later..."


def time_decode_NTP_packet(ip, port, mess, ch):
  mycontext['TIME_IMP_DICT']['time']['set'](time_convert_timestamp_to_float(mess[40:48]))
  mycontext['ntp_time_got_time'] = True
  stopcomm(ch)


# this unpacks the data from the packet and changes it to a float
def time_convert_timestamp_to_float(timestamp):
  integerpart = (ord(timestamp[0])<<24) + (ord(timestamp[1])<<16) + (ord(timestamp[2])<<8) + (ord(timestamp[3]))
  floatpart = (ord(timestamp[4])<<24) + (ord(timestamp[5])<<16) + (ord(timestamp[6])<<8) + (ord(timestamp[7]))
  return integerpart + floatpart / float(2**32)



mycontext['TIME_IMP_DICT']['ntp'] = {'update':ntp_time_updatetime}

#end include ntp_time.repy
#begin include tcp_time.repy
"""
  Author: Zachary Boka
    tcp_time.repy

  Start Date:
    3 May 2009
    Amended 5 July, 2009 to be an extension to time.repy

  Description:

    NOT INTENDED AS A STAND ALONE MODULE, this module is an extension to
    time.repy

    Contacts a server running time_server.repy to get the current time from an
    NTP because only the server can communicate with an NTP.

    To use this module, make one call to tcp_time_updatetime() to get the
    time from the server.  This function also implicitly sets the time.  Then
    call tcp_time_gettime() every time the current time is needed.

"""


#begin include centralizedadvertise.repy
""" 
Author: Justin Cappos

Start Date: July 8, 2008

Description:
Advertisements to a central server (similar to openDHT)


"""

#begin include session.repy
# This module wraps communications in a signaling protocol.   The purpose is to
# overlay a connection-based protocol with explicit message signaling.   
#
# The protocol is to send the size of the message followed by \n and then the
# message itself.   The size of a message must be able to be stored in 
# sessionmaxdigits.   A size of -1 indicates that this side of the connection
# should be considered closed.
#
# Note that the client will block while sending a message, and the receiver 
# will block while recieving a message.   
#
# While it should be possible to reuse the connectionbased socket for other 
# tasks so long as it does not overlap with the time periods when messages are 
# being sent, this is inadvisable.

class SessionEOF(Exception):
  pass

sessionmaxdigits = 20

# get the next message off of the socket...
def session_recvmessage(socketobj):

  messagesizestring = ''
  # first, read the number of characters...
  for junkcount in range(sessionmaxdigits):
    currentbyte = socketobj.recv(1)

    if currentbyte == '\n':
      break
    
    # not a valid digit
    if currentbyte not in '0123456789' and messagesizestring != '' and currentbyte != '-':
      raise ValueError, "Bad message size"
     
    messagesizestring = messagesizestring + currentbyte

  else:
    # too large
    raise ValueError, "Bad message size"

  messagesize = int(messagesizestring)
  
  # nothing to read...
  if messagesize == 0:
    return ''

  # end of messages
  if messagesize == -1:
    raise SessionEOF, "Connection Closed"

  if messagesize < 0:
    raise ValueError, "Bad message size"

  data = ''
  while len(data) < messagesize:
    chunk =  socketobj.recv(messagesize-len(data))
    if chunk == '': 
      raise SessionEOF, "Connection Closed"
    data = data + chunk

  return data

# a private helper function
def session_sendhelper(socketobj,data):
  sentlength = 0
  # if I'm still missing some, continue to send (I could have used sendall
  # instead but this isn't supported in repy currently)
  while sentlength < len(data):
    thissent = socketobj.send(data[sentlength:])
    sentlength = sentlength + thissent



# send the message 
def session_sendmessage(socketobj,data):
  header = str(len(data)) + '\n'
  session_sendhelper(socketobj,header)

  session_sendhelper(socketobj,data)




#end include session.repy
# I'll use socket timeout to prevent hanging when it takes a long time...
#begin include sockettimeout.repy
"""
<Description>
  Puts back in Python's non-blocking functionality.

  send():
    Raises SocketTimeout Error if the send call lasts
    longer than the set timeout.

  recv():
    Guarentees the receipt of a message.   Raises SocketTimeoutError if it does not
    receive any message before a given timeout.
    If actually receives the message, returns the message and continues.

<Usage>
  Text-replacable for Repy Sockets:
    timeout_openconn(desthost, destport, localip=None, localport=None, timeout = 5)
    timeout_waitforconn(localip, localport, function)

  Object:
    sockobj.settimeout(seconds)
    sockobj.send(data)
    sockobj.recv(bytes)
    sockobj.close()

<Date>
  Sun Mar  1 10:27:35 PST 2009

<Example>
  # hello world
  include sockettimer.repy

  def callback(ip, port, timeout_sockobj, commhandle, listenhandle):
    hw_message = timeout_sockobj.recv(1047)

    # cleanup
    stopcomm(commhandle)
    stopcomm(listenhandle)
    timeout_sockobj.close()

    print hw_message # => "hello world!"
  
  def server():
    sockobj = timeout_waitforconn(getmyip(), 12345, callback)

  def client():
    sockobj = timeout_openconn(getmyip(), 12345)
    sockobj.send("hello world!")

  def main():
    server()
    client()
    exitall()

  if callfunc == 'initialize':
    main() 
"""

class SocketTimeoutError(Exception):
  """The socket timed out before receiving a response"""

def timeout_openconn(desthost, destport, localip=None, localport=None, timeout = 5):
  """
  <Purpose> 
    Wrapper for Repy like socket interface

  <Args>
    Same as Repy openconn

  <Exception>
    Timeout exception if the dest address doesnt respond.

  <Returns>
    socket obj on success
  """

  tsock = TimeoutSocket()
  tsock.settimeout(timeout)
  if localip and localport:
    tsock.bind((localip, localport))
  tsock.connect((desthost, destport))
  return tsock

def timeout_waitforconn(localip, localport, function):
  """
  <Purpose> 
    Wrapper for Repy like socket interface

  <Args>
    Same as Repy waitforconn

  <Side Effects>
    Sets up event listener which calls function on messages.

  <Returns>
    Handle to listener.
  """

  tsock = TimeoutSocket()
  tsock.bind((localip, localport))
  tsock.setcallback(function)
  return tsock.listen()

class TimeoutSocket:
  """
  <Purpose>
    Provide an socket object like the Repy usual one.

  <Side Effects>
    Uses a getlock() to watch for a timeout
    Uses waitforconn and openconn to simulate socket
  """

  ################
  # Constructors
  ################

  def __init__(self):
    """ Constructor for socket """
#    self.lock = getlock() # general lock BUG: Do we need to lock everything?
    self.timeout_lock = getlock() # special lock for Timeout condition
    self.timeout = 5 # seconds to wait
    self.bytes_sent = None # used to check if send() timed out

    # user vars   
    self.local_address = None # ip, port
    self.remote_address = None # ip, port
    self.callback = None # the user's function to call

    # repy socket vars
    self.sockobj = None #  the Repy socket
    self.commhandle = None # the current comm
    self.listencommhandle = None # the listener comm

    #error tracking vars
    
    #if any exceptions are thrown in the separate thread executing _send_and_release, 
    #they are caught and stored in this variable, then raised in _send_or_close
    self.TCPSendError = None

  ################
  # Mutator methods
  #################

  def settimeout(self, value):
    """ Setter for timeout"""
    self.timeout = value

  def setcallback(self, function):
    """ Setter for callback function"""
    self.callback = function

  ####################
  # Public Methods
  ####################

  def bind(self, local_address = None):
    """
    <Purpose>
      Set local address

    <Args>
      Tuple of (ip, port) local.
    """
    self.local_address = local_address

  def listen(self):
    """
    <Purpose>
      Listen for peer
    
    <Side Effects>
      Calls Repy waitforconn()
    """
    return self._waitforconn()

  def connect(self, remote_address):
    """
    <Purpose>
      Connect to peer.

    <Args>
      Tuple of (ip, port) remote.
   
    <Side Effects>
      Calls Repy openconn.
    """
    self.remote_address = remote_address
    self._openconn()

  def recv(self, maxLen): # timeout as optional arg ???
    """
    <Purpose>
      If it fails to finish within the timeout, I close the socket and raise a
      TimeoutError exception. I.e. if there's no message, we call it an error
      and raise it.
      
    <Arguments>
      maxLen - bytes to recv

    <Exception>
      Raises TimeoutError exception if the recv times out
      without receiving a message.

    <Side Effects>
      Closes the connection if times out.

    <Returns>
      The message.
    """
    return self._recv_or_close(maxLen)

  def send(self, data):
    """
    <Purpose>
      Just like normal Repy socket.  Sends messages.
      
    <Arguments>
      data - the string message

    <Exception>
      Same as Repy socket.
 
    <Returns>
      The bytes sent.
    """
    return self._send_or_close(data)

  def close(self):
    self.local_address = None # ip, port
    self.remote_address = None # ip, port
    self.callback = None # the user's function to call

    if self.sockobj:
      self.sockobj.close()
    self.sockobj = None #  the Repy socket
    
    # Armon: As part of the semantics, stopcomm will raise an 
    # exception given an invalid handle, e.g. None. Thus,
    # we need to check for this.
    if self.commhandle: 
      stopcomm(self.commhandle)
      self.commhandle = None # the current comm
    
    # Armon: Same as above.
    if self.listencommhandle:
      stopcomm(self.listencommhandle)
      self.listencommhandle = None # the listener comm


  ########################
  # Private
  #########################

  def _openconn(self):
    """Handle current state variables and call Repy openconn."""

    destip, destport = self.remote_address
    if self.local_address:
      srcip, srcport = self.local_address
      self.sockobj = openconn(destip, destport, srcip, srcport, self.timeout)
    else:
      self.sockobj = openconn(destip, destport)

  def _waitforconn(self):
    """Setup way between Repy waitforconn event"""
    localip, localport = self.local_address
    self.listencommhandle = waitforconn(localip, localport, self._callback)
    return self.listencommhandle

  def _callback(self, ip, port, sockobj, ch, lh):
    """Pass on through to user callback"""
    self.sockobj = sockobj
    self.listencommhandle = lh # same as the 1st from wait for comm, right?
    self.commhandle = ch # should we care?
    
    if not self.remote_address:
      self.remote_address = (ip, port)
    else: 
      raise Exception("what! peer does not match?")

    self.callback(ip, port, self, ch, lh)

  def _send(self, data):
    """Send data"""
    return self.sockobj.send(data)

  def _recv(self, maxLen):
    """Recv data of length maxLen"""
    return self.sockobj.recv(maxLen)

  def _send_and_release(self, data):
    """Send data then release the timeout lock"""
    
    #Bug Fix (Cosmin): exceptions thrown in separate thread _send_and_release could not be caught
    #now we store the exception if it is thrown and raise it back in send_or_close
    try:
      self.bytes_sent = self._send(data)
    except Exception, e:
      self.TCPSendError = e
    
    self._quietly_release() # release the lock
 
  def _quietly_release(self):
    """Release the timeout lock and ignore if already released"""
    try:
      self.timeout_lock.release()
    except:
      pass
   
  def _send_or_close(self, data):
    """Raise the Timeout Error if no receipt.  Keep track by timeout_lock."""

    # acquire the lock, when it's release we'll carry on
    self.timeout_lock.acquire()

    # fork off a lock that'll release the lock at the timeout
    timerhandle = settimer(self.timeout, self._quietly_release, ())

    # fork off a send call so we can raise the exception in the main thread
    # the send call will also release our lock
    settimer(0, self._send_and_release, (data,))

    # block until either the timeout or _send finishes
    self.timeout_lock.acquire()
    self.timeout_lock.release()

    if self.bytes_sent: # send finished
      canceltimer(timerhandle)
      retdata = self.bytes_sent
      self.bytes_sent = None
      return retdata
    elif self.TCPSendError != None:
      #Bug Fix (Cosmin): exceptions thrown in separate thread _send_and_release could not be caught
      
      #we got an error within the separate thread that performed the send operation
      exception_to_throw = self.TCPSendError
      self.TCPSendError = None
      raise exception_to_throw
    else: # it timed out
      self.close()
      raise SocketTimeoutError

  def _recv_or_close(self, amount):
    """Raise the Timeout Error if no receipt.  Keep track by timeout_lock."""
    timerhandle = settimer(self.timeout, self._clobbersocket, ())
    try:
      retdata = self._recv(amount)
    except Exception, e:
      # if it's not the timeout, reraise...
      if self.timeout_lock.acquire(False):
        raise
      raise SocketTimeoutError
    
    # I acquired the lock, I should stop the timer because I succeeded...
    if self.timeout_lock.acquire(False):
      # even if this isn't in time, the lock prevents a race condition 
      # this is merely an optimization to prevent the timer from ever firing...
      canceltimer(timerhandle)
      self.timeout_lock.release() # Alper's bug 3/10/09
      return retdata
    else:
      raise SocketTimeoutError

  def _clobbersocket(self):
    """If I can acquire the lock without blocking, then close the socket to abort"""
    if self.timeout_lock.acquire(False):
      self.close()


############################
# Deprecated functions
##############################

# private function...
def sockettimeout_clobbersocket(sockobj,mylock):
  # if I can acquire the lock without blocking, then close the socket to abort
  if mylock.acquire(False):
    sockobj.close()

# if it fails to finish within the timeout, I close the socket and raise a
# SocketTimeout exception...
def sockettimeout_recv_or_close(sockobj, amount, timeout):
  # A lock I'll use for this attempt
  mylock = getlock()
  timerhandle = settimer(timeout,clobbersocket, (sockobj, mylock))
  try:
    retdata = sockobj.recv(amount)
  except Exception, e:
    # if it's not the timeout, reraise...
    if mylock.acquire(False):
      raise
    raise SocketTimeout
    
  # I acquired the lock, I should stop the timer because I succeeded...
  if mylock.acquire(False):
    # even if this isn't in time, the lock prevents a race condition 
    # this is merely an optimization to prevent the timer from ever firing...
    canceltimer(timerhandle)
    return retdata
  else:
    raise SocketTimeout


#end include sockettimeout.repy
servername = "satya.cs.washington.edu"
serverport = 10101

def centralizedadvertise_announce(key, value, ttlval):

  sockobj = timeout_openconn(servername,serverport, timeout=10)
  try:
    session_sendmessage(sockobj, "PUT|"+str(key)+"|"+str(value)+"|"+str(ttlval))
    response = session_recvmessage(sockobj)
    if response != 'OK':
      raise Exception, "Centralized announce failed '"+response+"'"
  finally:
    # BUG: This raises an error right now if the call times out ( #260 )
    # This isn't a big problem, but it is the "wrong" exception
    sockobj.close()
  
  return True
      



def centralizedadvertise_lookup(key, maxvals=100):
  sockobj = timeout_openconn(servername,serverport, timeout=10)
  try:
    session_sendmessage(sockobj, "GET|"+str(key)+"|"+str(maxvals))
    recvdata = session_recvmessage(sockobj)
    # worked
    if recvdata.endswith('OK'):
      return recvdata[:-len('OK')].split(',')
    raise Exception, "Centralized lookup failed"
  finally:
    # BUG: This raises an error right now if the call times out ( #260 )
    # This isn't a big problem, but it is the "wrong" exception
    sockobj.close()
      



#end include centralizedadvertise.repy

#begin include random.repy
#already included random.repy
#end include random.repy

#begin include sockettimeout.repy
#already included sockettimeout.repy
#end include sockettimeout.repy





# This function contacts the server to get the time from a NTP
def tcp_time_updatetime(localport):
  """
  <Purpose>
    Opens a connection with a server hosting time_server.repy, which obtains the
    current time via a NTP, then calls time_settime(float(currenttime)) to set
    the current time to the received value form the server.

  <Arguments>
    localport:

      The local port which may be used in contacting NTP servers.  It is
      currently not used in this function, but must be present as an argument
      for compatibility issues with time.repy.

  <Exceptions>
    Exception raised if centralizedadvertise_lookup("time_server") fails after
    ten tries.

    Exception raised when a connection is not able to be established with any of
    the servers running time_server.repy.

  <Side Effects>
    time_settime(float(currenttime)) is called to set the time.

  <Returns>
    None.

"""

  # Get the ips and ports of servers hosting time_server.repy, retrying nine
  # times if there is an exception.
  gotval = False
  attemptretrieval = 0
  while attemptretrieval < 10:
    try:
      serveraddresses = centralizedadvertise_lookup("time_server")
    except Exception:
      attemptretrieval = attemptretrieval + 1
      sleep(10)                 # Look up the value again in 10 seconds
    else:
      if serveraddresses != [] and serveraddresses[0] != '':
        gotval = True	        # Successfully obtained the value
        break
      else:
        attemptretrieval = attemptretrieval + 1


  if not gotval:
    raise Exception("Unable to locate any servers running time_server.repy")


  timelength = 25  # Max length of string, representing the time, to be received
  shuffledserveraddresses = random_sample(serveraddresses,len(serveraddresses))

  # Open a connection with a random server hosting time_server.repy
  timeobtained = False
  serverindex = 0
  while serverindex < len(shuffledserveraddresses):
    remoteaddress = shuffledserveraddresses[serverindex].split(':')
    remoteip = remoteaddress[0]
    remoteport = int(remoteaddress[1])

    try:
      sockobject = timeout_openconn(remoteip,remoteport)
    except Exception:
      pass  # stay in the while loop to try a different server
    else:
      timeobtained = True
      break


  if not timeobtained:
    raise Exception("Unable to open connection with any of the ",len(shuffledserveraddresses),"servers running time_server.repy.")


  # the timeserver appends a $ at the end of the time to ensure
  # we got the whole message  
  currenttime = ''
  while '$' not in currenttime:
    currenttime += sockobject.recv(timelength)
  sockobject.close()
  currenttime = float(currenttime[:-1])

  # finally, set the time
  mycontext['TIME_IMP_DICT']['time']['set'](currenttime)



# set information about this implementation in the time.repy IMP_DICT
mycontext['TIME_IMP_DICT']['tcp'] = {'update':tcp_time_updatetime}

#end include tcp_time.repy



# set the order of preferences for time layers
# this is set by default to use ntp_time.repy and the tcp_time.repy
TIME_PREF = ['ntp','tcp']


time_query_times = []


def time_set_pref(new_pref_list):
# for advanced use only
# manually set the layers to be used
  
  # empty the current list
  while (len(TIME_PREF) >0):
    TIME_PREF.pop()

  # refill the list with custom preferences
  for pref in new_pref_list:
    TIME_PREF.append(pref)



def time_updatetime(localport):
  """
   <Purpose>
    Obtains and stores the local time from a subset of NTP servers.

   <Arguments>
    localport:
             The local port that MAY be used when contacting the NTP server(s).
             Consider this port a hint and not a rule.
   
   <Exceptions>
    TimeError when getmyip() fails or one of the subset of NTP servers will not
    respond.

   <Side Effects>
    time_settime(currenttime) is called as the sub process of a sub process,
    which adjusts the current time.

   <Returns>
    None.
  """
  exception_list = []
  # try the 'update' function for each implementation, storing exceptions in
  # case of total failure, and exiting the function when any of the 'update'
  # functions succeed.
  for imp in TIME_PREF:
    try:
      mycontext['TIME_IMP_DICT'][imp]['update'](localport)
    except Exception, e:
      exception_list.append(e)
    else:
      return  # exit when we succeed

  # we failed
  ex_str =''
  for ex in exception_list:
    ex_str+=str(ex)
  ex_str = 'ERROR: failed to update ntp time, '+ex_str
  raise Exception(ex_str)





def time_settime(currenttime):
  """
   <Purpose>
    Sets a remote time as the current time.

   <Arguments>
    currenttime:
               The remote time to be set as the current time.

   <Exceptions>
    None.

   <Side Effects>
    Adjusts the current time.

   <Returns>
    None.
  """

  time_query_times.append((getruntime(), currenttime))






def time_gettime():
  """
   <Purpose>
    Gives the current time in seconds by calculating how much time has elapsed
    since the local time was obtained from an NTP server via the
    time_updatetime(localport) function.

   <Arguments>
    None.

   <Exceptions>
    TimeError when time_updatetime(localport)has not previously been called or 
    when time_updatetime(localport) has any unresolved TimeError exceptions.

   <Side Effects>
    None.

   <Returns>
    Current time in seconds.
  """

  if time_query_times == []:
    raise TimeError

  # otherwise use the most recent data...
  latest_update = time_query_times[-1]

  # first item is the getruntime(), second is NTP time...
  elapsedtimesinceupdate = getruntime() - latest_update[0]

  return latest_update[1] + elapsedtimesinceupdate



# in case you want to change to time since the 1970 (as is common)
time_seconds_from_1900_to_1970 = 2208988800


# pass the time_settime method into the TIME_IMP_DICT for
# use by implementers
mycontext['TIME_IMP_DICT']['time'] = {'set':time_settime}

#end include time.repy


# The signature for a piece of data is appended to the end and has the format:
# \n!publickey!timestamp!expirationtime!sequencedata!destination!signature
# The signature is actually the sha hash of the data (including the
# publickey, timestamp, expirationtime, sequencedata and destination) encrypted
# by the private key.



# I'll allow None and any int, long, or float (can be 0 or negative)
def signeddata_is_valid_timestamp(timestamp):
  if timestamp == None:
    return True

  if type(timestamp) is not int and type(timestamp) is not long and type(timestamp) is not float:
    return False

  return True

  
# I'll allow None and any int, long, or float that is 0 or positive
def signeddata_is_valid_expirationtime(expirationtime):
  if expirationtime == None:
    return True

  if type(expirationtime) is not int and type(expirationtime) is not long and type(expirationtime) is not float:
    return False

  if expirationtime < 0:
    return False

  return True





# sequence numbers must be 'tag:num' where tag doesn't contain ':','\n', or '!' # and num is a number
def signeddata_is_valid_sequencenumber(sequencenumber):
  if sequencenumber == None:
    return True

  if type(sequencenumber) != tuple:
    return False

  if len(sequencenumber) != 2:
    return False

  if type(sequencenumber[0]) != str:
    return False
  
  if '!' in sequencenumber[0] or ':' in sequencenumber[0] or '\n' in sequencenumber[0]:
    return False

  if type(sequencenumber[1]) != long and type(sequencenumber[1]) != int:
    return False

  return True

# Destination is an "opaque string" or None.  Should not contain a '!' or '\n'
def signeddata_is_valid_destination(destination):
  if type(destination) == type(None):
    return True

  # a string without '!' or '\n' ('!' is the separator character, '\n' is not
  # allowed anywhere in the signature)
  if type(destination) == type('abc') and '!' not in destination and '\n' not in destination:
    return True

  return False
  


#applies a signature to a given message (parameter data) and returns the signed message
def signeddata_signdata(data, privatekey, publickey, timestamp=None, expiration=None, sequenceno=None,destination=None):

  if not signeddata_is_valid_timestamp(timestamp):
    raise ValueError, "Invalid Timestamp"

  if not signeddata_is_valid_expirationtime(expiration):
    raise ValueError, "Invalid Expiration Time"

  if not signeddata_is_valid_sequencenumber(sequenceno):
    raise ValueError, "Invalid Sequence Number"

  if not signeddata_is_valid_destination(destination):
    raise ValueError, "Invalid Destination"


  # Build up \n!pubkey!timestamp!expire!sequence!dest!signature
  totaldata = data + "\n!"+rsa_publickey_to_string(publickey)
  totaldata = totaldata+"!"+signeddata_timestamp_to_string(timestamp)
  totaldata = totaldata+"!"+signeddata_expiration_to_string(expiration)
  totaldata = totaldata+"!"+signeddata_sequencenumber_to_string(sequenceno)
  totaldata = totaldata+"!"+signeddata_destination_to_string(destination)
  
  #generate the signature
  signature = signeddata_create_signature(totaldata, privatekey, publickey)
  
  totaldata = totaldata+"!"+ signature

  return totaldata

#creates a signature for the given data string and returns it
def signeddata_create_signature(data, privatekey, publickey):

  # NOTE: This takes waaaay too long.   I'm going to do something simpler...
  #  if not rsa_is_valid_privatekey(privatekey):
  #    raise ValueError, "Invalid Private Key"
  if not privatekey:
    raise ValueError, "Invalid Private Key"
      
  if not rsa_is_valid_publickey(publickey):
    raise ValueError, "Invalid Public Key"
    
  # Time to get the hash...
  shahashobj = sha()
  shahashobj.update(data)
  hashdata = shahashobj.digest()


  # ...and sign it
  signature = rsa_sign(hashdata, privatekey)
  
  return str(signature)


# return [original data, signature]
def signeddata_split_signature(data):
  return data.rsplit('\n',1)


# checks the signature.   If the public key is specified it must match that in
# the file...
def signeddata_issignedcorrectly(data, publickey=None):
  # I'll check signature over all of thesigneddata
  thesigneddata, signature = data.rsplit('!',1)
  junk, rawpublickey, junktimestamp, junkexpiration, junksequenceno, junkdestination = thesigneddata.rsplit('!',5)
  
  if publickey != None and rsa_string_to_publickey(rawpublickey) != publickey:
    return False

  publickey = rsa_string_to_publickey(rawpublickey)

  try: 
    # extract the hash from the signature
    signedhash = rsa_verify(signature, publickey)
  except TypeError, e:
    if 'RSA' not in str(e):
      raise
    # Bad signature or public key
    return False
  except OverflowError, e:      
    #bad signature 
    #this is most likely caused by mismatched public and private keys.
    return False
    
  # Does the hash match the signed data?
  if signedhash == sha_hash(thesigneddata):
    return True
  else:
    return False
  

def signeddata_string_to_destination(destination):
  if destination == 'None':
    return None
  return destination

def signeddata_destination_to_string(destination):
  return str(destination)


def signeddata_string_to_timestamp(rawtimestamp):
  if rawtimestamp == 'None':
    return None
  return float(rawtimestamp)


def signeddata_timestamp_to_string(timestamp):
  return str(timestamp)

def signeddata_string_to_expiration(rawexpiration):
  if rawexpiration == 'None':
    return None
  return float(rawexpiration)

def signeddata_expiration_to_string(expiration):
  return str(expiration)



def signeddata_string_to_sequencenumber(sequencenumberstr):
  if sequencenumberstr == 'None' or sequencenumberstr == None:
    return None

  if type(sequencenumberstr) is not str:
    raise ValueError, "Invalid sequence number type '"+str(type(sequencenumberstr))+"' (must be string)"
    
  if len(sequencenumberstr.split(':')) != 2:
    raise ValueError, "Invalid sequence number string (does not contain 1 ':')"

  if '!' in sequencenumberstr:
    raise ValueError, "Invalid sequence number data: '!' not allowed"
  
  return sequencenumberstr.split(':')[0],int(sequencenumberstr.split(':')[1])


def signeddata_sequencenumber_to_string(sequencenumber):
  if type(sequencenumber) is type(None):
    return 'None'

  if type(sequencenumber[0]) is not str:
    raise ValueError, "Invalid sequence number type"

  if type(sequencenumber[1]) is not long and type(sequencenumber[1]) is not int:
    raise ValueError, "Invalid sequence number count type"
    
  if len(sequencenumber) != 2:
    raise ValueError, "Invalid sequence number"

  return sequencenumber[0]+":"+str(sequencenumber[1])


def signeddata_iscurrent(expiretime):
  if expiretime == None:
    return True

  # may throw TimeError...
  currenttime = time_gettime()
  if expiretime > currenttime:
    return True
  else:
    return False




def signeddata_has_good_sequence_transition(oldsequence, newsequence):
  # None is always allowed by any prior sequence
  if newsequence == None:
    return True
    
  #newsequence is a tuple
  newsequencename,st_newsequenceno = newsequence
  newsequenceno = int(st_newsequenceno)

  if oldsequence == None: 
    # is this the start of a sequence when there was none prior?
    if newsequenceno == 0:
      return True
    return False
  
  # oldsequence is a pair.
  oldsequencename,st_oldsequenceno = oldsequence
  oldsequenceno = int(st_oldsequenceno)
  

  
  # They are from the same sequence
  if oldsequencename == newsequencename:
    # and this must be the next number to be valid
    if oldsequenceno + 1 == newsequenceno:
      return True
    return False

  else: 
    # Different sequences
 
    # is this the start of a new sequence?
    if newsequenceno == 0:
      return True

    # otherwise this isn't good
    return False


# used in lieu of a global for destination checking
signeddata_identity = {}

# Used to set identity for destination checking...
def signeddata_set_identity(identity):
  signeddata_identity['me'] = identity


def signeddata_destined_for_me(destination):
  # None means it's for everyone
  if destination == None:
    return True

  # My identity wasn't set and the destination was, so fail...
  if 'me' not in signeddata_identity:
    return False

  # otherwise, am I in the colon delimited list?
  if signeddata_identity['me'] in destination.split(':'):
    return True
  return False



def signeddata_split(data):
  originaldata, rawpublickey, rawtimestamp, rawexpiration, rawsequenceno,rawdestination, junksignature = data.rsplit('!',6)
  
  # strip the '\n' off of the original data...
  return originaldata[:-1], rsa_string_to_publickey(rawpublickey), signeddata_string_to_timestamp(rawtimestamp), signeddata_string_to_expiration(rawexpiration), signeddata_string_to_sequencenumber(rawsequenceno), signeddata_string_to_destination(rawdestination)



def signeddata_getcomments(signeddata, publickey=None):
  """Returns a list of problems with the signed data (but doesn't look at sequence number or timestamp data)."""
  returned_comments = []

  try:
    junkdata, pubkey, timestamp, expiretime, sequenceno, destination = signeddata_split(signeddata)
  except KeyError:
    return ['Malformed signed data']

  if publickey != None and publickey != pubkey:
    returned_comments.append('Different public key')

  if not signeddata_issignedcorrectly(signeddata, publickey):
    returned_comments.append("Bad signature")
  
  try:
    if not signeddata_iscurrent(expiretime):
      returned_comments.append("Expired signature")
  except TimeError:
    returned_comments.append("Cannot check expiration")

  #BUG FIX: destination checking has been re-enabled since teh issue with identities not being stored correctly has been fixed
  if destination != None and not signeddata_destined_for_me(destination):
    returned_comments.append("Not destined for this node")


  return returned_comments



signeddata_warning_comments = [ 'Timestamps match', "Cannot check expiration" ]
signeddata_fatal_comments = ['Malformed signed data', 'Different public key', "Bad signature", "Expired signature", 'Public keys do not match', 'Invalid sequence transition', 'Timestamps out of order', 'Not destined for this node']

signeddata_all_comments = signeddata_warning_comments + signeddata_fatal_comments

def signeddata_shouldtrustmeta(oldsignature, newsigneddata, publickey=None):
  """
  the signature of the metadata should be specified for the oldsignature parameter
  newsigneddata must contain the full request,
  """
  return signeddata_shouldtrust(oldsignature, newsigneddata, publickey=None, oldsigneddata_is_fullrequest=False)

def signeddata_shouldtrust(oldsigneddata, newsigneddata, publickey=None, oldsigneddata_is_fullrequest=True):
  """ Returns False for 'don't trust', None for 'use your discretion' and True 
  for everything is okay.   The second item in the return value is a list of
  reasons / justifications
  newsigneddata must contain full request
  by default, oldsigneddata must contain only the full previous request (for compatibility issues).
  if oldsigneddata_is_fullrequest=False, only the signature must be specified for oldsigneddata
  """

  returned_comments = []

# we likely only want to keep the signature data around in many cases.   For 
# example, if the request is huge.   
#  if not signeddata_issignedcorrectly(oldsigneddata, publickey):
#    raise ValueError, "Old signed data is not correctly signed!"

  if not signeddata_issignedcorrectly(newsigneddata, publickey):
    returned_comments.append("Bad signature")
    return False, returned_comments
    
  # extract information about the current signature
  newjunk, newpubkey, newtime, newexpire, newsequence, newdestination = signeddata_split(newsigneddata)
  
  # get comments on everything but the timestamp and sequence number
  returned_comments = returned_comments + signeddata_getcomments(newsigneddata, publickey)
  
  #BUG FIX: only if the oldmetadata is not set to None, we want to split it and verify it
  if oldsigneddata != None :
  
    if (oldsigneddata_is_fullrequest):
      oldjunk, oldpubkey, oldtime, oldexpire, oldsequence, olddestination = signeddata_split(oldsigneddata)
    else:
      oldrawpublickey, oldrawtimestamp, oldrawexpiration, oldrawsequenceno, oldrawdestination, oldjunksignature = oldsigneddata.rsplit('!',5)
      oldpubkey, oldtime, oldexpire, oldsequence, olddestination = rsa_string_to_publickey(oldrawpublickey[1:]), signeddata_string_to_timestamp(oldrawtimestamp), signeddata_string_to_expiration(oldrawexpiration), signeddata_string_to_sequencenumber(oldrawsequenceno), signeddata_string_to_destination(oldrawdestination)
    
  

    # get comments on everything but the timestamp and sequence number
    returned_comments = returned_comments + signeddata_getcomments(newsigneddata, publickey)
  
    # check the sequence number data...
    if not signeddata_has_good_sequence_transition(oldsequence, newsequence):
      returned_comments.append('Invalid sequence transition')

    # check the timestamps...  
    if (newtime == None and oldtime != None) or oldtime == None or oldtime > newtime:
      # if the timestamps are reversed (None is the earliest possible)
      returned_comments.append('Timestamps out of order')
    elif oldtime != None and newtime != None and oldtime == newtime:
      # the timestamps are equal but not none...
      returned_comments.append('Timestamps match')
    else:   # So they either must both be None or oldtime < newtime
      assert((newtime == oldtime == None) or oldtime < newtime)
  

  # let's see what happened...
  if returned_comments == []:
    return True, []
  for comment in returned_comments:
    if comment in signeddata_fatal_comments:
      return False, returned_comments

    # if not a failure, should be a warning comment
    assert(comment in signeddata_warning_comments)

  # Warnings, so I won't return True
  return None, returned_comments
  

#end include signeddata.repy

# session wrapper (breaks the stream into messages)
# an abstracted "itemized data communication" in a separate API
#begin include session.repy
#already included session.repy
#end include session.repy



#allow nat layer
#begin include NATLayer_rpc.py
"""

Author: Armon Dadgar, Eric Kimbrel

Start Date: January 22nd, 2009

Description:
Provides a method of transferring data to machines behind firewalls or Network Address Translation (NAT).

"""


#begin include NAT_advertisement.py
"""
Author: Armon Dadgar, Eric Kimbrel

Start date: March 27, 2009

Description: Abstracts the task of looking up and advertising servers and forwarders.

"""

#begin include centralizedadvertise.repy
#already included centralizedadvertise.repy
#end include centralizedadvertise.repy
#begin include deserialize.py
"""

Author: Armon Dadgar

Start Date: February 16th, 2009

Description:
Functions to reconstruct objects from their string representation.

"""
# Constants for the types, these are the supported object types
DERSERIALIZE_DICT = 1
DERSERIALIZE_LIST = 2
DERSERIALIZE_TUPLE = 3

# Convert a string, which either a boolean, None, floating point number,
# long, or int to a primitive, not string type
def deserialize_stringToPrimitive(inStr):
  try:
    # Check if it is None
    if inStr == "None":
      return None
      
    # Check if it is boolean
    if inStr == "True":
      return True
    elif inStr == "False":
      return False
    
    # Check if it is floating point
    if inStr.find(".") != -1:
      val = float(inStr)
  
    # It must be a long/int
    else:
      # It is a long if it has an L suffix
      if inStr[-1] == 'L':
        val = long(inStr)
      else:
        val = int(inStr)
  except:
    return inStr
  
  return val

# Returns an array with the index of the search char
def deserialize_findChar(char, str):
  indexes = []
  
  # Look for all starting braces
  location = 0
  first = True
  while first or index != -1:
    # Turn first off
    if first:
      first = False

    # Search for sub dictionaries
    index = str.find(char,location)

    # Add the index, update location
    if index != -1:
      indexes.append(index)
      location = index+1   
  
  return indexes
      
# Find sub-objects
def deserialize_findSubObjs(str):
  # Object types
  objectStarts = {"{":DERSERIALIZE_DICT,"[":DERSERIALIZE_LIST,"(":DERSERIALIZE_TUPLE}
  objectEnds = {"}":DERSERIALIZE_DICT,"]":DERSERIALIZE_LIST,")":DERSERIALIZE_TUPLE}
  
  # Location of the start and end braces
  startIndexes = []
  for (start, type) in objectStarts.items():
    startIndexes += deserialize_findChar(start, str)
  startIndexes.sort()
  
  # Check if any sub-dicts exist    
  if len(startIndexes) == 0:
    return []
  
  endIndexes = []
  for (end, type) in objectEnds.items():
    endIndexes += deserialize_findChar(end, str)          
  endIndexes.sort()
  
  # Partitions of the string
  partitions = []
  
  startindex = 0
  endindex = 0
  
  while True:    
    maxStartIndex = len(startIndexes) - 1
    
    if maxStartIndex == -1:
      break
      
    if maxStartIndex == startindex or endIndexes[endindex] < startIndexes[startindex+1]:
      partitions.append([startIndexes[startindex],endIndexes[endindex],startindex,objectStarts[str[startIndexes[startindex]]]])
      del startIndexes[startindex]
      del endIndexes[endindex]
      startindex = 0
      endindex = 0
    else:
      startindex += 1
  
  return partitions
  
# Returns an object from the string filler
def deserialize_partitionedObj(value, partitions):
  index = int(value.lstrip("#"))
  return partitions[index]

# Modifies the start and end indexes of all elements in the array
# by indexOffset if they are greater than the start index
def deserialize_indexOffsetAdjustment(array, start, indexOffset):
  index = 0
  
  while index < len(array):
    if array[index][0] > start:
      array[index][0] -= indexOffset
    if array[index][1] > start:
      array[index][1] -= indexOffset
    index += 1
    
# Removes all string objects from a larger string
def deserialize_removeStringObjects(strIn, partitions):
  # Get strings starting with a single quote
  substrings1 = deserialize_findChar("'",strIn)
  
  # Get strings starting with a double quote
  substrings2 = deserialize_findChar("\"",strIn)
  
  # Calculate the lengths
  num1 = len(substrings1)
  num2 = len(substrings2)    
  partitionIndex = len(partitions)
  
  # Actual top level strings
  substrings = []
  
  # Filter out strings inside other strings
  subIndex1 = 0
  subIndex2 = 0
  if num1 != 0 and num2 != 0:
    while True:
      # Get the indexes of both lists
      start1 = substrings1[subIndex1]
      start2 = substrings2[subIndex2]
    
      # If the start index of one is lower than the other, then 
      # remove all members until we reach the closing quote
      if start1<start2:
        # Get the index value of the closing quote
        endIncrement = substrings1[subIndex1+1]
      
        # While there are strings between the starting and closing quote, remove them
        while num2 != 0 and endIncrement > start2:
          del substrings2[subIndex2]
          num2 -= 1
          if num2 == subIndex2:
            break
          start2 = substrings2[subIndex2]
      
        # Add the current start and end to the list of substrings
        substrings.append([start1,endIncrement])
        subIndex1 += 2
        
      elif start2<start1:
        # Get the index value of the closing quote
        endIncrement = substrings2[subIndex2+1]
      
        # While there are strings between the starting and closing quote, remove them
        while num1 != 0 and endIncrement > start1:
          del substrings1[subIndex1]
          num1 -= 1
          if num1 == subIndex1:
            break
          start1 = substrings1[subIndex1]
      
        # Add the current start and end to the list of substrings
        substrings.append([start2,endIncrement])
        subIndex2 += 2
    
      # Break if we've hit the end of either list
      if subIndex1 >= num1 or subIndex2 >= num2:
        break
  
  # Add any remaining substrings, that were not nested
  while subIndex1+1 < num1:
    substrings.append([substrings1[subIndex1],substrings1[subIndex1+1]])
    subIndex1 += 2
  while subIndex2+1 < num2:
    substrings.append([subIndex2[subIndex2],subIndex2[subIndex2+1]])
    subIndex2 += 2
  
  # Cleanup
  substrings1 = None
  substrings2 = None
    
  # Remove every substring and store as an object
  for sub in substrings:
    # Get the info for the string
    (start,end) = sub
    
    # Extract the real string, store it
    actualstr = strIn[start+1:end] # Add one to the start to avoid including the single quotes
    partitions.append(actualstr)
    
    # Replace the string in the larger string with a filler
    addIn = "#"+str(partitionIndex)
    partitionIndex += 1
    strIn = strIn[0:start]+addIn+strIn[end+1:]
    
    # Modify the indexes of the existing strings
    indexOffset = 1+end-start
    indexOffset -= len(addIn)
    deserialize_indexOffsetAdjustment(substrings, start, indexOffset)
    
  return strIn  

# Removes all lists and dictionary objects from the string, begins deserializing
# objects from the innermost depth upward
def deserialize_removeObjects(strIn, partitions=[]):  
  # Find all the sub objects
  subObjs = deserialize_findSubObjs(strIn)
  
  # Get the current length of the partitions
  partitionIndex = len(partitions)
    
  # Determine maximum depth
  maxDepth = 0
  for obj in subObjs:
    maxDepth = max(maxDepth, obj[2])
  
  # Start at the lowest depth and work upward
  while maxDepth >= 0:
    for obj in subObjs:
      (start,end,depth,type) = obj
      if depth == maxDepth:
        # Switch deserialization method on type
        if type == DERSERIALIZE_DICT:
          realObj = deserialize_dictObj(strIn[start:end+1],partitions)
        elif type == DERSERIALIZE_LIST:
          realObj = deserialize_listObj(strIn[start:end+1],partitions)
        elif type == DERSERIALIZE_TUPLE:
          realObj = deserialize_tupleObj(strIn[start:end+1],partitions)
        
        # Store the real object
        partitions.append(realObj)
        
        # Replace the string representation of the object with a filler
        addIn = "#"+str(partitionIndex)
        partitionIndex += 1
        strIn = strIn[0:start]+addIn+strIn[end+1:]
        
        # Modify the indexes now that the string length has changed
        indexOffset = 1+end-start
        indexOffset -= len(addIn)
        deserialize_indexOffsetAdjustment(subObjs, start, indexOffset)
    
    # Go up to a higher depth        
    maxDepth -= 1
  
  return strIn
          
# Convert a string representation of a Dictionary back into a dictionary
def deserialize_dictObj(strDict, partitions):
  # Remove dict brackets
  strDict = strDict[1:len(strDict)-1]
    
  # Get key/value pairs by exploding on commas
  keyVals = strDict.split(", ")

  # Create new dictionary
  newDict = {}

  # Process each key/Value pair
  for pair in keyVals:
    (key, value) = pair.split(": ",1)
    
    # Convert key to primitive
    if (key[0] == "#"):
      key = deserialize_partitionedObj(key,partitions)
    else:
      key = deserialize_stringToPrimitive(key)
    
    # Convert value to primitive
    if (value[0] == "#"):
      value = deserialize_partitionedObj(value,partitions)
    else:
      value = deserialize_stringToPrimitive(value)
  
    # Add key/value pair
    newDict[key] = value

  return newDict

# Convert a string representation of a list back into a list
def deserialize_listObj(strList, partitions):
  # Remove list brackets
  strList = strList[1:len(strList)-1]

  # Get values by exploding on commas
  values = strList.split(", ")

  # Create new list
  newList = []

  # Process each value
  for value in values:
    # Check for a sub-object filler
    if (value[0] == "#"):
      value = deserialize_partitionedObj(value,partitions)

    # Else this is a primitive type
    else:
      value = deserialize_stringToPrimitive(value)

    # Store the element
    newList.append(value)

  return newList
      
# Convert a string representation of a tuple back into a tuple
def deserialize_tupleObj(strList, partitions):
  # Remove tuple brackets
  strList = strList[1:len(strList)-1]

  # Get values by exploding on commas
  values = strList.split(", ")

  # Create new tuple
  newTuple = ()

  # Process each value
  for value in values:
    # Check for a sub-object filler
    if (value[0] == "#"):
      value = deserialize_partitionedObj(value,partitions)
    
    # Else this is a primitive type
    else:
      value = deserialize_stringToPrimitive(value)
      
    # Store the element
    newTuple += (value,)

  return newTuple  

# Converts a string representation of a list or dictionary 
# back into the real object. This works with sub-lists, sub-dictionaries,
# as well as strings, longs, ints, floats, and bools
def deserialize(string):
  # Array of partitions
  partitions = []
  
  # If there is an error, try to give specific feedback
  # Remove the sub-strings
  try:
    string = deserialize_removeStringObjects(string, partitions)
  except:
    raise ValueError, "Complicated sub-strings failed to parse!"
  
  # Remove the sub-objects
  try:
    string = deserialize_removeObjects(string, partitions)
  except:
    raise ValueError, "Complicated sub-objects failed to parse!"
    
  # Retrieve the top level object
  try:
    root = deserialize_partitionedObj(string, partitions)
  except:
    raise ValueError, "Failed to retrieve top-level object!"
  
  return root
  

#end include deserialize.py

# What should we register as?
NAT_FORWARDER_ADVERTISE_KEY = "__NAT__FORWARDER__"
NAT_SRV_PREFIX = "__NAT_SRV__"

# Limit of forwarder lookups
NAT_MAX_LOOKUP = 50

NAT_ADVERTISE_INTERVAL = 10
NAT_ADVERTISE_TTL = 3*NAT_ADVERTISE_INTERVAL

# Pools the advertisements, so that they can be done in one thread
# Maps key-> value
NAT_ADVERTISE_POOL = {}

# Enable allows toggling of periodic advertisement
# Run controls the advertisement thread, False will stop the thread
NAT_ADVERTISE_STATE = {"enable":False,"run":False}

# Registers the forwarder so that clients using the NATLayer can find us
def nat_forwarder_advertise(ip, serverport, clientport):
  # Generate the value to advertise
  value = ip+"*"+str(serverport)+"*"+str(clientport)
  
  # Add to the advertising pool
  NAT_ADVERTISE_POOL[NAT_FORWARDER_ADVERTISE_KEY] = value


# Advertises a server, so that other NATLayer users can connect
def nat_server_advertise(key, forwarderIP, forwarderCltPort):
  # Generate the value to advertise
  value = forwarderIP+'*'+str(forwarderCltPort)

  # Alter the key, add the prefix
  key = NAT_SRV_PREFIX + key

  # Add to the advertising pool
  NAT_ADVERTISE_POOL[key] = value

# Stops advertising a server key    
def nat_stop_server_advertise(key):
  # Alter the key, add the prefix
  key = NAT_SRV_PREFIX + key
  
  if key in NAT_ADVERTISE_POOL:
    del NAT_ADVERTISE_POOL[key]
    
# Lookup a forwarder so that we can connect
def nat_forwarder_lookup():
  # Get the list of forwarders
  forwarders = centralizedadvertise_lookup(NAT_FORWARDER_ADVERTISE_KEY, NAT_MAX_LOOKUP)

  # Safety check..
  if len(forwarders) <= 1 and forwarders[0] == '':
    raise Exception, "No forwarders could be found!"
  
  # Grab a random forwarder
  index = int(randomfloat() * (len(forwarders)-1))

  # Get the info
  forwarderInfo = forwarders[index]
  
  try:
    (ip,server_port,client_port) = forwarderInfo.split('*')
  except ValueError:
    raise Exception, 'Forwarder lookup returned unexpected value'
  


# Lookup a forwarder so that we can connect
def nat_forwarder_list_lookup():
  # Get the list of forwarders
  forwarders = centralizedadvertise_lookup(NAT_FORWARDER_ADVERTISE_KEY, NAT_MAX_LOOKUP)

  # Safety check..
  if len(forwarders) <= 1 and forwarders[0] == '':
    raise Exception, "No forwarders could be found!"
  

  list = []
  for index in range(len(forwarders)):

    # Get the info
    forwarderInfo = forwarders[index]
  
    try:
      (ip,server_port,client_port) = forwarderInfo.split('*')
    except ValueError:
      raise Exception, 'Forwarder lookup returned unexpected value'
    else:
      list.append((ip,server_port,client_port))
   

  # Return a tuple containing the IP and port for server and client
  return list


# Finds a server using the NATLayer
def nat_server_lookup(key):
  # Get the proper key, add the prefix
  key = NAT_SRV_PREFIX + key

  # Fetch all the keys
  lst = centralizedadvertise_lookup(key, NAT_MAX_LOOKUP)
  num = len(lst)
  
  # Safety check...
  assert(num <= 1)
  if num == 0 or (num == 1 and lst[0] == ''):
    raise Exception, "Host could not be found!"

  # Get the information about the server
  info = lst[0]

  try:
    (forwarder_ip,clt_port) = info.split('*')
  except ValueError:
    raise 'Unexpected value recieved from server lookup'

  # Return a tuple of the forwarder IP port
  return (forwarder_ip, int(clt_port))


def nat_server_list_lookup(key):
  # Get the proper key, add the prefix
  key = NAT_SRV_PREFIX + key

  # Get the list of forwarders
  servers = centralizedadvertise_lookup(key, NAT_MAX_LOOKUP)
  num = len(servers)

  # Safety check...
  assert(num <= 1)
  if num == 0 or (num == 1 and servers[0] == ''):
    raise Exception, "Host could not be found!"
  

  list = []
  for index in range(num):

    # Get the info
    info = servers[index]
  
    try:
      (forwarder_ip,clt_port) = info.split('*')
    except ValueError:
      raise Exception, 'lookup returned unexpected value'
    else:
      list.append((forwarder_ip,clt_port))
   

  # Return a tuple containing the IP and port for server and client
  return list



# Toggles advertisement
# Enable: allows or disallows advertisement of the pool
# threadRun: allows/starts or stops the advertisement thread
def nat_toggle_advertisement(enabled, threadRun=True): 
  NAT_ADVERTISE_STATE["enable"] = enabled
  
  # Start the advertisement thread if necessary
  if not NAT_ADVERTISE_STATE["run"] and threadRun:
    settimer(.1, _nat_advertise_thread, ())
  
  NAT_ADVERTISE_STATE["run"] = threadRun

  
# Launch this thread with settimer to handle the advertisement  
def _nat_advertise_thread():
  while True:
    # Check if advertising is enabled:
    if NAT_ADVERTISE_STATE["enable"]:
      # Advertise everything in the pool
      for (key, val) in NAT_ADVERTISE_POOL.items():
        try:
          centralizedadvertise_announce(key, val, NAT_ADVERTISE_TTL)
        except:
          pass
    
    # Sleep for a while
    sleep(NAT_ADVERTISE_INTERVAL)
              
    # Check if we should terminate
    if not NAT_ADVERTISE_STATE["run"]:
      break


#end include NAT_advertisement.py
#begin include deserialize.py
#already included deserialize.py
#end include deserialize.py
#begin include Multiplexer.py
"""

Author: Armon Dadgar

Start Date: February 16th, 2009

Description:
Provides a means of multiplexing any stream-like connection into a multiple
socket-like connections.

Details:
There are 3 main objects in the Multiplexer
++ MultiplexerFrame
-- This objects is like a meta-"packet" in that it encapsulates a some data with a header
-- The header allows the Multiplexer to route the data to the correct destination

++ Multiplexer
-- This object is takes a single stream-like object that has the properties of being
-- in-order and lossless and multiplexes that single connection into any number of virtual connections.
-- At its heart, there is one thread the socketReader which reads all incoming data and either evaluates control messages
-- or buffers data for clients

++ MultiplexerSocket
-- When the multiplexer creates virtual sockets, a MultiplexerSocket is returned. This socket is tied to its parent multiplexer
-- since that parent buffers all of the incoming data for this socket. 

These three objects are wrapped in several mux_* functions, which abstract the details of the Multiplexer
and provide a repy like interface for easily multiplexing a normal TCP connection. mux_remap can be used to
multiplex any type of connection.

"""

# This is to help send dictionaries as strings
#begin include deserialize.py
#already included deserialize.py
#end include deserialize.py

# Define Module Constants
# 
# How many digits can be used to indicate header length
MULTIPLEXER_FRAME_HEADER_DIGITS = 3 
MULTIPLEXER_FRAME_DIVIDER = ";" # What character is used to divide a frame header

# These are the valid Message Types
MULTIPLEXER_DATA_FORWARD = 0
MULTIPLEXER_CONN_TERM = 1
MULTIPLEXER_CONN_BUF_SIZE = 2
MULTIPLEXER_INIT_CLIENT = 3
MULTIPLEXER_INIT_STATUS = 4

# Special Case
MULTIPLEXER_FRAME_NOT_INIT = -1

# Valid Multiplexer responses to init
MULTIPLEXER_STATUS_CONFIRMED = "CONFIRMED"
MULTIPLEXER_STATUS_FAILED = "FAILED"

# Defines a delay period for the initialization of a multiplexer object
# This is to allow the user to specify waitfunctions before the multiplexer is started
# So that any queued openconn requests are not immediately rejected
MULTIPLEXER_START_DELAY = 1

# Core unit of the Specification, this is used for multiplexing a single connection,
# and for initializing connections
class MultiplexerFrame():
  
  # Set the frame instance variables
  def __init__(self):
    self.headerSize = 0
    self.mesgType = MULTIPLEXER_FRAME_NOT_INIT
    self.contentLength = 0
    self.referenceID = 0
    self.content = ""
    
  # So that we display properly  
  def __repr__(self):
    try:
      return self.toString()
    except AttributeError:
      return "<MultiplexerFrame instance, MULTIPLEXER_FRAME_NOT_INIT>"
    
  def initClientFrame(self,requestedID, remotehost, remoteport, localip, localport):
    """
    <Purpose>
      Makes the frame a MULTIPLEXER_INIT_CLIENT frame

    <Arguments>
      requestedID:
        The requested Identifier for this new virtual socket
      
      ip:
       Our IP address reported to the partner multiplexer
       
      port:
        Our port reported to the partner multiplexer
      
      
    """    
    # Set the requestedID in the frame
    self.referenceID = requestedID
    
    # Set the content as a dict
    requestDict = {'localip':remotehost,'localport':remoteport,'remoteip':localip,'remoteport':localport}
    self.content = str(requestDict)
    self.contentLength = len(self.content)
    
    # Set the correct frame message type
    self.mesgType = MULTIPLEXER_INIT_CLIENT

    
  def initResponseFrame(self,requestedID,response):
    """
    <Purpose>
      Makes the frame a MULTIPLEXER_INIT_STATUS frame

    <Arguments>
      requestedID:
          A reference to the requestedID of the MULTIPLEXER_INIT_CLIENT message
      
      response:
          The response message.
          
    """
    # Set the requestedID in the frame
    self.referenceID = requestedID

    # Set the frame content
    self.content = response
    
    # Set the content length
    self.contentLength = len(self.content)

    # Set the correct frame message type
    self.mesgType = MULTIPLEXER_INIT_STATUS 

  def initDataFrame(self,referenceID, content):
    """
    <Purpose>
      Makes the frame a MULTIPLEXER_DATA_FORWARD frame

    <Arguments>
      referenceID:
            The referenceID that this frame should be routed to.
      content:
            The content that should be sent to the destination.

    """
    # Strip any colons in the mac address
    self.referenceID = referenceID

    # Set the frame content
    self.content = str(content)

    # Set the content length
    self.contentLength = len(self.content)

    # Set the correct frame message type
    self.mesgType = MULTIPLEXER_DATA_FORWARD
  
  
  def initConnTermFrame(self,referenceID):
    """
    <Purpose>
      Makes the frame a MULTIPLEXER_CONN_TERM frame

    <Arguments>
      referenceID:
            The referenceID of the socket that should be disconnected.
       
    """
    # Strip any colons in the mac address
    self.referenceID = referenceID

    # Set the frame content
    self.content = ""

    # Set the content length
    self.contentLength = 0

    # Set the correct frame message type
    self.mesgType = MULTIPLEXER_CONN_TERM
  
  
    
  def initConnBufSizeFrame(self,referenceID, bufferSize):
    """
    <Purpose>
      Makes the frame a MULTIPLEXER_CONN_BUF_SIZE frame

    <Arguments>
      referenceID:
            The referenceID of the scoket that should be altered.
            
      bufferSize:
            The new buffer size for the client.
    
    """
    # Strip any colons in the mac address
    self.referenceID = referenceID

    # Set the frame content, convert the bufferSize into a string
    self.content = str(bufferSize)

    # Set the content length
    self.contentLength = len(self.content)

    # Set the correct frame message type
    self.mesgType = MULTIPLEXER_CONN_BUF_SIZE
  
  
  
  def initFromSocket(self, inSocket):
    """
    <Purpose>
      Constructs a frame object given a socket which contains only frames.

    <Arguments>
      inSocket:
            The socket to read from.
    
    <Exceptions>
      An EnvironmentError will be raised if an unexpected header is received. This could happen if the socket is closed.
    """    
    # Read in the header frame size
    headerSize = inSocket.recv(MULTIPLEXER_FRAME_HEADER_DIGITS+len(MULTIPLEXER_FRAME_DIVIDER))
    headerSize = headerSize.rstrip(MULTIPLEXER_FRAME_DIVIDER)
    
    try:
      headerSize = int(headerSize)-1
    except:
      raise EnvironmentError, "Failed to convert: "+headerSize+" to an integer!"
      
    header = inSocket.recv(headerSize)
    
    if len(header) == headerSize:
      # Setup header
      self._parseStringHeader(header)

      if self.contentLength != 0:
        content = ""  # Store the data we have received so far
        recieved = 0  # Track the amount of data we have
        
        # Loop until we receive all of the data
        while recieved < self.contentLength:
          newContent = inSocket.recv(self.contentLength - recieved)
          newLength = len(newContent)
          
          # Check the length
          if newLength == 0:
            raise EnvironmentError, "Received null dataset!"
          else:
            # Store the new data
            recieved += newLength
            content += newContent
        
        # Assign the content
        self.content = content

    else:
      raise EnvironmentError, "Unexpected Header Size!"
  
  
  
  # Takes a string representing the header, and initializes the frame  
  def _parseStringHeader(self, header):
    # Explode based on the divider
    headerFields = header.split(MULTIPLEXER_FRAME_DIVIDER,2)
    (msgtype, contentlength, ref) = headerFields
    
    try:
      # Convert the types
      msgtype = int(msgtype)
      contentlength = int(contentlength)
    
      # Strip the last semicolon off
      ref = int(ref.rstrip(MULTIPLEXER_FRAME_DIVIDER))
    
      # Setup the Frame
      self.mesgType = msgtype
      self.contentLength = contentlength
      self.referenceID = ref
    except:
      raise EnvironmentError, "Failed to parse header: "+header+" with fields: "+str(headerFields)    
    
    
  def toString(self):
    """
    <Purpose>
      Converts the frame to a string.

    <Exceptions>
      Raises an AttributeError exception if the frame is not yet initialized.
      
    <Returns>
      A string based representation of the string.
    """
    if self.mesgType == MULTIPLEXER_FRAME_NOT_INIT:
      raise AttributeError, "Frame is not yet initialized!"
    
    # Create header
    frameHeader = MULTIPLEXER_FRAME_DIVIDER + str(self.mesgType) + MULTIPLEXER_FRAME_DIVIDER + str(self.contentLength) + \
                  MULTIPLEXER_FRAME_DIVIDER + str(self.referenceID) + MULTIPLEXER_FRAME_DIVIDER
    
    # Determine variable header size
    headerSize = str(len(frameHeader)).rjust(MULTIPLEXER_FRAME_HEADER_DIGITS,"0")
    
    if len(headerSize) > MULTIPLEXER_FRAME_HEADER_DIGITS:
      raise AttributeError, "Frame Header too large! Max:"+ MULTIPLEXER_FRAME_HEADER_DIGITS+ " Actual:"+ len(headerSize)
    
    return  headerSize + frameHeader + self.content
    


# This helps abstract the details of a Multiplexed connection    
class Multiplexer():
  
  def __init__(self, socket, info={}):
    """
    <Purpose>
      Initializes the Multiplexer object.
     
    <Arguments>
      socket:
        Socket like object that is used for multiplexing
      
      info:
        A dictionary object. Its key/value pairs will be injected into mux.socketInfo.
        This can be used to store custom data, or to override localip, localport, remoteip, and remoteport.
        It is optional.
    """    
    # If we are given a socket, assume it is setup
    if socket != None:
      # Is everything setup?
      self.connectionInit = True 

      # Default incoming and outgoing buffer size expansion value
      # Defaults to 128 kilobytes
      self.defaultBufSize = 128*1024

      # This is the main socket
      self.socket = socket 

      # This dictionary contains information about this socket
      # This just has some junk default values, and is filled in during init
      self.socketInfo = {"localip":"127.0.0.1","localport":0,"remoteip":"127.0.0.1","remoteport":0}

      # Locks, this is to make sure only one thread is reading or writing at any time
      self.readLock = getlock()
      self.writeLock = getlock()

      # Callback function that is passed a socket object
      # Maps a host (e.g. 127.0.0.1) to a dictionary of ports -> functions
      # So  callBackFunctions["127.0.0.1"][50] returns the user function for host 127.0.0.1 port 50
      self.callbackFunction = {}

      # This dictionary keeps track of sockets we are waiting to open, e.g. openconn has been called
      # but the partner multiplexer has not responded yet
      self.pendingSockets = {}

      # If we want a new client, what number should we request?
      self.nextReferenceID = 0

      # A dictionary that associates reference ID's to their MultiplexerSocket objects
      self.virtualSockets = {}
      self.virtualSocketsLock = getlock()  
      
      # Inject or override socket info given to use
      for key, value in info.items():
        self.socketInfo[key] = value
    
      # Set error if one occurs in socketReader
      self.error = None
      
      # Callback function in case of fatal error
      self.errorDelegate = None
        
      # Launch event to handle the multiplexing
      # Wait a few seconds so that the user has a chance to set waitforconn
      settimer(MULTIPLEXER_START_DELAY, self._socketReader, ())
      
    else:
      raise ValueError, "Must pass in a valid socket!"
  
  # So that we display properly  
  def __repr__(self):
    # Format a nice string with some of our info
    return "<Multiplexer setup:"+str(self.isAlive())+ \
    " buf_size:"+str(self.defaultBufSize)+ \
    " counter:"+str(self.nextReferenceID)+ \
    " info:"+str(self.socketInfo)+">"
  
  
  # Returns the status of the multiplexer
  def isAlive(self):
    """
    <Purpose>
      Returns the status of the multiplexer. Since the multiplexer is mostly handled by internal threads,
      user programs will not receive exceptions on a fatal error, like the underlying socket closing.
      This function returns the status, or setErrorDelegate can be used to be informed proactively.
  
   <Returns>
    True, if the multiplexer is alive and functional. False otherwise.      
    """
    # Just use connectionInit, that is our internal variable
    return self.connectionInit
          
          
  # Closes the Multiplexer, and cleans up
  def close(self, closeSocket=True):
    """
    <Purpose>
      Closes the Multiplexer object. Also closes all virtual sockets associated with this connection.
      
    <Arguments>
      closeSocket:
        If true, the master socket will be closed as well.
    """
    # Prevent more reading or writing
    try:
      self.readLock.release()
    except:
      # See below
      pass
    finally:
      self.readLock.acquire()
    
    try:
      self.writeLock.release()
    except:
      # Exception is thrown if the lock is already unlocked
      pass
    finally:
      self.writeLock.acquire()
    
    # The Mux is no longer initialized
    self.connectionInit = False
     
    # Close each individual socket
    for refID, sock in self.virtualSockets.items():
      self._closeCONN(sock, refID) 
    
    # Close the real socket
    if closeSocket and self.socket != None:
      self.socket.close()
      self.socket = None
    
    # Cancel all pending sockets, this is so they get
    # connection refused instead of timed out
    for refID, info in self.pendingSockets.items():
      # Cancel the timeout timer
      canceltimer(info[2])
    
      # Set the handle to None, so that Connection Refused is infered
      info[2] = None
    
      # Unblock openconn
      try:
        info[1].release()
      except:
        pass
    
    # Check if we have an error delegate and an error
    if self.error != None and self.errorDelegate != None:
      # Call the error delegate, with self and the error
      self.errorDelegate(self, self.error[0], self.error[1])
      
      # Remove the error, to prevent multiple notifications
      self.error = None

      
  # Stops additional listener threads
  def stopcomm(self,handle):
    """
    <Purpose>
      Stops listening for the selected waithandle
      
    <Arguments>
      handle:
        A handle returned from waitforconn
      
    """
    # Convert handle back to tuple, unpack it
    (ip, port) = deserialize(handle)
    
    # Deletes the callback function on the specified port
    if ip in self.callbackFunction and port in self.callbackFunction[ip]:
      del self.callbackFunction[ip][port]
    
  # Private: Recieves a single frame 
  def _recvFrame(self):
    # Check if we are initialized
    if not self.isAlive():
      raise AttributeError, "Multiplexer is not yet initialized or is closed!"
            
    # Init frame
    frame = MultiplexerFrame()
    
    try:
      # Get the read lock
      self.readLock.acquire()
      
      # Construct frame, this blocks
      frame.initFromSocket(self.socket)
   
    except Exception, exp:
      # Store the error
      self.error = ("_recvFrame", exp)
      
      # We need to close the multiplexer
      self.close()
      
      # Re-raise the exception
      raise EnvironmentError, "Fatal Error:"+str(exp)

    # Release the lock
    self.readLock.release()
    
    # Return the frame
    return frame

  # Private: Sends a single frame
  def _sendFrame(self,frame):
    # Check if we are initialized
    if not self.isAlive():
      raise AttributeError, "Multiplexer is not yet initialized or is closed!"
    
    try:
      # Get the send lock
      self.writeLock.acquire()

      # Send the frame!
      self.socket.send(frame.toString())
    
    except Exception, exp:
      # Store the error
      self.error = ("_sendFrame", exp)
      
      # We need to close the multiplexer
      self.close()
      
      # Re-raise the exception
      raise EnvironmentError, "Fatal Error:"+str(exp)
        
    # release the send lock
    self.writeLock.release()
   
  def _send(self,referenceID, data):
    """
    <Purpose>
      Sends data as a frame over the socket.
      
    <Arguments>
      referenceID:
        The target to send the data to.
       
      data:
        The data to send to the target.
        
    <Exceptions>
      If the connection is not initialized, an AttributeError is raised. Socket error can be raised if the socket is closed during transmission.
    """
    # Build the frame
    frame = MultiplexerFrame()
    
    # Initialize it
    frame.initDataFrame(referenceID, data)
    
    # Send it!
    self._sendFrame(frame)

  def openconn(self, desthost, destport, localip=None,localport=None,timeout=15):
    """
    <Purpose>
      Opens a connection, returning a socket-like object

    <Arguments>
      See repy's openconn

    <Side Effects>
      None

    <Returns>
      A socket like object.
    """    
    # Check if we are initialized
    if not self.isAlive():
      raise AttributeError, "Multiplexer is not yet initialized or is closed!"
    
    # Check for default values
    if localip == None:
      localip = self.socketInfo["localip"]
      
    if localport == None:
      localport = self.socketInfo["localport"]
    
    # Create an MULTIPLEXER_INIT_CLIENT frame
    frame = MultiplexerFrame()
    
    # Get a new id
    requestedID = self.nextReferenceID
    
    # Increment the counter
    self.nextReferenceID = self.nextReferenceID + 1
    
    # Setup the frame
    frame.initClientFrame(requestedID, desthost, destport, localip, localport)
    
   
    
    # Add this request to the pending sockets, add a bool to hold if this was successful, and a lock that we use for blocking
    # The third element is a timer handle, that is used for the timeout
    self.pendingSockets[requestedID] = [False, getlock(), None]
    
    # Send the request
    self._sendFrame(frame)

    # Now we block until the request is handled, or until we reach the timeout
    
    # Set a timer to unblock us after a timeout
    self.pendingSockets[requestedID][2] = settimer(timeout, self._openconn_timeout, [requestedID])
    
    # Acquire the lock twice, and wait for it to be release
    self.pendingSockets[requestedID][1].acquire()
    self.pendingSockets[requestedID][1].acquire()
    
    # Were we successful?
    success = self.pendingSockets[requestedID][0]
    
    # Get the timer handle
    handle = self.pendingSockets[requestedID][2]
    
    # Remove the request
    del self.pendingSockets[requestedID]
    
    # At this point we've been unblocked, so were we successful?
    if success:
      # Create info dictionary
      info  = {"localip":localip,"localport":localport,"remoteip":desthost,"remoteport":destport}
      
      # Return a virtual socket
      socket = MultiplexerSocket(requestedID, self, self.defaultBufSize, info)
      
      # By default there is no data, so set the lock
      socket.socketLocks["nodata"].acquire()
      
      # Lock the virtual sockets dictionary
      self.virtualSocketsLock.acquire()
      
      # Create the entry for it, add the data to it
      self.virtualSockets[requestedID] = socket
      
      # Release the dictionary lock
      self.virtualSocketsLock.release()
      
      return socket
      
    # We failed or timed out  
    else:
      if handle == None:
        # Our partner responded, but not with MULTIPLEXER_STATUS_CONFIRMED
        raise EnvironmentError, "Connection Refused!"
      else:
        # Our connection timed out
        raise EnvironmentError, "Connection timed out!"
      
  
  # Unblocks openconn after a timeout
  def _openconn_timeout(self, refID):
    # Release the socket, so that openconn can continue execution
    try:
      self.pendingSockets[refID][1].release()
    except:
      # This is just to be safe
      pass
    
  def waitforconn(self, localip, localport, function):
    """
    <Purpose>
      Waits for a connection to a port. Calls function with a socket-like object if it succeeds.

    <Arguments>
      localip:
        The local IP to listen on

      localport:
        The local port to bind to
    
      function:
        The function to call. It should take four arguments: (remoteip, remoteport, socketlikeobj, None, multiplexer)
        If your function has an uncaught exception, the socket-like object it is using will be closed.

    <Side Effects>
      Starts an event handler that listens for connections.

    <Returns>
      A handle that can be used with stopcomm
    """
    # Check if we are initialized
    if not self.isAlive():
      raise AttributeError, "Multiplexer is not yet initialized or is closed!"
      
    # Check if this is a new host, make a new dictionary
    if not localip in self.callbackFunction:
      self.callbackFunction[localip] = {}
        
    # Setup the user function to call if there is a new client
    self.callbackFunction[localip][localport] = function
     
    # Generate a handle, string version of tuple (ip, port)
    return str((localip,localport))
  
  
  # Handles a client closing a connection
  def _closeCONN(self,socket, refID):    
    # Close the socket
    socket.socketInfo["closed"] = True
    
    # Release the client sockets nodata and sending locks, so that they immediately see the message
    # Wrap in try/catch since release will fail on a non-acquired lock
    try:
      socket.socketLocks["nodata"].release()
    except:
      pass
    
    try:
      socket.socketLocks["outgoing"].release()
    except:
      pass
    
    

  # Handles a MULTIPLEXER_CONN_BUF_SIZE message
  # Increases the amount we can send out
  def _conn_buf_size(self,socket, num):
    # Acquire a lock for the socket
    socket.socketLocks["send"].acquire()
    
    # Increase the buffer size
    socket.bufferInfo["outgoing"] = num
    
    # Release the outgoing lock, this unblocks socket.send
    try:
      socket.socketLocks["outgoing"].release()
    except:
      # That means the lock was already released
      pass
    
    # Release the socket
    socket.socketLocks["send"].release()
    
  # Handles a new client connecting
  def _new_client(self, frame, refID):
    # Do an internal error check
    if self._virtualSock(refID) != None:
      raise Exception, "Attempting to connect with a used reference ID!"
    
    # Get the request info
    id = frame.referenceID    # Get the ID from the frame
    info = deserialize(frame.content)   # Get the socket info from
    
    # What port are they trying to connect to?
    requestedHost = info["localip"]
    requestedPort = info["localport"]
      
    # Check for a callback function
    if requestedHost in self.callbackFunction and requestedPort in self.callbackFunction[requestedHost]:
      userfunc = self.callbackFunction[requestedHost][requestedPort]
    
    # Send a failure message and return
    else:
      # Respond to our parter, send a failure message
      resp = MultiplexerFrame()
      resp.initResponseFrame(id,MULTIPLEXER_STATUS_FAILED)
      self._sendFrame(resp)
      return
    
    # Get the main dictionary lock
    self.virtualSocketsLock.acquire()
    
    # Create the socket
    socket = MultiplexerSocket(id, self, self.defaultBufSize, info)
    
    # We need to increase our reference counter now, so as to prevent duplicates
    self.nextReferenceID = id + 1
    
    # Respond to our parter, send a success message
    resp = MultiplexerFrame()
    resp.initResponseFrame(id,MULTIPLEXER_STATUS_CONFIRMED)
    self._sendFrame(resp)
    
    # Create the entry for it, add the data to it
    self.virtualSockets[refID] = socket
    
    # By default there is no data, so set the lock
    socket.socketLocks["nodata"].acquire()
    
    # If the frame is a data frame, add the data
    if frame.mesgType == MULTIPLEXER_DATA_FORWARD:
      self._incoming_client_data(frame, socket)
    
    # Release the main dictionary lock
    self.virtualSocketsLock.release()
    
    # Make sure the user code is safe, launch an event for it
    try:
      settimer(0, userfunc, (info["remoteip"], info["remoteport"], socket, None, self))
    except:      
      # Close the socket
      socket.close()
      
  
  # Handles incoming data for an existing client
  def _incoming_client_data(self, frame, socket):
    # Acquire a lock for the socket
    socket.socketLocks["recv"].acquire()
    
    # Increase the buffer size
    socket.buffer += frame.content
    
    # Release the outgoing lock, this unblocks socket.send
    try:
      socket.socketLocks["nodata"].release()
    except:
      # That means the lock was already released
      pass
    
    # Release the socket
    socket.socketLocks["recv"].release()
    
  
  # Handles MULTIPLEXER_INIT_STATUS messages for a pending client
  def _pending_client(self, frame, refID):
    # Return if the referenced client is not in the pending list
    if not (refID in self.pendingSockets):
      return
    
    # Cancel the timeout timer
    canceltimer(self.pendingSockets[refID][2])
    
    # Set the handle to None
    self.pendingSockets[refID][2] = None
      
    # Has our partner confirmed the connection? If so, then update the pending socket
    if frame.content == MULTIPLEXER_STATUS_CONFIRMED:
      self.pendingSockets[refID][0] = True
    
    # Unblock openconn
    try:
      self.pendingSockets[refID][1].release()
    except:
      pass
  
  # Simple function to determine if a client is connected,
  # and if so returns their virtual socket
  def _virtualSock(self,refID):
    # Get the main dictionary lock
    self.virtualSocketsLock.acquire()
    
    if refID in self.virtualSockets:
      sock = self.virtualSockets[refID]
    else:
      sock = None
    
    # Release the main dictionary lock
    self.virtualSocketsLock.release()
       
    return sock
     
  # This is launched as an event to handle multiplexing the connection
  def _socketReader(self):
    # If this thread crashes, close the multiplexer
    try:
      # This thread is responsible for reading all incoming frames,
      # so it pushes data into the buffers, initializes new threads for each new client
      # and handles all administrative frames
      while True:
        # Should we quit?
        if not self.isAlive():
          break
      
        # Read in a frame
        try:
          frame = self._recvFrame()
          refID = frame.referenceID
          frameType = frame.mesgType
        except:
          # This is probably because the socket is now closed, so lets loop around and see
          continue
      
        # It is possible we recieved a close command while doing recv, so lets check again and handle this
        if not self.isAlive():
          break 
      
        # Get the virtual socket if it exists
        socket = self._virtualSock(refID)
      
        # Handle MULTIPLEXER_INIT_CLIENT
        if frameType == MULTIPLEXER_INIT_CLIENT:
          self._new_client(frame, refID)
      
        # Handle MULTIPLEXER_INIT_STATUS
        elif frameType == MULTIPLEXER_INIT_STATUS:
          self._pending_client(frame, refID)
        
        # Handle MULTIPLEXER_CONN_TERM
        elif frameType == MULTIPLEXER_CONN_TERM:
          # If the socket is none, that means this client is already terminated
          if socket != None: 
            self._closeCONN(socket, refID)
      
        # Handle MULTIPLEXER_CONN_BUF_SIZE
        elif socket != None and frameType == MULTIPLEXER_CONN_BUF_SIZE:
          self. _conn_buf_size(socket, int(frame.content))
          
        # Handle MULTIPLEXER_DATA_FORWARD
        elif frameType == MULTIPLEXER_DATA_FORWARD:
          # Does this client socket exists? If so, append to their buffer
          # This is a new client, we need to call the user callback function
          if socket == None:
            self._new_client(frame, refID)
          else:
            self._incoming_client_data(frame,socket)
      
        # We don't know what this is, so panic    
        else:
          raise Exception, "Unhandled Frame type: "+ str(frame)
    
    # We caught an exception, close the multiplexer and exit
    except Exception, err:
      # Store the error
      self.error = ("_socketReader", err)
      
      # Close
      self.close()
      
  
  def setErrorDelegate(self, func):
    """
    <Purpose>
      Allows a user-defined function to be notified if the Multiplexer is closed internally, without a call to close().
      
    <Arguments>
      func:
        The user function to be called after close() is completed due to an error condition.
        The function should take the following arguments:
        -mux : A reference to the multiplexer object
        -location : A string reference to the point of failure
        -exp : The actually exception that caused the internal failure
    
      Set the func to None to disable the error delegation.
        
    <Returns>
      None.
    """
    # Assign the user function to the internal callback handle
    self.errorDelegate = func
    

# A socket like object with an understanding that it is part of a Multiplexer
# Has the same functions as the socket like object in repy
class MultiplexerSocket():  
  
  def __init__(self, id, mux, buf, info):
    # Initialize
    
    # Reference ID
    self.id = id
    
    # Pointer to the master Multiplexer
    self.mux = mux
    
    # Socket information
    self.socketInfo = {"closed":False,"localip":"","localport":0,"remoteip":"","remoteport":0}
    
    # Actual buffer of unread data
    self.buffer = ""
    
    # Buffering Information
    self.bufferInfo = {"incoming":buf,"outgoing":buf}

    # Various locks used in the socket
    self.socketLocks = {"recv":getlock(),"send":getlock(),"nodata":getlock(),"outgoing":getlock()}
    
    # Inject or override socket info given to use
    for key, value in info.items():
      self.socketInfo[key] = value
  
  def close(self):
    """
    <Purpose>
      Closes the socket. This will close the client connection if possible.
      
    <Side effects>
      The socket will no longer be usable. Socket behavior is undefined after calling this method,
      and most likely Runtime Errors will be encountered.
    """
    # If the Multiplexer is still initialized, then lets send a close message
    if self.mux != None and self.mux.isAlive():
      # Create termination frame
      termFrame = MultiplexerFrame()
      termFrame.initConnTermFrame(self.id)
      
      # Tell our partner to terminate the client connection
      self.mux._sendFrame(termFrame)
    
    # Remove from the list of virtual sockets
    if self.mux != None:
      self.mux.virtualSocketsLock.acquire()
      del self.mux.virtualSockets[self.id]
      self.mux.virtualSocketsLock.release()
    
    # Clean-up
    self.mux = None
    self.socketInfo = None
    self.buffer = None
    self.bufferInfo = None
    self.socketLocks = None
  
  # Checks if the socket is closed, and handles it
  def _handleClosed(self):
    # Check if the socket is closed from the other side  
    if self.socketInfo["closed"] and len(self.buffer) < 1:
      self.close() # Clean-up
      raise EnvironmentError, "The socket has been closed!"
    elif self.socketInfo["closed"]:
      # raise the exception, but dont kill the socket, it can still return data to recv
      raise EnvironmentError, "The socket has been closed!"
    
    
    # handle the case where the socket was closed and recv is called
  def _handleClosed_recv(self):  
    if self.socketInfo["closed"] and len(self.buffer) < 1:
      self.close() # Clean-up
      raise EnvironmentError, "The socket has been closed!"
    
    
    
    
  def recv(self,bytes,blocking=False):
    """
    <Purpose>
      To read data from the socket. This operation will block until some data is available. It will not block if some, non "bytes" amount is available. 
    
    <Arguments>
      bytes:
        Read up to "bytes" input. Positive integer.
    
      blocking
        Should the operation block until all "bytes" worth of data are read.
        
    <Exceptions>
      If the socket is closed, an EnvironmentError will be raised. If bytes is a non-positive integer, a ValueError will be raised.
        
    <Returns>
      A string with length up to bytes
    """
    # Check input sanity
    if bytes <= 0:
      raise ValueError, "Must read a positive integer number of bytes!"
        
    # Check if the socket is closed
    self._handleClosed_recv()
        
    # Block until there is data
    # This lock is released whenever new data arrives, or if there is data remaining to be read
    self.socketLocks["nodata"].acquire()
    try:
      self.socketLocks["nodata"].release()
    except:
      # Some weird timing issues can cause an exception, but it is harmless
      pass
    
    # Check if the socket is closed
    self._handleClosed_recv()
            
    # Get our own lock
    self.socketLocks["recv"].acquire()
  
    # Read up to bytes
    data = self.buffer[:bytes] 
    amountIn = len(data)
    
    # Remove what we read from the buffer
    self.buffer = self.buffer[bytes:] 
  
    # Reduce amount of incoming data available
    self.bufferInfo["incoming"] -= amountIn
  
    # Check if there is more incoming buffer available, if not, send a MULTIPLEXER_CONN_BUF_SIZE
    # This does not count against the outgoingAvailable quota
    if self.bufferInfo["incoming"] <= 0:
      # Create MULTIPLEXER_CONN_BUF_SIZE frame
      buf_frame = MultiplexerFrame()
      buf_frame.initConnBufSizeFrame(self.id, self.mux.defaultBufSize)
      
      # Send it
      try:
        self.mux._sendFrame(buf_frame)
      except:
        # The multiplexer may be closed
        # Check if the socket is closed
        self._handleClosed()
      
      # Increase our incoming buffer
      self.bufferInfo["incoming"] = self.mux.defaultBufSize
    
    # Set the no data lock if there is none
    if len(self.buffer) == 0:
      self.socketLocks["nodata"].acquire()
      
    # Release the lock
    self.socketLocks["recv"].release() 
    
    # Are we supposed to block?
    if blocking and amountIn < bytes:
      # How much more do we need?
      more = bytes - amountIn
      
      # Try to recieve the extra, recursively call ourself
      moreData = self.recv(more, True)
      
      # Return the original data, plus the extra
      return (data + moreData)
    # Otherwise, just return what we have
    else:
      return data

  def send(self,data):
    """
    <Purpose>
      To send data over the socket. This operation will block. 
    
    <Arguments>
      data:
        Send string data over the socket.
    
    <Exceptions>
      If the socket is closed, an EnvironmentError will be raised.
      If the data input is empty, a ValueError will be raised.
      
    """
    # Get the data length
    fullDataLength = len(data)
    
    # Input sanity
    if fullDataLength == 0:
      raise ValueError, "Cannot send a null data-set!"
        
    # Send chunks of data until it is all sent
    while True:
      # Check if the socket is closed
      self._handleClosed()
        
      # Make sure we have available outgoing bandwidth
      self.socketLocks["outgoing"].acquire()
      try:
        self.socketLocks["outgoing"].release()
      except:
        # Some weird timing issues can cause an exception, but it is harmless
        pass
      
      # Check if the socket is closed
      self._handleClosed()
        
      # Get our own lock
      self.socketLocks["send"].acquire()
      
      # How much outgoing traffic is available?
      outgoingAvailable = self.bufferInfo["outgoing"]
      
      # If we can, just send it all at once
      if len(data) < outgoingAvailable:
        try:
          # Instruct the multiplexer object to send our data
          self.mux._send(self.id, data)
        except AttributeError:
          # The multiplexer may be closed
          # Check if the socket is closed
          self._handleClosed()
        
        # Reduce the size of outgoing avail
        self.bufferInfo["outgoing"] -= len(data)
        
        # Release the lock
        self.socketLocks["send"].release()
          
        # We need to explicitly leave the loop
        break
        
      # We need to send chunks, while waiting for more outgoing B/W
      else:
        # Get a chunk of data, and send it
        chunk = data[:outgoingAvailable]
        try:
          # Instruct the multiplexer object to send our data
          self.mux._send(self.id, chunk)
        except AttributeError:
          # The multiplexer may be closed
          # Check if the socket is closed
          self._handleClosed()
      
        # Reduce the size of outgoing avail
        self.bufferInfo["outgoing"] = 0

        # Lock the outgoing lock, so that we block until we get a MULTIPLEXER_CONN_BUF_SIZE message
        self.socketLocks["outgoing"].acquire()
      
        # Trim data to only what isn't sent syet
        data = data[outgoingAvailable:]
    
        # Release the lock
        self.socketLocks["send"].release()
        
        # If there is no data left to send, then break
        if len(data) == 0:
          break
    
    # Return bytes sent, which is always the full message
    # since we will block indefinately until everything is sent.
    return fullDataLength

# Functional Wrappers for the Multiplexer objects

# This dictionary object links IP's to their respective multiplexer
MULTIPLEXER_OBJECTS = {}

# This dictionary has data about the underlying waitforconn operations
MULTIPLEXER_WAIT_HANDLES = {}

# This function has the underlying function calls
MULTIPLEXER_FUNCTIONS = {}

# Setup function pointers to be used by the multiplexer wrappers
MULTIPLEXER_FUNCTIONS["waitforconn"] = waitforconn
MULTIPLEXER_FUNCTIONS["openconn"] = openconn
MULTIPLEXER_FUNCTIONS["stopcomm"] = stopcomm
MULTIPLEXER_FUNCTIONS["errdelegate"] = None # What function is used to handle error delegation, _mux_error_delegate is default

# This dictionary has all of the virtual waitforconn functions to propagate waitforconn to new muxes
# E.g. if a new host connects, it inherits all of the waitforconns on the existing muxes
MULTIPLEXER_WAIT_FUNCTIONS = {}

# Openconn that uses Multiplexers
def mux_openconn(desthost, destport, localip=None,localport=None,timeout=15,virtualport=None):
  """
  <Purpose>
    Opens a multiplexed connection to a remote host, and returns a virtual socket.
  
  <Arguments>
    desthost
      The IP address of the host to connect to.
    
    destport
      The port of the remote host to connect to.
      
    localip
      The localip to use when connecting to the remote host
    
    localport
      The localport to use when connecting to the remote host
    
    timeout
      How long before timing out the connection
  
    virtualport
      Specify a virtual port to connect to, defaults to the destport
      
  <Exceptions>
    See openconn.
  
  <Side effects>
    If this is the first connect to the remote host, an additional event will be used to establish the multiplexing
  
  <Returns>
    A socket-like object that supports close, send, and recv
  
  <Remarks>
    If there is no multiplexed connection pre-established, an attempt will be made to establish a new connection.
    If a connection is already established, then only a virtual socket will be opened.
  """
  # Use the destport by default for the virtualport
  if virtualport == None:
    virtualport = destport
    
  # Check if we already have a real multiplexer
  key = "IP:"+desthost+":"+str(destport)
  if key in MULTIPLEXER_OBJECTS:
    # Check if the multiplexer is still initialized
    status = MULTIPLEXER_OBJECTS[key].isAlive()
    
    # If the mux is not still initialized, then remove it and call ourselves again
    if not status:
      del MULTIPLEXER_OBJECTS[key]
      
      # Recursive call will re-initialize the mux
      return mux_openconn(desthost, destport, localip,localport,timeout,virtualport)
    
    # Since a connection already exists, do a virtual openconn
    else:
      return mux_virtual_openconn(desthost, destport, virtualport, localip,localport,timeout)

    # We need to establish a new multiplexer with this host
  else:
    # Get the correct function
    openconn_func = MULTIPLEXER_FUNCTIONS["openconn"]

    # Try to get a real socket
    if localport != None and localip != None:
      realsocket = openconn_func(desthost, destport, localip,localport,timeout)
    else:
      realsocket = openconn_func(desthost, destport,timeout=timeout)
      
    # Setup the info for this new mux, give the mux its key
    info = {"remoteip":desthost,"remoteport":destport,"key":key}

    # Get an IP if necessary
    if localip == None:
      try:
        # Otherwise, use getmyip
        info["localip"] = getmyip()
        
        # On failure, use a local loopback ip
      except:
        info["localip"] = "127.0.0.1"

    # If we already have a user given localip, use that
    else:
      info["localip"] = localip

    # Did the use give us a real port?	
    if localport != None:
      info["localport"] = localport

    # Make a mux with this new socket
    mux = Multiplexer(realsocket, info)

    # Assign the error delegate, in case of a fatal internal error
    mux.setErrorDelegate(MULTIPLEXER_FUNCTIONS["errdelegate"])
    
    # Add the key entry for this mux
    MULTIPLEXER_OBJECTS[key] = mux

    # Map the old waitforconn's
    _helper_map_existing_waits(mux)
    
    # Now call openconn on the mux to get a virtual socket
    return mux.openconn(desthost, virtualport, localip,localport,timeout)

# Helper function for mux_waitforconn, handles everything then calls user function
def _helper_mux_waitforconn(ip, port, func, remoteip, remoteport, socket, thiscommhandle, listencommhandle):
  # Create key for this new mux
  key = "IP:"+remoteip+":"+str(remoteport)
	
  # Generate connection info
  info = {"remoteip":remoteip,"remoteport":remoteport,"localip":ip,"localport":port,"key":key}
  
  # Create a mux
  mux = Multiplexer(socket, info)
  
  # Assign the error delegate, in case of a fatal internal error
  mux.setErrorDelegate(MULTIPLEXER_FUNCTIONS["errdelegate"])
  
  # Add the key entry for this mux
  MULTIPLEXER_OBJECTS[key] = mux
  
  # Map all virtual waitforconn's to this mux
  _helper_map_existing_waits(mux)
  

# Helper function to map pre-existing waitforconn's to a new multiplexer
def _helper_map_existing_waits(mux):
  # Apply the old waitforconns
  for (key, function) in MULTIPLEXER_WAIT_FUNCTIONS.items():
    (ip, port) = deserialize(key)
    mux.waitforconn(ip, port, function)

# Wait for connection to establish new multiplexers and new virtual connections
def mux_waitforconn(localip, localport, function):
  """
  <Purpose>
    Sets up an event handler for an incoming connection. The connection will be multiplexed.
    
  <Arguments>
    localip
      The IP address to listen on
    
    localport
      The port to listen on
    
    function
      The user function to call when a new connection is established. This function should take the following parameters:
        remoteip   : The IP address of the remote host
        remoteport : The port of the remote host for this connection
        socket     : A socket like object that supports close,send,recv
        thiscommhandle   : Nothing, this should not be used
        listencommhandle : A reference to the parent multiplexer
  
  <Exceptions>
    See waitforconn.
  
  <Returns>
    A handle that can be used with mux_stopcomm to stop listening on this port for new connections.
  """
  # Get the key
  key = "LISTEN:"+str((localip,localport))
  
  # Does this key already exist?
  if key in MULTIPLEXER_WAIT_HANDLES:
    # Stop the last waitforconn, then make a new one
    mux_stopcomm(key)
    
  # Get the correct function
  waitforconn_func = MULTIPLEXER_FUNCTIONS["waitforconn"]
  
  # This adds ip and port and function information to help with multiplex waitforconns
  def _add_ip_port_func(remoteip, remoteport, socket, thiscommhandle, listencommhandle):
    _helper_mux_waitforconn(localip, localport, function, remoteip, remoteport, socket, thiscommhandle, listencommhandle)
  
  # Call waitforconn, and trigger our helper
  handle = waitforconn_func(localip, localport, _add_ip_port_func)
  
  # Register the handle
  MULTIPLEXER_WAIT_HANDLES[key] = handle
  
  # Do a virtual waitforconn as well as the real one
  mux_virtual_waitforconn(localip, localport, function)

  # Return the key
  return key


# Stops waiting for new connections
def mux_stopcomm(key):
  """
  <Purpose>
    Stops waiting for new clients
  
  <Arguments>
    key:
      Key returned by mux_waitforconn
  
  <Side effects>
    New connections will no longer trigger the user function.
  
  <Returns>
    None
  """
  # Is this a real handle?
  if key in MULTIPLEXER_WAIT_HANDLES:
    # Retrieve the handle
    handle = MULTIPLEXER_WAIT_HANDLES[key]
    
    # Call stopcomm on it
    stopcomm_func = MULTIPLEXER_FUNCTIONS["stopcomm"]
    
    # Stopcomm
    stopcomm_func(handle)
    
    # Delete the handle
    del MULTIPLEXER_WAIT_HANDLES[key]

    # Get the values by spliting on colon
    arr = key.split(":")
    virtualkey = arr[1]

    # Propogate this stopcomm virtually
    mux_virtual_stopcomm(virtualkey)


# Changes the underlying hooks that the mux wrappers use
def mux_remap(wait, open, stop):
  """
  <Purpose>
    Remaps the underlying calls used by mux_openconn, mux_waitforconn, and mux_stopcomm
    
  <Arguments>
    wait:
      The underlying waitforconn function to use
    
    open:
      The underlying openconn function to use
    
    stop:
      The underlying stopcomm function to use
    
  <Returns>
    None
  """
  MULTIPLEXER_FUNCTIONS["waitforconn"] = wait
  MULTIPLEXER_FUNCTIONS["openconn"] = open
  MULTIPLEXER_FUNCTIONS["stopcomm"] = stop


# This function will only do a virtual opeconn, and will not attempt to establish a new connection
def mux_virtual_openconn(desthost, destport, virtualport, localip=None,localport=None,timeout=15):
  """
  <Purpose>
    Opens a new virtual socket on an existing multiplexed connection.
  
  <Arguments>
    desthost
      The IP address of the host machine, to which there is an existing connection
    
    destport
      The real port of the remote host with the multiplexed connection
    
    virtualport
      The virtualport to connect to on the remote host
    
    localip
      The localip to report to the remote host
    
    localport
      The localport to report to the remote host
    
    timeout
      How long before timing out the connection
  
  <Exceptions>
    Raises a ValueError if there is no pre-existing connection to the requested host
  
  <Returns>
    A socket-like object. See mux_openconn.
  """
  # Get the key to the existing multiplexer
  key = "IP:"+desthost+":"+str(destport)
  
  if key in MULTIPLEXER_OBJECTS:
    # Since a multiplexer already exists, lets just use that objects builtin method
    mux = MULTIPLEXER_OBJECTS[key]

    try:
      return mux.openconn(desthost, virtualport, localip,localport,timeout)
    except AttributeError, err:
      if str(err) == "Multiplexer is not yet initialized or is closed!":
        # There has been a fatal error in this multiplexer, delete it
        del MULTIPLEXER_OBJECTS[key]
        
      raise EnvironmentError, "Connection Refused!"
      
  else:
    raise ValueError, "There is no pre-existing connection to the requested host!"
    

# This function will only affect multiplexers, and does not listen on real ports
def mux_virtual_waitforconn(localip, localport, function):
  """
  <Purpose>
    Similar to mux_waitforconn, however it only waits on virtual ports and not on real ports.
  
  <Arguments>
    localip
      The localip to listen on. This will be ignored, and the port will be mapped to all multiplexers.
    
    localport
      What port the multiplexers should respond on
    
    function
      What function should be triggered by connections on localport
  
  <Side effects>
    All multiplexers will begin waiting on the local port
  
  <Returns>
    A handle that can be used with mux_virtual_stopcomm
  """
  # Generate a key
  key = str((localip, localport))
  
  # Register the ip/port function for new multiplexers
  MULTIPLEXER_WAIT_FUNCTIONS[key] = function
  
  # Map this waitforconn to all existing multiplexers
  for (key, mux) in MULTIPLEXER_OBJECTS.items():
    try:
      mux.waitforconn(localip, localport, function)
    except AttributeError, err:
      if str(err) == "Multiplexer is not yet initialized or is closed!":
        # There has been a fatal error in this multiplexer, delete it
        del MULTIPLEXER_OBJECTS[key]
      else:
        # Otherwise, it is something else
        raise err

  return key
  

# This function will only affect multiplexers, and does not listen on real ports
def mux_virtual_stopcomm(key):
  """
  <Purpose>
    Instructs all multiplexers to stop responding to new connections on the virtual ip/port.

  <Arguments>
    key
      The handle returned from mux_virtual_stopcomm

  <Side effects>
    All multiplexers will stop waiting on the local port

  <Returns>
    None
  """
  # De-register this function for new multiplexers
  del MULTIPLEXER_WAIT_FUNCTIONS[key]
  
  # Map this stopcomm to all existing multiplexers
  for (listenkey, mux) in MULTIPLEXER_OBJECTS.items():
    mux.stopcomm(key)

# This functions stops and closes all multiplexer objects
def mux_stopall():
  """
  <Purpose>
    This is a general purpose cleanup routine for the multiplexer library.
    It will stop all multiplexers, remove any virtual and real waitforconn's,
    and close and delete all multiplexers. This will close all virtual sockets in the process.

  <Side effects>
    All multiplexers will stop and be destroyed.

  """ 
  # Map this close to all existing multiplexers
  for (key, mux) in MULTIPLEXER_OBJECTS.items():
    mux.close()
    del MULTIPLEXER_OBJECTS[key]
  
  # Stop all underlying waitforconns
  for key in MULTIPLEXER_WAIT_HANDLES.keys():
    # Map stopcomm to each key
    mux_stopcomm(key)
    
  # Remove all the wait functions
  for key in MULTIPLEXER_WAIT_FUNCTIONS.keys():
    mux_virtual_stopcomm(key)
    
# This function is the error delegate for the multiplexers created using the functional wrappers,
# they help clean everything up
def _mux_error_delegate(mux,errloc,exception):
  # Retrieve the key from the mux, the key is injected by mux_openconn and mux_waitforconn
  # into the socketInfo dictionary
  key = mux.socketInfo["key"]

  # Cleanup the multiplexer object
  if key in MULTIPLEXER_OBJECTS:
    del MULTIPLEXER_OBJECTS[key]


# Register this as the default error delegate
MULTIPLEXER_FUNCTIONS["errdelegate"] = _mux_error_delegate


  

#end include Multiplexer.py
#begin include RPC_Constants.py  
"""
This file declares and sets the constant values used for the forwarder RPC interface

RPC requests are dictionaries that have special fields
A typical request would be like the following:

# Server requests to de-register
rpc_req = {"id":0,"request":"de_reg_serv"}

# Forwarder responds with success message
rpc_resp = {"id":0,"status":True,"value":None}

# To actually transfer this request, the following is necessary:
message = encode_rpc(rpc_req)
sock.send(message)

# Then, to receive a RPC mesg
rpc_mesg = decode_rpc(sock)

"""
# This is used to decode RPC dictionaries
#begin include deserialize.py
#already included deserialize.py
#end include deserialize.py

# General Protocal Constants
RPC_VIRTUAL_IP = "0.0.0.0" # What IP is used for the virtual waitforconn / openconn
RPC_VIRTUAL_PORT = 0 # What virtual port to listen on for Remote Procedure Calls
RPC_FIXED_SIZE = 4   # Size of the RPC dictionary

# Defines fields
RPC_REQUEST_ID = "id"    # The identifier of the RPC request
RPC_FUNCTION = "request" # The remote function to call
RPC_PARAM = "value"      # The parameter to the requested function (if any)
RPC_ADDI_REQ = "additional" # Are there more RPC requests on the socket?
RPC_REQUEST_STATUS = "status" # The boolean status of the request
RPC_RESULT = "value"     # The result value if the RPC request

# Function Names
RPC_EXTERNAL_ADDR = "externaladdr"  # This allows the server to query its ip/port

# deterines if a connection is bi-directional
RPC_BI_DIRECTIONAL = "bidirectional"


# This allows a server to register with a forwarder
# This expects a MAC address as a parameter
RPC_REGISTER_SERVER = "reg_serv"    

# This allows a server to de-register from a forwarder
# This expects a MAC address as a parameter, or None to deregister all MAC's 
RPC_DEREGISTER_SERVER = "dereg_serv"

# The following two functions require an integer port and a server mac address
# # It expects the RPC_PARAM to be a dictionary:
# {"server":"__MAC__","port":50}
RPC_REGISTER_PORT = "reg_port"      # THis allows the server to register a wait port
RPC_DEREGISTER_PORT = "dereg_port"  # This allows the server to de-register a wait port

# This instructs the forwarder to begin forwarding data from this socket to a server
# It expects the RPC_PARAM to be a dictionary:
# {"server":"__MAC__","port":50}
RPC_CLIENT_INIT = "client_init"

# Helper Functions
def RPC_encode(rpc_dict):
  """
  <Purpose>
    Encodes an RPC request dictionary
  
  <Arguments>
    rpc_dict:
      A dictionary object
  
  <Returns>
    Returns a string that can be sent over a socket
  """
  rpc_dict_str = str(rpc_dict) # Conver to string
  rpc_length = str(len(rpc_dict_str)).rjust(RPC_FIXED_SIZE, "0") # Get length string
  return rpc_length + rpc_dict_str # Concatinate size with string

def RPC_decode(sock,blocking=False):
  """
  <Purpose>
    Returns an RPC request object from a socket
  
  <Arguments>
    sock:
      A socket that supports recv
    
    blocking:
      If the socket supports the blocking mode of operations, speicify this to be True
  
  <Returns>
    Returns a dictionary object containing the RPC Request
  """
  # Get the dictionary length
  # Then, Get the dictionary
  if blocking:
    length = int(sock.recv(RPC_FIXED_SIZE,blocking=True))
    dict_str = sock.recv(length,blocking=True)
  else:
    length = int(sock.recv(RPC_FIXED_SIZE))
    dict_str = sock.recv(length)
  
  dict_obj = deserialize(dict_str) # Convert to object
  return dict_obj
  

#end include RPC_Constants.py  


# How long we should stall nat_waitforconn after we create the mux to check its status
NAT_MUX_STALL = 2  # In seconds

# Set the messages
NAT_STATUS_NO_SERVER = "NO_SERVER"
NAT_STATUS_BSY_SERVER = "BSY_SERVER"
NAT_STATUS_CONFIRMED = "CONFIRMED"
NAT_STATUS_FAILED = "FAILED"


# Dictionary holds NAT_Connection state
NAT_STATE_DATA = {}
NAT_STATE_DATA["mux"] = None # Initialize to nothing

# Holds the ports we are listening on
NAT_LISTEN_PORTS = {}


# a lock used for stopcomm and nat_persist
NAT_STOP_LOCK = getlock()

#########################################################################

# Wrapper function around the NATLayer for clients        
def nat_openconn(destmac, destport, localip=None, localport=None, timeout = 5, forwarderIP=None,forwarderPort=None):
  """
  <Purpose>
    Opens a connection to a server behind a NAT.
  
  <Arguments>
    destmac:
      A string identifer for the destination server
    
    destport:
      The port on the host to connect to.
    
    localip:
      See openconn.
    
    localport:
      See openconn.
    
    timeout:
      How long before timing out the forwarder connection
    
    forwarderIP:
      Force a forwarder to connect to. This will be automatically resolved if None.
      forwarderPort must be specified if this is not None.
      
    forwarderPort:
      Force a forwarder port to connect to. This will be automatically resolved if None.
      forwarderIP must be specified if this is not None.
      
  <Returns>
     A socket-like object that can be used for communication. 
     Use send, recv, and close just like you would an actual socket object in python.
  """ 
  # If we don't get an ip/port explicitly, then locate the server
  if forwarderIP == None or forwarderPort == None:
    forwarders = nat_server_list_lookup(destmac)
  else:
    forwarders = [(forwarderIP, forwarderPort)]


  # try to connect to every forwarder listed until we suceed
  # or run out of forwarders
  connected = False
  for (ip,port) in forwarders:

    # Create a real connection to the forwarder
    try:
      socket = openconn(ip, int(port), localip, localport, timeout)
    except:
      pass # try the next forwarder listed
    else:
      connected = True
      break

  if not connected:
    raise EnvironmentError, "Could not connect to forwarder"

  
  # Create an RPC request to connect to the desired server
  rpc_dict = {RPC_FUNCTION:RPC_CLIENT_INIT,
              RPC_PARAM:{"server":destmac,"port":destport}}

  # Send the RPC request
  socket.send(RPC_encode(rpc_dict)) 

  # Get the response
  response = RPC_decode(socket)
  
  # Check the response 
  if response[RPC_RESULT] == NAT_STATUS_CONFIRMED:
    # Everything is good to go
    return socket
  
  # Handle no server at the forwarder  
  elif response[RPC_RESULT] == NAT_STATUS_NO_SERVER:
    raise EnvironmentError, "Connection Refused! No server at the forwarder!"
    
  # Handle busy forwarder
  elif response[RPC_RESULT] == NAT_STATUS_BSY_SERVER:
    raise EnvironmentError, "Connection Refused! Forwarder Busy."
  
  # General error    
  else:  
    raise EnvironmentError, "Connection Refused!"



# Private method to request a function on the forwarder and
# return the result
def _nat_rpc_call(mux, rpc_dict):
  # Get a virtual socket
  rpcsocket = mux.openconn(RPC_VIRTUAL_IP, RPC_VIRTUAL_PORT)
  
  # Get message encoding
  rpc_mesg = RPC_encode(rpc_dict)
  
  # Request, get the response
  rpcsocket.send(rpc_mesg)
  response = RPC_decode(rpcsocket,blocking=True)
  
  # Close the socket
  try:
    rpcsocket.close()
  except:
    pass
  
  # Return the status  
  return response[RPC_REQUEST_STATUS]
  


# Does an RPC call to the forwarder to register a port
def _nat_reg_port_rpc(mux, mac, port):
  rpc_dict = {RPC_REQUEST_ID:1,RPC_FUNCTION:RPC_REGISTER_PORT,RPC_PARAM:{"server":mac,"port":port}}
  return _nat_rpc_call(mux,rpc_dict)


# Does an RPC call to the forwarder to deregister a port
def _nat_dereg_port_rpc(mux, mac, port):
  rpc_dict = {RPC_REQUEST_ID:2,RPC_FUNCTION:RPC_DEREGISTER_PORT,RPC_PARAM:{"server":mac,"port":port}}
  return _nat_rpc_call(mux,rpc_dict)


# Does an RPC call to the forwarder to register a server
def _nat_reg_server_rpc(mux, mac):
  rpc_dict = {RPC_REQUEST_ID:3,RPC_FUNCTION:RPC_REGISTER_SERVER,RPC_PARAM:mac}
  return _nat_rpc_call(mux,rpc_dict)


# Does an RPC call to the forwarder to deregister a server
def _nat_dereg_server_rpc(mux, mac):
  rpc_dict = {RPC_REQUEST_ID:4,RPC_FUNCTION:RPC_DEREGISTER_SERVER,RPC_PARAM:mac}
  return _nat_rpc_call(mux,rpc_dict)  
  

# Simple wrapper function to determine if we are still waiting
# e.g. if the multiplexer is still alive
def nat_waitforconn_alive():
  """
  <Purpose>
    Informs the caller of the current state of the NAT waitforconn.
    
  <Returns>
    True if the connection to the forwarder is established and alive, False otherwise.    
  """
  return NAT_STATE_DATA["mux"] != None and NAT_STATE_DATA["mux"].isAlive()
  

# Wrapper function around the NATLayer for servers  
def nat_waitforconn(localmac, localport, function, forwarderIP=None, forwarderPort=None, forwarderCltPort=None, errdel=None,persist=True):
  """
  <Purpose>
    Allows a server to accept connections from behind a NAT.
    
  <Arguments>
    See wait for conn.

    forwarderIP:
      Force a forwarder to connect to. This will be automatically resolved if None.
      All forwarder information must be specified if this is set.
      
    forwarderPort:
      Force a forwarder port to connect to. This will be automatically resolved if None.
      All forwarder information must be specified if this is set.           
  
    forwarderCltPort:
      The port for clients to connect to on the explicitly specified forwarder.
      All forwarder information must be specified if this is set.
      
    errdel:
      Sets the Error Delegate for the underlying multiplexer. See Multiplexer.setErrorDelegate.
      Argument should be a function pointer, the function should take 3 parameters, (mux, location, exception)
      
    persist:
      If set to true the natlayer will reconnect to another forwarder in the
      case of failure 

  <Side Effects>
    An event will be used to monitor new connections
    If persist is true an event is used to check forwarder connection    

  <Returns>
    A handle, this can be used with nat_stopcomm to stop listening.      
  """  
  # Check if our current mux is dead (if it exists)
  if NAT_STATE_DATA["mux"] != None and not NAT_STATE_DATA["mux"].isAlive():
    # Delete the mux
    NAT_STATE_DATA["mux"] = None
  
  #save the user specified values in case we have to redo the waitforconn
  orig_forwarderIP = forwarderIP
  orig_forwarderPort = forwarderPort
  orig_forwarderCltPort = forwarderCltPort


  # Do we already have a mux? If not create a new one
  if NAT_STATE_DATA["mux"] == None:

    # Get a forwarder to use
    if forwarderIP == None or forwarderPort == None or forwarderCltPort == None:
      forwarders_list = nat_forwarder_list_lookup()
    else:
      forwarders_list = [(forwarderIP, forwarderPort, forwarderCltPort)]

    # do this until we get a connection or run out of forwarders
    connected = False
    for (forwarderIP, forwarderPort, forwarderCltPort) in forwarders_list:
        
    
      try:  
        # Create a real connection to the forwarder
        socket = openconn(forwarderIP, int(forwarderPort))
      except:
        pass # do nothing and try the next forwarder
      else:
        # we got a connection so stop looping
        connected = True
        break

    if not connected:
      raise EnvironmentError, "Failed to connect to a forwarder."
     
    # Save this information
    NAT_STATE_DATA["forwarderIP"] = forwarderIP
    NAT_STATE_DATA["forwarderPort"] = forwarderPort
    NAT_STATE_DATA["forwarderCltPort"] = forwarderCltPort


    # Immediately create a multiplexer from this connection
    mux = Multiplexer(socket, {"localip":getmyip(), "localport":localport})

    # Stall for a while then check the status of the mux
    sleep(NAT_MUX_STALL)
    
    # If the mux is no longer initialized, or never could initialize, then raise an exception
    if not mux.isAlive():
      raise EnvironmentError, "Failed to begin listening!"
    
    # Add the multiplexer to our state
    NAT_STATE_DATA["mux"] = mux
  
  else:
    # Get the mux
    mux = NAT_STATE_DATA["mux"]

  # If the error delegate is assigned, set up error delegation
  if errdel != None:
    mux.setErrorDelegate(errdel)
        
  # Register us as a server, if necessary
  if not localmac in NAT_LISTEN_PORTS:
    success = _nat_reg_server_rpc(mux, localmac)
    if success:
      # Create a set for the ports
      NAT_LISTEN_PORTS[localmac] = set()
      
      # Setup an advertisement
      nat_server_advertise(localmac, NAT_STATE_DATA["forwarderIP"], NAT_STATE_DATA["forwarderCltPort"])
      nat_toggle_advertisement(True)
    
    else:
      # Something is wrong, raise Exception
      raise EnvironmentError, "Failed to begin listening!"
      
  # Setup the waitforconn
  mux.waitforconn(localmac, localport, function)

  # Register our wait port on the forwarder, if necessary
  if not localport in NAT_LISTEN_PORTS[localmac]:
    success = _nat_reg_port_rpc(mux, localmac, localport)
    if success:
      # Register this port
      NAT_LISTEN_PORTS[localmac].add(localport)
    else:
      # Something is wrong, raise Exception
      raise EnvironmentError, "Failed to begin listening!"
   

  # Setup a function to check that the waitforconn is still
  # functioning, and peroform a new waitforconn if its now
  if persist:
    settimer(10,nat_persist,[localmac, localport, function, orig_forwarderIP, 
              orig_forwarderPort, orig_forwarderCltPort, errdel])
 
 
  # Return the localmac and localport, for stopcomm
  return (localmac,localport)
  

# Private method to make nat_waitforconn persist across
# forwarder errors.
# if the forwarder or mux fails redo the waitforconn unless
# stopcomm has been called   
def nat_persist(localmac, localport, function, forwarderIP, 
              forwarderPort, forwarderCltPort, errdel):
  
  # WHILE STOPCOMM HAS NOT BEEN CALLED 
  while True:
    NAT_STOP_LOCK.acquire()  #prevent race with stopcomm
    if not (localmac in NAT_LISTEN_PORTS and 
         localport in NAT_LISTEN_PORTS[localmac]):
      NAT_STOP_LOCK.release()
      return

    if not nat_isalive():
      nat_waitforconn(localmac, localport, function, forwarderIP, 
              forwarderPort, forwarderCltPort, errdel)
    NAT_STOP_LOCK.release() 
    sleep(10)
  
  
    
# Private method to check to see if the nat_waitforconn is still active
# used with persist to determine if we need to connect to a new forwarder
def nat_isalive():

  # Check if our current mux is dead (if it exists)
  if NAT_STATE_DATA["mux"] == None or not NAT_STATE_DATA["mux"].isAlive():
    # Delete the mux

    for key in NAT_STATE_DATA.keys():
      del NAT_STATE_DATA[key]
    NAT_STATE_DATA["mux"] = None
    for key in NAT_LISTEN_PORTS.keys():
      del NAT_LISTEN_PORTS[key]
    
    return False
  
  return True



# Stops the socketReader for the given natcon  
def nat_stopcomm(handle):
  """
  <Purpose>
    Stops listening on a NATConnection, opened by nat_waitforconn
    
  <Arguments>
    handle:
        Handle returned by nat_waitforconn.
  
  """
  NAT_STOP_LOCK.acquire() # prevent a race with persist
  
  # Get the mux
  mux = NAT_STATE_DATA["mux"]
  
  # Check the status of the mux, is it alive?
  if mux != None and not mux.isAlive():
    # Delete the mux, and stop listening on everything
    NAT_STATE_DATA["mux"] = None
    NAT_LISTEN_PORTS.clear()
    mux = None
  
  # Unpack the handle
  (localmac, localport) = handle
  
  if mux != None and localmac in NAT_LISTEN_PORTS and localport in NAT_LISTEN_PORTS[localmac]:
    # Tell the Mux to stop listening
    mux.stopcomm(str(handle))
    
    # Cleanup
    NAT_LISTEN_PORTS[localmac].discard(localport)
  
    # De-register our port from the forwarder
    _nat_dereg_port_rpc(mux, localmac, localport)
    
    # Are we listening on any ports?
    numListen = len(NAT_LISTEN_PORTS[localmac])
    
    if numListen == 0:
      # De-register the server entirely
      _nat_dereg_server_rpc(mux, localmac)
      
      # Stop advertising
      nat_stop_server_advertise(localmac)
      
      # Cleanup
      del NAT_LISTEN_PORTS[localmac]
    
    # Are we listening as any server?
    if len(NAT_LISTEN_PORTS) == 0:
      # Close the mux, and set it to Null
      mux.close()
      NAT_STATE_DATA["mux"] = None
      
      # Disable advertisement
      nat_toggle_advertisement(False, False)
  
  NAT_STOP_LOCK.release()




# Determine if you have a bi-directional connection
def nat_check_bi_directional(localip,port,forwarderIP=None,forwarderCltPort=None):
  """
  <Purpose>
    Allows a vessel to determine if they can establish a bi-direction connection
    without use of the nat layer
  
  <Arguments>
    forwarderIP/forwarderPort:
      If None, a forwarder will be automatically selected. They can also be explicitly specified.
      forwarderPort must be a client port.
  
    localip: the ip to be used for a temporay waitforconn
    port: the port to be used for a temporary waitforconn

  <Side Effects>
    This operation will use a socket while it is running.
  
  <Returns>
    True if the client needs to use the nat layer
    False if they don't
  """
  # If we don't have an explicit forwarder, pick a random one
  if forwarderIP == None or forwarderCltPort == None:
    forwarder_list = nat_forwarder_list_lookup()
  else:
    forwarder_list = [(forwarderIP,None,forwarderCltPort)]

  connected = False
  # try this until we get a good connection or run out of forwarders
  for (forwarderIP, forwarderPort, forwarderCltPort) in forwarder_list:

    # Create a real connection to the forwarder
    try:
      rpcsocket = openconn(forwarderIP, int(forwarderCltPort))
    except Exception, e:
      print str(e)
      pass
    else:
      connected = True
      break
    
  if not connected:
    raise EnvironmentError, "Failed to connect to forwarder. Please try again."
  
  # define an echo function to test the connection  
  def nat_echo_test(rip,remoteport,test_sock,th,lh):
    while True:
      try:
        msg = test_sock.recv(1024)
        test_sock.send(msg)
      except Exception:
        test_sock.close()
        return

  # start a listener
  handle = waitforconn(localip,port,nat_echo_test)

  # Now connect to a forwarder, and get our external ip/port
  # Create a RPC dictionary
  rpc_request = {RPC_FUNCTION:RPC_BI_DIRECTIONAL}
  rpc_request[RPC_PARAM] = {'localip':localip,'waitport':port}

  # Send the RPC message
  rpcsocket.send(RPC_encode(rpc_request))
  
  # Get the response
  response = RPC_decode(rpcsocket)
  
  # Close the socket
  rpcsocket.close()
  
  # stop the listener
  stopcomm(handle)

  # Return the IP
  return response[RPC_RESULT]



# SUPERCEEDED
# Determines if you are behind a NAT (Network-Address-Translation)
# this fuction along with get_my_external_ip have been replaced with 
# nat_check_bi_directional but remain here as it may still be of
# interest for some users.
def behind_nat(forwarderIP=None,forwarderCltPort=None):
  """
  <Purpose>
    Determines if the currently executing node is behind a Network-Address-Translation device
  
  <Arguments>
    forwarderip:
      Defaults to None. This can be set for explicitly forcing the use of a forwarder
    
    forwarderport:
      Defaults to None. This can be set for explicitly forcing the use of a port on a forwarder.
      This must be the client port, not the server port.
  
  <Exceptions>
    This may raise various network related Exceptions if not connected to the internet.
  
  <Returns>
    True if behind a nat, False otherwise.
  """
  # Get "normal" ip
  ip = getmyip()
  
  # Get external ip
  externalip = getmy_external_ip(forwarderIP, forwarderCltPort)
  
  return (ip != externalip)



# Pings a forwarder to get our external IP
# SUPERCEEDED - should not be in use
# this function and use_nat are superceeded by the new nat_check_bi_directional.
# they remain here because this function may still be of interest for some users
def getmy_external_ip(forwarderIP=None,forwarderCltPort=None):
  """
  <Purpose>
    Allows a vessel to determine its external IP address. E.g. this will differ from getmyip if you are on a NAT.
  
  <Arguments>
    forwarderIP/forwarderPort:
      If None, a forwarder will be automatically selected. They can also be explicitly specified.
      forwarderPort must be a client port.
  
  <Side Effects>
    This operation will use a socket while it is running.
  
  <Returns>
    A string IP address
  """
  # If we don't have an explicit forwarder, pick a random one
  if forwarderIP == None or forwarderCltPort == None:
    forwarder_list = nat_forwarder_list_lookup()
  else:
    forwarder_list = [(forwarderIP,None,forwarderCltPort)]

  connected = False
  # try this until we get a good connection or run out of forwarders
  for (forwarderIP, forwarderPort, forwarderCltPort) in forwarder_list:

    # Create a real connection to the forwarder
    try:
      rpcsocket = openconn(forwarderIP, int(forwarderCltPort))
    except Exception, e:
      print str(e)
      pass
    else:
      connected = True
      break
    
  if not connected:
    raise EnvironmentError, "Failed to connect to forwarder. Please try again."
  # Now connect to a forwarder, and get our external ip/port
  # Create a RPC dictionary
  rpc_request = {RPC_FUNCTION:RPC_EXTERNAL_ADDR}
  
  # Send the RPC message
  rpcsocket.send(RPC_encode(rpc_request))
  
  # Get the response
  response = RPC_decode(rpcsocket)
  
  # Close the socket
  rpcsocket.close()
  
  # Return the IP
  return response[RPC_RESULT]["ip"]


#end include NATLayer_rpc.py


# makes connections time out
#begin include sockettimeout.repy
#already included sockettimeout.repy
#end include sockettimeout.repy

# The idea is that this module returns "node manager handles".   A handle
# may be used to communicate with a node manager and issue commands.   If the
# caller wants to have a set of node managers with the same state, this can
# be done by something like:
#
#
# myid =    # some unique, non-repeating value
# nmhandles = []
# for nm in nodemanagers:
#   nmhandles.append(nmclient_createhandle(nm, sequenceid = myid))
#
# 
# def do_action(action):
#   for nmhandle in nmhandles:
#     nmclient_doaction(nmhandle, ... )
#
#
# The above code snippet will ensure that none of the nmhandles perform the
# actions called in do_action() out of order.   A node that "misses" an action
# (perhaps due to a network or node failure) will not perform later actions 
# unless the sequenceid is reset.
#
# Note that the above calls to nmclient_createhandle and nmclient_doaction 
# should really be wrapped in try except blocks for NMClientExceptions



# Thrown when a failure occurs when trying to communicate with a node
class NMClientException(Exception):
  pass

# This holds all of the client handles.   A client handle is merely a 
# string that is the key to this dict.   All of the information is stored in
# the dictionary value (a dict with keys for IP, port, sessionID, timestamp,
# identity, expirationtime, public key, private key, and vesselID).   
nmclient_handledict = {}

# BUG: How do I do this and have it be portable across repy <-> python?
# needed when assigning new handles to prevent race conditions...
nmclient_handledictlock = getlock()



# Note: I open a new connection for every request.   Is this really what I want
# to do?   It seemed easiest but likely has performance implications

# Sends data to a node (opens the connection, writes the 
# communication header, sends all the data, receives the result, and returns
# the result)...
def nmclient_rawcommunicate(nmhandle, *args):

  # the node is behind a nat and using nat layer
  if 'natlayermac' in nmclient_handledict[nmhandle]:
    try:
      thisconnobject = nat_openconn(nmclient_handledict[nmhandle]['natlayermac'],nmclient_handledict[nmhandle]['port']) 
    except Exception, e:
      raise NMClientException, str(e)
  
  # not a NATLayer connection
  else:
    # do the normal openconn
    try:
      thisconnobject = timeout_openconn(nmclient_handledict[nmhandle]['IP'], nmclient_handledict[nmhandle]['port'],timeout=nmclient_handledict[nmhandle]['timeout']) 
    except Exception, e:
      raise NMClientException, str(e)

  
  # always close the connobject
  try:

    # send the args separated by '|' chars (as is expected by the node manager)
    session_sendmessage(thisconnobject, '|'.join(args))
    return session_recvmessage(thisconnobject)
  except Exception, e:
    raise NMClientException, str(e)
  finally:
    thisconnobject.close()




# Sends data to a node (opens the connection, writes the 
# communication header, sends all the data, receives the result, and returns
# the result)...
def nmclient_signedcommunicate(nmhandle, *args):
  
  # need to check lots of the nmhandle settings...

  if nmclient_handledict[nmhandle]['timestamp'] == True:
    # set the time based upon the current time...
    timestamp = time_gettime()
  elif not nmclient_handledict[nmhandle]['timestamp']:
    # we're false, so set to None
    timestamp = None
  else:
    # For some reason, the caller wanted a specific time...
    timestamp = nmclient_handledict[nmhandle]['timestamp']

  if nmclient_handledict[nmhandle]['publickey']:
    publickey = nmclient_handledict[nmhandle]['publickey']
  else:
    raise NMClientException, "Must have public key for signed communication"

  if nmclient_handledict[nmhandle]['privatekey']:
    privatekey = nmclient_handledict[nmhandle]['privatekey']
  else:
    raise NMClientException, "Must have private key for signed communication"

  # use this blindly (None or a value are both okay)
  sequenceid = nmclient_handledict[nmhandle]['sequenceid']

  if nmclient_handledict[nmhandle]['expiration']:
    if timestamp == None:
      # highly dubious.   However, it's technically valid, so let's allow it.
      expirationtime = nmclient_handledict[nmhandle]['expiration']
    else:
      expirationtime = timestamp + nmclient_handledict[nmhandle]['expiration']

  else:
    # they don't want this to expire
    expirationtime = nmclient_handledict[nmhandle]['expiration']


  # use this blindly (None or a value are both okay)
  identity = nmclient_handledict[nmhandle]['identity']


  # build the data to send.   Ideally we'd do: datatosend = '|'.join(args)
  # we can't do this because some args may be non-strings...
  datatosend = args[0]
  for arg in args[1:]:
    datatosend = datatosend + '|' + str(arg)
  


  # the node is behind a nat
  if 'natlayermac' in nmclient_handledict[nmhandle]:
    try:
      thisconnobject = nat_openconn(nmclient_handledict[nmhandle]['natlayermac'], nmclient_handledict[nmhandle]['port']) 
    except Exception, e:
      raise NMClientException, str(e)
  
  # not a natlayer conn
  else:  

    try:
      thisconnobject = timeout_openconn(nmclient_handledict[nmhandle]['IP'], nmclient_handledict[nmhandle]['port'], timeout=nmclient_handledict[nmhandle]['timeout'])
    except Exception, e:
      raise NMClientException, str(e)

  
  # always close the connobject afterwards...
  try:
    try:
      signeddata = signeddata_signdata(datatosend, privatekey, publickey, timestamp, expirationtime, sequenceid, identity)
    except ValueError, e:
      raise NMClientException, str(e)

    try:
      session_sendmessage(thisconnobject, signeddata)
    except Exception, e:
      # label the exception and change the type...
      raise NMClientException, "signedcommunicate failed on session_sendmessage with error '"+str(e)+"'"

    try:
      message = session_recvmessage(thisconnobject)
    except Exception, e:
      # label the exception and change the type...
      raise NMClientException, "signedcommunicate failed on session_recvmessage with error '"+str(e)+"'"

    return message
  finally:
    thisconnobject.close()



def nmclient_safelygethandle():
  # I lock to prevent a race when adding handles to the dictionary.   I don't
  # need a lock when removing because a race is benign (it prevents reuse)
  nmclient_handledictlock.acquire()
  try:
    potentialhandle = randomfloat()
    while potentialhandle in nmclient_handledict:
      potentialhandle = randomfloat()
    return potentialhandle
  finally:
    nmclient_handledictlock.release()





# Create a new handle, the IP, port must be provided but others are optional.
# The default is to have no sequenceID, timestamps on, expiration time of 1 
# hour, and the program should set and use the identity of the node.   The 
# public key, private key, and vesselids are left uninitialized unless 
# specified elsewhere.   Regardless, the keys and vesselid are not used to 
# create the handle and so are merely transfered to the created handle.
def nmclient_createhandle(nmIP, nmport, sequenceid = None, timestamp=True, identity = True, expirationtime = 60*60, publickey = None, privatekey = None, vesselid = None, timeout=10):

  thisentry = {}

  # is this using the nat layer  NAT$MAC
  if 'NAT' in nmIP:
    (_,mac) = nmIP.split('$')
    thisentry['natlayermac'] = mac 


  thisentry['IP'] = nmIP
  thisentry['port'] = nmport
  thisentry['sequenceid'] = sequenceid
  thisentry['timestamp'] = timestamp
  thisentry['expiration'] = expirationtime
  thisentry['publickey'] = publickey
  thisentry['privatekey'] = privatekey
  thisentry['vesselid'] = vesselid
  thisentry['timeout'] = timeout

    
  newhandle = nmclient_safelygethandle()

  nmclient_handledict[newhandle] = thisentry

  # Use GetVessels as a "hello" test (and for identity reasons as shown below)
  try:
    response = nmclient_rawsay(newhandle, 'GetVessels')

  except (ValueError, NMClientException, KeyError), e:
    del nmclient_handledict[newhandle]
    raise NMClientException, e


  # set up the identity
  if identity == True:
    for line in response.split('\n'):
      if line.startswith('Nodekey: '):
        # get everything after the Nodekey as the identity
        nmclient_handledict[newhandle]['identity'] = line[len('Nodekey: '):]
        break
        
    else:
      raise NMClientException, "Do not understand node manager identity in identification"

  else:
    nmclient_handledict[newhandle]['identity'] = identity

  # it worked!
  return newhandle



def nmclient_duplicatehandle(nmhandle):
  newhandle = nmclient_safelygethandle()
  nmclient_handledict[newhandle] = nmclient_handledict[nmhandle].copy()
  return newhandle

# public.   Use this to clean up a handle
def nmclient_destroyhandle(nmhandle):
  try:
    del nmclient_handledict[nmhandle]
  except KeyError:
    return False
  return True
  

# public.   Use these to get / set attributes about the handles...
def nmclient_get_handle_info(nmhandle):
  if nmhandle not in nmclient_handledict:
    raise NMClientException, "Unknown nmhandle: '"+str(nmhandle)+"'"
  return nmclient_handledict[nmhandle].copy()


def nmclient_set_handle_info(nmhandle, dict):
  if nmhandle not in nmclient_handledict:
    raise NMClientException, "Unknown nmhandle: '"+str(nmhandle)+"'"
  nmclient_handledict[nmhandle] = dict


  

# Public:  Use this for non-signed operations...
def nmclient_rawsay(nmhandle, *args):
  fullresponse = nmclient_rawcommunicate(nmhandle, *args)

  try:
    (response, status) = fullresponse.rsplit('\n',1)
  except KeyError:
    raise NMClientException, "Communication error '"+fullresponse+"'"

  if status == 'Success':
    return response
  elif status == 'Error':
    raise NMClientException, "Node Manager error '"+response+"'"
  elif status == 'Warning':
    raise NMClientException, "Node Manager warning '"+response+"'"
  else:
    raise NMClientException, "Unknown status '"+fullresponse+"'"
  



# Public:  Use this for signed operations...
def nmclient_signedsay(nmhandle, *args):

  fullresponse = nmclient_signedcommunicate(nmhandle, *args)

  try:
    (response, status) = fullresponse.rsplit('\n',1)
  except KeyError:
    raise NMClientException, "Communication error '"+fullresponse+"'"

  if status == 'Success':
    return response
  elif status == 'Error':
    raise NMClientException, "Node Manager error '"+response+"'"
  elif status == 'Warning':
    raise NMClientException, "Node Manager warning '"+response+"'"
  else:
    raise NMClientException, "Unknown status '"+fullresponse+"'"
  


# public, use this to do raw communication with a vessel
def nmclient_rawsaytovessel(nmhandle, call, *args):
  vesselid = nmclient_handledict[nmhandle]['vesselid']
  if not vesselid:
    raise NMClientException, "Must set vesselid to communicate with a vessel"

  return nmclient_rawsay(nmhandle,call, vesselid,*args)
  


# public, use this to do a signed communication with a vessel
def nmclient_signedsaytovessel(nmhandle, call, *args):
  vesselid = nmclient_handledict[nmhandle]['vesselid']
  if not vesselid:
    raise NMClientException, "Must set vesselid to communicate with a vessel"

  return nmclient_signedsay(nmhandle,call, vesselid,*args)


# public, lists the vessels that the provided key owns or can use
def nmclient_listaccessiblevessels(nmhandle, publickey):

  vesselinfo = nmclient_getvesseldict(nmhandle)

  # these will be filled with relevant vessel names...
  ownervessels = []
  uservessels = []

  for vesselname in vesselinfo['vessels']:
    if publickey == vesselinfo['vessels'][vesselname]['ownerkey']:
      ownervessels.append(vesselname)

    if 'userkeys' in vesselinfo['vessels'][vesselname] and publickey in vesselinfo['vessels'][vesselname]['userkeys']:
      uservessels.append(vesselname)


  return (ownervessels, uservessels)



#public, parse a node manager's vessel information and return it to the user...
def nmclient_getvesseldict(nmhandle):

  response = nmclient_rawsay(nmhandle, 'GetVessels')

  retdict = {}
  retdict['vessels'] = {}

  # here we loop through the response and set the dicts as appropriate
  lastvesselname = None
  for line in response.split('\n'):
    if not line:
      # empty line.   Let's allow it...
      pass
    elif line.startswith('Version: '):
      retdict['version'] = line[len('Version: '):]
    elif line.startswith('Nodename: '):
      retdict['nodename'] = line[len('Nodename: '):]
    elif line.startswith('Nodekey: '):
      retdict['nodekey'] = rsa_string_to_publickey(line[len('Nodekey: '):])
 
    # start of a vessel
    elif line.startswith('Name: '):
      # if there is a previous vessel write it to the dict...
      if lastvesselname:
        retdict['vessels'][lastvesselname] = thisvessel

      thisvessel = {}
      # NOTE:I'm changing this so that userkeys will always exist even if there
      # are no user keys (in this case it has an empty list).   I think this is
      # the right functionality.
      thisvessel['userkeys'] = []
      lastvesselname = line[len('Name: '):]

    elif line.startswith('OwnerKey: '):
      thiskeystring = line[len('OwnerKey: '):]
      thiskey = rsa_string_to_publickey(thiskeystring)
      thisvessel['ownerkey'] = thiskey

    elif line.startswith('OwnerInfo: '):
      thisownerstring = line[len('OwnerInfo: '):]
      thisvessel['ownerinfo'] = thisownerstring

    elif line.startswith('Status: '):
      thisstatus = line[len('Status: '):]
      thisvessel['status'] = thisstatus

    elif line.startswith('Advertise: '):
      thisadvertise = line[len('Advertise: '):]
      if thisadvertise == 'True':
        thisvessel['advertise'] = True
      elif thisadvertise == 'False':
        thisvessel['advertise'] = False
      else:
        raise NMClientException, "Unknown advertise type '"+thisadvertise+"'"

    elif line.startswith('UserKey: '):
      thiskeystring = line[len('UserKey: '):]
      thiskey = rsa_string_to_publickey(thiskeystring)

      thisvessel['userkeys'].append(thiskey)

    else:
      raise NMClientException, "Unknown line in GetVessels response '"+line+"'"


  if lastvesselname:
    retdict['vessels'][lastvesselname] = thisvessel
  return retdict

#end include nmclient.repy

#begin include time.repy
#already included time.repy
#end include time.repy

#begin include rsa.repy
#already included rsa.repy
#end include rsa.repy

#begin include listops.repy
""" 
Author: Justin Cappos

Module: A simple library of list commands that allow the programmer
        to do list composition operations

Start date: November 11th, 2008

This is a really simple module, only broken out to avoid duplicating 
functionality.

This was adopted from previous code in seash.   

I really should be using sets instead I think.   These are merely for 
convenience when you already have lists.

"""


def listops_difference(list_a,list_b):
  """
   <Purpose>
      Return a list that has all of the items in list_a that are not in list_b
      Duplicates are removed from the output list

   <Arguments>
      list_a, list_b:
        The lists to operate on

   <Exceptions>
      TypeError if list_a or list_b is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing list_a - list_b
  """

  retlist = []
  for item in list_a:
    if item not in list_b:
      retlist.append(item)

  # ensure that a duplicated item in list_a is only listed once
  return listops_uniq(retlist)


def listops_union(list_a,list_b):
  """
   <Purpose>
      Return a list that has all of the items in list_a or in list_b.   
      Duplicates are removed from the output list

   <Arguments>
      list_a, list_b:
        The lists to operate on

   <Exceptions>
      TypeError if list_a or list_b is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing list_a union list_b
  """

  retlist = list_a[:]
  for item in list_b: 
    if item not in list_a:
      retlist.append(item)

  # ensure that a duplicated item in list_a is only listed once
  return listops_uniq(retlist)


def listops_intersect(list_a,list_b):
  """
   <Purpose>
      Return a list that has all of the items in both list_a and list_b.   
      Duplicates are removed from the output list

   <Arguments>
      list_a, list_b:
        The lists to operate on

   <Exceptions>
      TypeError if list_a or list_b is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing list_a intersect list_b
  """

  retlist = []
  for item in list_a:
    if item in list_b:
      retlist.append(item)

  # ensure that a duplicated item in list_a is only listed once
  return listops_uniq(retlist)
      

def listops_uniq(list_a):
  """
   <Purpose>
      Return a list that has no duplicate items

   <Arguments>
      list_a
        The list to operate on

   <Exceptions>
      TypeError if list_a is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing the unique items in list_a
  """
  retlist = []
  for item in list_a:
    if item not in retlist:
      retlist.append(item)

  return retlist



#end include listops.repy

#begin include parallelize.repy
""" 
Author: Justin Cappos

Module: A parallelization module.   It performs actions in parallel to make it
        easy for a user to call a function with a list of tasks.

Start date: November 11th, 2008

This module is adapted from code in seash which had similar functionality.

NOTE (for the programmer using this module).   It's really important to 
write concurrency safe code for the functions they provide us.  It will not 
work to write:

def foo(...):
  mycontext['count'] = mycontext['count'] + 1

YOU MUST PUT A LOCK AROUND SUCH ACCESSES.

"""


# I use this to get unique identifiers. 
#begin include uniqueid.repy
""" 
Author: Justin Cappos

Module: A simple library that provides a unique ID for each call

Start date: November 11th, 2008

This is a really, really simple module, only broken out to avoid duplicating 
functionality.

NOTE: This will give unique ids PER FILE.   If you have multiple python 
modules that include this, they will have the potential to generate the
same ID.

"""

# This is a list to prevent using part of the user's mycontext dict
uniqueid_idlist = [0]
uniqueid_idlock = getlock()

def uniqueid_getid():
  """
   <Purpose>
      Return a unique ID in a threadsafe way

   <Arguments>
      None

   <Exceptions>
      None

   <Side Effects>
      None.

   <Returns>
      The ID (an integer)
  """

  uniqueid_idlock.acquire()

  # I'm using a list because I need a global, but don't want to use the 
  # programmer's dict
  myid = uniqueid_idlist[0]
  uniqueid_idlist[0] = uniqueid_idlist[0] + 1

  uniqueid_idlock.release()

  return myid


def listops_union(list_a,list_b):
  """
   <Purpose>
      Return a list that has all of the items in list_a or in list_b.   
      Duplicates are removed from the output list

   <Arguments>
      list_a, list_b:
        The lists to operate on

   <Exceptions>
      TypeError if list_a or list_b is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing list_a union list_b
  """

  retlist = list_a[:]
  for item in list_b: 
    if item not in list_a:
      retlist.append(item)

  # ensure that a duplicated item in list_a is only listed once
  return listops_uniq(retlist)


def listops_intersect(list_a,list_b):
  """
   <Purpose>
      Return a list that has all of the items in both list_a and list_b.   
      Duplicates are removed from the output list

   <Arguments>
      list_a, list_b:
        The lists to operate on

   <Exceptions>
      TypeError if list_a or list_b is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing list_a intersect list_b
  """

  retlist = []
  for item in list_a:
    if item in list_b:
      retlist.append(item)

  # ensure that a duplicated item in list_a is only listed once
  return listops_uniq(retlist)
      

def listops_uniq(list_a):
  """
   <Purpose>
      Return a list that has no duplicate items

   <Arguments>
      list_a
        The list to operate on

   <Exceptions>
      TypeError if list_a is not a list.

   <Side Effects>
      None.

   <Returns>
      A list containing the unique items in list_a
  """
  retlist = []
  for item in list_a:
    if item not in retlist:
      retlist.append(item)

  return retlist



#end include uniqueid.repy



class ParallelizeError(Exception):
  """An error occurred when operating on a parallelized task"""


# This has information about all of the different parallel functions.
# The keys are unique integers and the entries look like this:
# {'abort':False, 'callfunc':callfunc, 'callargs':callargs,
# 'targetlist':targetlist, 'availabletargetpositions':positionlist,
# 'runninglist':runninglist, 'result':result}
#
# abort is used to determine if future events should be aborted.
# callfunc is the function to call
# callargs are extra arguments to pass to the function
# targetlist is the list of items to call the function with
# runninglist is used to track which events are executing
# result is a dictionary that contains information about completed function.
#    The format of result is:
#      {'exception':list of tuples with (target, exception string), 
#       'aborted':list of targets,
#       'returned':list of tuples with (target, return value)}
# 
parallelize_info_dict = {}



def parallelize_closefunction(parallelizehandle):
  """
   <Purpose>
      Clean up the state created after calling parallelize_initfunction.

   <Arguments>
      parallelizehandle:
         The handle returned by parallelize_initfunction
          

   <Exceptions>
      None

   <Side Effects>
      Will try to abort future functions if possible

   <Returns>
      True if the parallelizehandle was recognized or False if the handle is
      invalid or already closed.
  """

  # There is no sense trying to check then delete, since there may be a race 
  # with multiple calls to this function.
  try:
    del parallelize_info_dict[parallelizehandle]
  except KeyError:
    return False
  else:
    return True

    



def parallelize_abortfunction(parallelizehandle):
  """
   <Purpose>
      Cause pending events for a function to abort.   Events will finish 
      processing their current event.

   <Arguments>
      parallelizehandle:
         The handle returned by parallelize_initfunction
          

   <Exceptions>
      ParallelizeException is raised if the handle is unrecognized

   <Side Effects>
      None

   <Returns>
      True if the function was not previously aborting and is now, or False if 
      the function was already set to abort before the call.
  """

  
  try:
    if parallelize_info_dict[parallelizehandle]['abort'] == False:
      parallelize_info_dict[parallelizehandle]['abort'] = True
      return True
    else:
      return False
  except KeyError:
    raise ParallelizeException("Cannot abort the parallel execution of a non-existent handle:"+str(parallelizehandle))



def parallelize_isfunctionfinished(parallelizehandle):
  """
   <Purpose>
      Indicate if a function is finished

   <Arguments>
      parallelizehandle:
         The handle returned by parallelize_initfunction
          

   <Exceptions>
      ParallelizeException is raised if the handle is unrecognized

   <Side Effects>
      None

   <Returns>
      True if the function has finished, False if it is still has events running
  """

  
  try:
    if parallelize_info_dict[parallelizehandle]['runninglist']:
      return False
    else:
      return True
  except KeyError:
    raise ParallelizeException("Cannot get status for the parallel execution of a non-existent handle:"+str(parallelizehandle))





def parallelize_getresults(parallelizehandle):
  """
   <Purpose>
      Get information about a parallelized function

   <Arguments>
      parallelizehandle:
         The handle returned by parallelize_initfunction
          
   <Exceptions>
      ParallelizeException is raised if the handle is unrecognized

   <Side Effects>
      None

   <Returns>
      A dictionary with the results.   The format is
        {'exception':list of tuples with (target, exception string), 
         'aborted':list of targets, 'returned':list of tuples with (target, 
         return value)}
  """

  
  try:
    # I copy so that the user doesn't have to deal with the fact I may still
    # be modifying it
    return parallelize_info_dict[parallelizehandle]['result'].copy()
  except KeyError:
    raise ParallelizeException("Cannot get results for the parallel execution of a non-existent handle:"+str(parallelizehandle))



      



      


def parallelize_initfunction(targetlist, callerfunc,concurrentevents=5, *extrafuncargs):
  """
   <Purpose>
      Call a function with each argument in a list in parallel

   <Arguments>
      targetlist:
          The list of arguments the function should be called with.   Each
          argument is passed once to the function.   Items may appear in the
          list multiple times

      callerfunc:
          The function to call
 
      concurrentevents:
          The number of events to issue concurrently (default 5).   No more 
          than len(targetlist) events will be concurrently started.

      extrafuncargs:
          Extra arguments the function should be called with (every function
          is passed the same extra args).

   <Exceptions>
      ParallelizeException is raised if there isn't at least one free event.   
      However, if there aren't at least concurrentevents number of free events,
      this is not an error (instead this is reflected in parallelize_getstatus)
      in the status information.

   <Side Effects>
      Starts events, etc.

   <Returns>
      A handle used for status information, etc.
  """

  parallelizehandle = uniqueid_getid()

  # set up the dict locally one line at a time to avoid a ginormous line
  handleinfo = {}
  handleinfo['abort'] = False
  handleinfo['callfunc'] = callerfunc
  handleinfo['callargs'] = extrafuncargs
  # make a copy of target list because 
  handleinfo['targetlist'] = targetlist[:]
  handleinfo['availabletargetpositions'] = range(len(handleinfo['targetlist']))
  handleinfo['result'] = {'exception':[],'returned':[],'aborted':[]}
  handleinfo['runninglist'] = []

  
  parallelize_info_dict[parallelizehandle] = handleinfo

  # don't start more threads than there are targets (duh!)
  threads_to_start = min(concurrentevents, len(handleinfo['targetlist']))

  for workercount in range(threads_to_start):
    # we need to append the workercount here because we can't return until 
    # this is scheduled without having race conditions
    parallelize_info_dict[parallelizehandle]['runninglist'].append(workercount)
    try:
      settimer(0.0, parallelize_execute_function, (parallelizehandle,workercount))
    except:
      # If I'm out of resources, stop
      # remove this worker (they didn't start)
      parallelize_info_dict[parallelizehandle]['runninglist'].remove(workercount)
      if not parallelize_info_dict[parallelizehandle]['runninglist']:
        parallelize_closefunction(parallelizehandle)
        raise Exception, "No events available!"
      break
  
  return parallelizehandle
    


def parallelize_execute_function(handle, myid):
  # This is internal only.   It's used to execute the user function...

  # No matter what, an exception in me should not propagate up!   Otherwise,
  # we might result in the program's termination!
  try:

    while True:
      # separate this from below functionality to minimize scope of try block
      thetargetlist = parallelize_info_dict[handle]['targetlist']
      try:
        mytarget = thetargetlist.pop()
      except IndexError:
        # all items are gone, let's return
        return

      # if they want us to abort, put this in the aborted list
      if parallelize_info_dict[handle]['abort']:
        parallelize_info_dict[handle]['result']['aborted'].append(mytarget)

      else:
        # otherwise process this normally

        # limit the scope of the below try block...
        callfunc = parallelize_info_dict[handle]['callfunc']
        callargs = parallelize_info_dict[handle]['callargs']

        try:
          retvalue = callfunc(mytarget,*callargs)
        except Exception, e:
          # always log on error.   We need to report what happened
          parallelize_info_dict[handle]['result']['exception'].append((mytarget,str(e)))
        else:
          # success, add it to the dict...
          parallelize_info_dict[handle]['result']['returned'].append((mytarget,retvalue))


  except KeyError:
    # A KeyError is normal if they've closed the handle
    return

  except Exception, e:
    print 'Internal Error: Exception in parallelize_execute_function',e

  finally:
    # remove my entry from the list of running worker threads...
    try:
      parallelize_info_dict[handle]['runninglist'].remove(myid)
    except ValueError:
      pass
    

    


#end include parallelize.repy

import traceback

import advertise            #  used to do OpenDHT lookups

import os.path    # fix path names when doing upload, loadkeys, etc.







#### Helper functions and exception definitions


# this is how long we wait for a node to timeout
globalseashtimeout = 10

  
# Use this to signal an error we want to print...
class UserError(Exception):
  """This indicates the user typed an incorrect command"""







def is_immutable_targetname(targetname):
  if targetname.startswith('%') or ':' in targetname:
    return True
  return False


def valid_targetname(targetname):
  if targetname.startswith('%') or ':' in targetname or ' ' in targetname:
    return False
  return True


def fit_string(stringdata, length):
  if len(stringdata) > length:
    return stringdata[:length-3]+'...'
  return stringdata


nextidlock = getlock()
def atomically_get_nextid():
  global nextid

  # mutex around getting an id
  nextidlock.acquire()

  myid = nextid
  nextid = nextid + 1

  nextidlock.release()

  return myid
    
  

# adds a vessel and returns the new ID...
def add_vessel(longname, keyname, vesselhandle):
  vesselinfo[longname] = {}
  vesselinfo[longname]['handle'] = vesselhandle
  vesselinfo[longname]['keyname'] = keyname
  vesselinfo[longname]['IP'] = longname.split(':')[0]
  vesselinfo[longname]['port'] = int(longname.split(':')[1])
  vesselinfo[longname]['vesselname'] = longname.split(':')[2]
  # miscelaneous information about the vessel (version, nodeID, etc.)
  vesselinfo[longname]['information'] = {}
  
  # set up a reference to myself...
  targets[longname] = [longname]

  myid = atomically_get_nextid()

  # add my id...
  targets['%'+str(myid)] = [longname]
  vesselinfo[longname]['ID'] = '%'+str(myid)

  # add me to %all...
  targets['%all'].append(longname)

  return myid




def copy_vessel(longname, newvesselname):
  newhandle = nmclient_duplicatehandle(vesselinfo[longname]['handle'])
  newlongname = vesselinfo[longname]['IP']+":"+str(vesselinfo[longname]['port'])+":"+newvesselname
  add_vessel(newlongname,vesselinfo[longname]['keyname'],newhandle)
  return newlongname

def delete_vessel(longname):
  # remove the item...
  del vesselinfo[longname]

  # remove the targets that reference it...
  for target in targets.copy():
    # if in my list...
    if longname in targets[target]:
      # if this is the %num entry or longname entry...
      if ('%' in target and target != '%all') or longname == target:
        del targets[target]
        continue
      # otherwise remove the item from the list...
      targets[target].remove(longname)



def longnamelist_to_nodelist(longnamelist):
  
  retlist = []
  for longname in longnamelist:
    nodename = vesselinfo[longname]['IP']+":"+str(vesselinfo[longname]['port'])
    retlist.append(nodename)

  return retlist


def find_handle_for_node(nodename):
  
  for longname in vesselinfo:
    if longname.rsplit(':',1)[0] == nodename:
      return vesselinfo[longname]['handle']
  raise IndexError("Cannot find handle for '"+nodename+"'")





#################### functions that operate on a target

MAX_CONTACT_WORKER_THREAD_COUNT = 10


# This function abstracts out contacting different nodes.   It spawns off 
# multiple worker threads to handle the clients...
# by a threaded model in the future...
# NOTE: entries in targetlist are assumed by me to be unique
def contact_targets(targetlist, func,*args):
  
  phandle = parallelize_initfunction(targetlist, func, MAX_CONTACT_WORKER_THREAD_COUNT, *args)

  while not parallelize_isfunctionfinished(phandle):
    sleep(.1)
  
  # I'm going to change the format slightly...
  resultdict = parallelize_getresults(phandle)

  # There really shouldn't be any exceptions in any of the routines...
  if resultdict['exception']:
    print "WARNING: ",resultdict['exception']

  # I'm going to convert the format to be targetname (as the key) and 
  # a value with the return value...
  retdict = {}
  for nameandretval in resultdict['returned']:
    retdict[nameandretval[0]] = nameandretval[1]

  return retdict
    

    

# This function abstracts out contacting different nodes.   It is obsoleted by
# the threaded model...   This code is retained for testing reasons only
def simple_contact_targets(targetlist, func,*args):
  retdict = {}

  # do the function on each target, returning a dict of results.
  for target in targetlist:
    retdict[target] = func(target,*args)

  return retdict
    



# used in show files
def showfiles_target(longname):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    filedata = nmclient_signedsay(vesselinfo[longname]['handle'],"ListFilesInVessel",vesselname)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True, filedata)








# used in show log
def showlog_target(longname):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    logdata = nmclient_signedsay(vesselinfo[longname]['handle'],"ReadVesselLog",vesselname)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True, logdata)





# used in show resources
def showresources_target(longname):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    resourcedata = nmclient_rawsay(vesselinfo[longname]['handle'],"GetVesselResources",vesselname)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True, resourcedata)


# used in show offcut
def showoffcut_target(nodename):
  vesselhandle = find_handle_for_node(nodename)
  try:
    offcutdata = nmclient_rawsay(vesselhandle,"GetOffcutResources")
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True, offcutdata)
  




def browse_target(node, currentkeyname):

  # NOTE: I almost think I should skip those nodes that I know about from 
  # previous browse commands.   Perhaps I should have an option on the browse
  # command?

  host, portstring = node.split(':')
  port = int(portstring)

  # get information about the node's vessels
  try:
    nodehandle = nmclient_createhandle(host, port, privatekey = keys[currentkeyname]['privatekey'], publickey = keys[currentkeyname]['publickey'], timeout=globalseashtimeout)
  except NMClientException,e:
    return (False, str(e))

  try:
    # need to contact the node to get the list of vessels we can perform
    # actions on...
    ownervessels, uservessels = nmclient_listaccessiblevessels(nodehandle,keys[currentkeyname]['publickey'])

    retlist = []

    # we should add anything we can access (whether a user or owner vessel)
    for vesselname in ownervessels + uservessels:
      longname = host+":"+str(port)+":"+vesselname

      # if we haven't discovered the vessel previously...
      if longname not in targets:
        # set the vesselname in the handle
        newhandle = nmclient_duplicatehandle(nodehandle)
        handleinfo = nmclient_get_handle_info(newhandle)
        handleinfo['vesselname'] = vesselname
        nmclient_set_handle_info(newhandle, handleinfo)

        # then add the vessel to the target list, etc.
        # add_vessel has no race conditions as long as longname is unique 
        # (and it should be unique)
        id = add_vessel(longname,currentkeyname,newhandle)
        targets['browsegood'].append(longname)

        # and append some information to be printed...
        retlist.append('%'+str(id)+"("+longname+")")



  finally:
    nmclient_destroyhandle(nodehandle)

  return (True, retlist)


def list_or_update_target(longname):

  vesselname = vesselinfo[longname]['vesselname']
  try:
    vesseldict = nmclient_getvesseldict(vesselinfo[longname]['handle'])
  except NMClientException, e:
    return (False, str(e))
  else:
    # updates the dictionary of our node information (dictionary used in show, 
    # etc.)
    for key in vesseldict['vessels'][vesselname]:
      vesselinfo[longname][key] = vesseldict['vessels'][vesselname][key]

    # Update the "information" (version number, etc.)
    del vesseldict['vessels']
    vesselinfo[longname]['information'] = vesseldict

    return (True,)


def upload_target(longname, remotefn, filedata):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # add the file data...
    nmclient_signedsay(vesselinfo[longname]['handle'], "AddFileToVessel", vesselname, remotefn, filedata)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)


def download_target(longname,localfn,remotefn):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # get the file data...
    retrieveddata = nmclient_signedsay(vesselinfo[longname]['handle'], "RetrieveFileFromVessel", vesselname, remotefn)

  except NMClientException, e:
    return (False, str(e))

  else:
    writefn = localfn+"."+longname.replace(':','_')
    # write to the local filename (replacing ':' with '_')...
    fileobj = open(writefn,"w")
    fileobj.write(retrieveddata)
    fileobj.close()
    # for output...
    return (True, writefn)



def delete_target(longname,remotefn):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # delete the file...
    nmclient_signedsay(vesselinfo[longname]['handle'], "DeleteFileInVessel", vesselname, remotefn)

  except NMClientException, e:
    return (False, str(e))

  else:
    return (True,)


def start_target(longname, argstring):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # start the program
    nmclient_signedsay(vesselinfo[longname]['handle'], "StartVessel", vesselname, argstring)

  except NMClientException, e:
    return (False, str(e))

  else:
    return (True,)


def stop_target(longname):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # stop the programs
    nmclient_signedsay(vesselinfo[longname]['handle'], "StopVessel", vesselname)
  except NMClientException, e:
    return (False, str(e))

  else:
    return (True,)


def reset_target(longname):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # reset the target
    nmclient_signedsay(vesselinfo[longname]['handle'], "ResetVessel", vesselname)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)


def run_target(longname,filename,filedata, argstring):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    nmclient_signedsay(vesselinfo[longname]['handle'], "AddFileToVessel", vesselname, filename, filedata)
    nmclient_signedsay(vesselinfo[longname]['handle'], "StartVessel", vesselname, argstring)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)



# didn't test...
def split_target(longname, resourcedata):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    newvesselnames = nmclient_signedsay(vesselinfo[longname]['handle'], "SplitVessel", vesselname, resourcedata)
  except NMClientException, e:
    return (False, str(e))
  else:
    newname1 = copy_vessel(longname, newvesselnames.split()[0])
    newname2 = copy_vessel(longname, newvesselnames.split()[1])
    delete_vessel(longname)
    return (True,(newname1,newname2))


# didn't test...
def join_target(nodename,nodedict):
 
  if len(nodedict[nodename]) < 2:
    # not enough vessels, nothing to do
    return (False, None)
            

  # I'll iterate through the vessels, joining one with the current 
  # (current starts as the first vessel and becomes the "new vessel")
  currentvesselname = vesselinfo[nodedict[nodename][0]]['vesselname']
  currentlongname = nodedict[nodename][0]

  # keep a list of what I replace...
  subsumedlist = [currentlongname]

  for longname in nodedict[nodename][1:]:
    vesselname = vesselinfo[longname]['vesselname']
    try:
      newvesselname = nmclient_signedsay(vesselinfo[longname]['handle'], "JoinVessels", currentvesselname, vesselname)
    except NMClientException, e:
      return (False, str(e))
    else:
      newname = copy_vessel(longname, newvesselname)
      delete_vessel(longname)
      delete_vessel(currentlongname)
      subsumedlist.append(longname)
      currentlongname = newname
      currentvesselname = newvesselname
  else:
    return (True, (currentlongname,subsumedlist))



# didn't test...
def setowner_target(longname,newowner):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    nmclient_signedsay(vesselinfo[longname]['handle'], "ChangeOwner", vesselname, rsa_publickey_to_string(keys[newowner]['publickey']))
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)
  


# didn't test...
def setadvertise_target(longname,newadvert):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # do the actual advertisement changes
    nmclient_signedsay(vesselinfo[longname]['handle'], "ChangeAdvertise", vesselname, newadvert)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)
  

def setownerinformation_target(longname,newownerinformation):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    # do the actual advertisement changes
    nmclient_signedsay(vesselinfo[longname]['handle'], "ChangeOwnerInformation", vesselname, newownerinformation)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)
  

def setusers_target(longname,userkeystring):
  vesselname = vesselinfo[longname]['vesselname']
  try:
    nmclient_signedsay(vesselinfo[longname]['handle'], "ChangeUsers", vesselname, userkeystring)
  except NMClientException, e:
    return (False, str(e))
  else:
    return (True,)




# Checks if both keys are setup
def check_key_set(name):
  if (name in keys and 'publickey' in keys[name] and 'privatekey' in keys[name] and keys[name]['publickey'] and keys[name]['privatekey']):
    if not check_key_pair_compatibility(name):
      raise UserError("Error: Mis-matched Public/Private key pair!")

# Check the keys to make sure they are compatible, for the given name
def check_key_pair_compatibility(name):
   # Check for both sets of keys
    setPublic = keys[name]['publickey']
    setPrivate = keys[name]['privatekey']
    
    # Check for a mis-match
    match = rsa_matching_keys(setPrivate, setPublic)
    
    return match


#################### main loop and variables.
  
# a dict that contains all of the targets (vessels and groups) we know about.
targets = {'%all':[]}

# stores information about the vessels...
vesselinfo = {}

# the nextid that should be used for a new target.
nextid = 1

# a dict that contains all of the key information
keys = {}



# The usual way of handling a user request is:
#   1) parse the arguments the user gives (I do this up front so that I can
#      give intelligible error messages before doing any work)
#   2) handle the request.   If the request can be handled with local data, 
#      it does so.   Otherwise, contact_targets is called with the list of
#      of targets.   (targets are usually either nodenames or longnames)
#   3) provide output to the user informing them of what happened.   It is
#      common to create groups for the user if different targets have different
#      outcomes
#
# Steps 1 and 3 are always done inline (inflating the function length).   Step
# 2 is commonly done by a function XXX_target(...) listed above

def command_loop():
  # we will set this if they call set timeout
  global globalseashtimeout


  # things that may be set herein and used in later commands
  host = None
  port = None
  expnum = None
  filename = None
  cmdargs = None
  defaulttarget = None
  defaultkeyname = None


  # exit via a return
  while True:

    try:
      
      
      prompt = ''
      if defaultkeyname:
        prompt = fit_string(defaultkeyname,20)+"@"

      # display the thing they are acting on in their prompt (if applicable)
      if defaulttarget:
        prompt = prompt + fit_string(defaulttarget,20)

      prompt = prompt + " !> "
      # the prompt should look like: justin@good !> 

      # get the user input
      userinput = raw_input(prompt)

      userinput = userinput.strip()

      userinputlist = userinput.split()
      if len(userinputlist)==0:
        continue

      # by default, use the target specified in the prompt
      currenttarget = defaulttarget

      # set the target, then handle other operations
      if len(userinputlist) >= 2:
        if userinputlist[0] == 'on':
          if userinputlist[1] not in targets:
            raise UserError("Error: Unknown target '"+userinputlist[1]+"'")
          # set the target and strip the rest...
          currenttarget = userinputlist[1]
          userinputlist = userinputlist[2:]

          # they are setting the default
          if len(userinputlist) == 0:
            defaulttarget = currenttarget
            continue

      # by default, use the identity specified in the prompt
      currentkeyname = defaultkeyname

      # set the keys, then handle other operations
      if len(userinputlist) >= 2:
        if userinputlist[0] == 'as':
          if userinputlist[1] not in keys:
            raise UserError("Error: Unknown identity '"+userinputlist[1]+"'")
            
          # set the target and strip the rest...
          currentkeyname = userinputlist[1]
          userinputlist = userinputlist[2:]

          # they are setting the default
          if len(userinputlist) == 0:
            defaultkeyname = currentkeyname
            continue





# help or ?
      if userinputlist[0] == 'help' or userinputlist[0] == '?':
        if len(userinputlist) == 1:
          print \
"""
A target can be either a host:port:vesselname, %ID, or a group name.

on target [command] -- Runs a command on a target (or changes the default)
as keyname [command]-- Run a command using an identity (or changes the default).
add [target] [to group]      -- Adds a target to a new or existing group 
remove [target] [from group] -- Removes a target from a group
show                -- Displays shell state (use 'help show' for more info)
set                 -- Changes the state of the targets (use 'help set')
browse              -- Find vessels I can control
genkeys fn [len] [as identity] -- creates new pub / priv keys (default len=1024)
loadkeys fn [as identity]   -- loads filename.publickey and filename.privatekey
list               -- Update and display information about the vessels
upload localfn (remotefn)   -- Upload a file 
download remotefn (localfn) -- Download a file 
delete remotefn             -- Delete a file
reset                  -- Reset the vessel (clear the log and files and stop)
run file [args ...]    -- Shortcut for upload a file and start
start file [args ...] -- Start an experiment
stop               -- Stop an experiment
split resourcefn            -- Split another vessel off of each vessel
join                        -- Join vessels on the same node
help [help | set | show ]    -- help information 
exit                         -- exits the shell
"""
#!resourcedata                -- List resource information about the vessel

        else:
          if userinputlist[1] == 'set':
            print \
"""set users [ identity ... ]  -- Change a vessel's users
set ownerinfo [ data ... ]    -- Change owner information for the vessels
set advertise [ on | off ] -- Change advertisement of vessels
set owner identity        -- Change a vessel's owner
set timeout count  -- Sets the time that seash is willing to wait on a node
"""


          elif userinputlist[1] == 'show':
            print \
"""
show info       -- Display general information about the vessels
show users      -- Display the user keys for the vessels
show ownerinfo  -- Display owner information for the vessels
show advertise  -- Display advertisement information about the vessels
show ip         -- Display the ip addresses of the nodes
show owner      -- Display a vessel's owner
show targets    -- Display a list of targets
show identities -- Display the known identities
show keys       -- Display the known keys
show log        -- Display the log from the vessel (*)
show files      -- Display a list of files in the vessel (*)
show resources  -- Display the resources / restrictions for the vessel (*)
show offcut     -- Display the offcut resource for the node (*)
show timeout    -- Display the timeout for nodes

(*) No need to update prior, the command contacts the nodes anew
"""


          elif userinputlist[1] == 'help':
            print \
"""
Extended commands (not commonly used):

loadpub fn [as identity]    -- loads filename.publickey 
loadpriv fn [as identity]   -- loads filename.privatekey
move target to group        -- Add target to group, remove target from default
contact host:port[:vessel] -- Communicate with a node
update             -- Update information about the vessels
"""
          else:
            raise UserError("Usage: help [ set | show ] -- display help")


        continue





# exit, quit, bye
      elif userinputlist[0] == 'exit' or userinputlist[0] == 'quit' or userinputlist[0] == 'bye':
        return







# show   (lots to do here)
      elif userinputlist[0] == 'show':
        if len(userinputlist) == 1:
          # What do I show?
          pass

# show info       -- Display general information about the vessels
        elif userinputlist[1] == 'info' or userinputlist[1] == 'information':
          if not currenttarget:
            raise UserError("Error, command requires a target")

          for longname in targets[currenttarget]:
            if vesselinfo[longname]['information']:
              print longname, vesselinfo[longname]['information']
            else:
              print longname, "has no information (try 'update' or 'list')"


# show targets    -- Display a list of targets
        elif userinputlist[1] == 'targets' or userinputlist[1] == 'groups':
          for target in targets:
            if len(targets[target]) == 0:
              print target, "(empty)"
              continue
            # this is a vesselentry
            if target == targets[target][0]:
              continue
            print target, targets[target]


# show keys       -- Display the known keys
        elif userinputlist[1] == 'keys':
          for identity in keys:
            print identity,keys[identity]['publickey'],keys[identity]['privatekey']




# show identities -- Display the known identities
        # catch a common typo
        elif userinputlist[1] == 'identities' or userinputlist[1] == 'identites':
          for keyname in keys:
            print keyname,
            if keys[keyname]['publickey']:
              print "PUB",
            if keys[keyname]['privatekey']:
              print "PRIV",
            print



# show users      -- Display the user keys for the vessels
        elif userinputlist[1] == 'users':
          if not currenttarget:
            raise UserError("Error, command requires a target")

          for longname in targets[currenttarget]:
            if 'userkeys' in vesselinfo[longname]:
              if vesselinfo[longname]['userkeys'] == []:
                print longname,"(no keys)"
                continue

              print longname,
              # we'd like to say 'joe's public key' instead of '3453 2323...'
              for key in vesselinfo[longname]['userkeys']:
                for identity in keys:
                  if keys[identity]['publickey'] == key:
                    print identity,
                    break
                else:
                  print fit_string(rsa_publickey_to_string(key),15),
              print
            else:
              print longname, "has no information (try 'update' or 'list')"

          continue

# show ownerinfo  -- Display owner information for the vessels
        elif userinputlist[1] == 'ownerinfo':
          if not currenttarget:
            raise UserError("Error, command requires a target")

          for longname in targets[currenttarget]:
            if 'ownerinfo' in vesselinfo[longname]:
              print longname, "'"+vesselinfo[longname]['ownerinfo']+"'"
              # list all of the info...
            else:
              print longname, "has no information (try 'update' or 'list')"

          continue

# show advertise  -- Display advertisement information about the vessels
        elif userinputlist[1] == 'advertise':
          if not currenttarget:
            raise UserError("Error, command requires a target")

          for longname in targets[currenttarget]:
            if 'advertise' in vesselinfo[longname]:
              if vesselinfo[longname]['advertise']:
                print longname, "on"
              else:
                print longname, "off"
              # list all of the info...
            else:
              print longname, "has no information (try 'update' or 'list')"

          continue


# show owner      -- Display a vessel's owner
        elif userinputlist[1] == 'owner':
          if not currenttarget:
            raise UserError("Error, command requires a target")

          for longname in targets[currenttarget]:
            if 'ownerkey' in vesselinfo[longname]:
              # we'd like to say 'joe public key' instead of '3453 2323...'
              ownerkey = vesselinfo[longname]['ownerkey']
              for identity in keys:
                if keys[identity]['publickey'] == ownerkey:
                  print longname, identity+" pubkey"
                  break
              else:
                print longname, fit_string(rsa_publickey_to_string(ownerkey),15)
            else:
              print longname, "has no information (try 'update' or 'list')"

          continue



# show files      -- Display a list of files in the vessel (*)
        elif userinputlist[1] == 'file' or userinputlist[1] == 'files':

          if not currenttarget:
            raise UserError("Error, command requires a target")

          # print the list of files in the vessels...
          retdict = contact_targets(targets[currenttarget], showfiles_target)

          goodlist = []
          faillist = []
          for longname in retdict:
            # True means it worked
            if retdict[longname][0]:
              print "Files on '"+longname+"': '"+retdict[longname][1]+"'"
              goodlist.append(longname)
            else:
              print "failure:",retdict[longname][1]
              faillist.append(longname)
  
          # and display it...
          if faillist:
            print "Failures on "+str(len(faillist))+" targets: "+", ".join(faillist)
          if goodlist and faillist:
            targets['filesgood'] = goodlist
            targets['filesfail'] = faillist
            print "Added group 'filesgood' with "+str(len(targets['filesgood']))+" targets and 'filesfail' with "+str(len(targets['filesfail']))+" targets"

          continue






# show log        -- Display the log from the node (*)
        elif userinputlist[1] == 'log' or userinputlist[1] == 'logs':

          if not currenttarget:
            raise UserError("Error, command requires a target")

          # print the vessel logs...
          retdict = contact_targets(targets[currenttarget], showlog_target)

          goodlist = []
          faillist = []
          for longname in retdict:
            # True means it worked
            if retdict[longname][0]:
              print "Log from '"+longname+"':"
              print retdict[longname][1]
              goodlist.append(longname)
            else:
              print "failure:",retdict[longname][1]
              faillist.append(longname)
  
          # and display it...
          if faillist:
            print "Failures on "+str(len(faillist))+" targets: "+", ".join(faillist)
          if goodlist and faillist:
            targets['loggood'] = goodlist
            targets['logfail'] = faillist
            print "Added group 'loggood' with "+str(len(targets['loggood']))+" targets and 'logfail' with "+str(len(targets['logfail']))+" targets"

          continue




# show resources  -- Display the resources / restrictions for the vessel (*)
        elif userinputlist[1] == 'resource' or userinputlist[1] == 'resources':

          if not currenttarget:
            raise UserError("Error, command requires a target")

          retdict = contact_targets(targets[currenttarget], showresources_target)
          faillist = []
          goodlist = []
          for longname in retdict:
            # True means it worked
            if retdict[longname][0]:
              print "Resource data for '"+longname+"':"
              print retdict[longname][1]
              goodlist.append(longname)
            else:
              print "failure:",retdict[longname][1]
              faillist.append(longname)
  
          # and display it...
          if faillist:
            print "Failures on "+str(len(faillist))+" targets: "+", ".join(faillist)
          if goodlist and faillist:
            targets['resourcegood'] = goodlist
            targets['resourcefail'] = faillist
            print "Added group 'resourcegood' with "+str(len(targets['resourcegood']))+" targets and 'resourcefail' with "+str(len(targets['resourcefail']))+" targets"

          continue



# show offcut     -- Display the offcut resource for the node (*)
        elif userinputlist[1] == 'offcut':

          if not currenttarget:
            raise UserError("Error, command requires a target")

          
          # we should only visit a node once...
          nodelist = listops_uniq(longnamelist_to_nodelist(targets[currenttarget]))
          retdict = contact_targets(nodelist, showoffcut_target)

          for nodename in retdict:
            if retdict[nodename][0]:
              print "Offcut resource data for '"+nodename+"':"
              print retdict[nodename][1]
            else:
              print "failure:",retdict[nodename][1]
  
          continue



# show ip         -- Display the ip addresses of the nodes
        # catch a misspelling
        elif userinputlist[1] == 'ip' or userinputlist[1] == 'ips':

          if not currenttarget:
            raise UserError("Error, command requires a target")

          
          # we should only visit a node once...
          printedIPlist = []
          for longname in targets[currenttarget]:
            thisnodeIP = vesselinfo[longname]['IP']

            if thisnodeIP not in printedIPlist:
              printedIPlist.append(thisnodeIP)
              print thisnodeIP
  
          continue

# show timeout    -- Display the timeout for nodes
        elif userinputlist[1] == 'timeout' or userinputlist[1] == 'timeouts':

          print globalseashtimeout
          
          continue








# show ???      -- oops!
        else:
          raise UserError("Error in usage: try 'help show'")
        continue






# add (target) (to group)
      elif userinputlist[0] == 'add':
        if len(userinputlist) == 2:
          source = userinputlist[1]
          dest = currenttarget

        elif len(userinputlist) == 3:
          source = currenttarget
          if userinputlist[1] != 'to':
            raise UserError("Error, command format: add (target) (to group)")
          dest = userinputlist[2]

        elif len(userinputlist) == 4:
          source = userinputlist[1]
          if userinputlist[2] != 'to':
            raise UserError("Error, command format: add (target) (to group)")
          dest = userinputlist[3]

        else:
          raise UserError("Error, command format: add (target) (to group)")
 
        # okay, now source and dest are set.   Time to add the nodes in source
        # to the group dest...
        if source not in targets:
          raise UserError("Error, unknown target '"+source+"'")
        if dest not in targets:
          if not valid_targetname(dest):
            raise UserError("Error, invalid target name '"+dest+"'")
          targets[dest] = []

        if is_immutable_targetname(dest):
          raise UserError("Can't modify the contents of '"+dest+"'")

        # source - dest has what we should add (items in source but not dest)
        addlist = listops_difference(targets[source],targets[dest])
        if len(addlist) == 0:
          raise UserError("No targets to add (the target is already in '"+dest+"')")
        
        for item in addlist:
          targets[dest].append(item)
        continue







# remove (target) (from group)
      elif userinputlist[0] == 'remove':
        if len(userinputlist) == 2:
          source = userinputlist[1]
          dest = currenttarget

        elif len(userinputlist) == 3:
          source = currenttarget
          if userinputlist[1] != 'from':
            raise UserError("Error, command format: remove (target) (from group)")
          dest = userinputlist[2]

        elif len(userinputlist) == 4:
          source = userinputlist[1]
          if userinputlist[2] != 'from':
            raise UserError("Error, command format: remove (target) (from group)")
          dest = userinputlist[3]

        else:
          raise UserError("Error, command format: remove (target) (from group)")
 
        # time to check args and do the ops
        if source not in targets:
          raise UserError("Error, unknown target '"+source+"'")
        if dest not in targets:
          raise UserError("Error, unknown group '"+dest+"'")

        if is_immutable_targetname(dest):
          raise UserError("Can't modify the contents of '"+dest+"'")

        # find the items to remove (the items in both dest and source)
        removelist = listops_intersect(targets[dest],targets[source])
        if len(removelist) == 0:
          raise UserError("No targets to remove (no items from '"+source+"' are in '"+dest+"')")

        # it's okay to end up with an empty group.   We'll leave it...
        for item in removelist:
          targets[dest].remove(item)

        continue
          





# move target to group
      elif userinputlist[0] == 'move':
        if len(userinputlist) == 4:
          moving = userinputlist[1]
          source = currenttarget
          if userinputlist[2] != 'to':
            raise UserError("Error, command format: move target to group")
          dest = userinputlist[3]

        else:
          raise UserError("Error, command format: move target to group")
 
        # check args...
        if source not in targets:
          raise UserError("Error, unknown group '"+source+"'")
        if moving not in targets:
          raise UserError("Error, unknown group '"+moving+"'")
        if dest not in targets:
          raise UserError("Error, unknown group '"+dest+"'")


        if is_immutable_targetname(dest):
          raise UserError("Can't modify the contents of '"+source+"'")

        if is_immutable_targetname(dest):
          raise UserError( "Can't modify the contents of '"+dest+"'")

        removelist = listops_intersect(targets[source], targets[moving])
        if len(removelist) == 0:
          raise UserError("Error, '"+moving+"' is not in '"+source+"'")

        addlist = listops_difference(removelist, targets[dest])
        if len(addlist) == 0:
          raise UserError("Error, the common items between '"+source+"' and '"+moving+"' are already in '"+dest+"'")

        for item in removelist:
          targets[source].remove(item)

        for item in addlist:
          targets[dest].append(item)

        continue







# contact host:port[:vessel] -- Communicate with a node
      elif userinputlist[0] == 'contact':
        if currentkeyname == None or not keys[currentkeyname]['publickey']:
          raise UserError("Error, must contact as an identity")

        if len(userinputlist)>2:
          raise UserError("Error, usage is contact host:port[:vessel]")

        if len(userinputlist[1].split(':')) == 2:
          host, portstring = userinputlist[1].split(':')
          port = int(portstring)
          vesselname = None
        elif len(userinputlist[1].split(':')) == 3:
          host, portstring,vesselname = userinputlist[1].split(':')
          port = int(portstring)
        else:
          raise UserError("Error, usage is contact host:port[:vessel]")
        
        # get information about the node's vessels
        thishandle = nmclient_createhandle(host, port, privatekey = keys[currentkeyname]['privatekey'], publickey = keys[currentkeyname]['publickey'], vesselid = vesselname, timeout = globalseashtimeout)
        ownervessels, uservessels = nmclient_listaccessiblevessels(thishandle,keys[currentkeyname]['publickey'])

        newidlist = []
        # determine if we control the specified vessel...
        if vesselname:
          if vesselname in ownervessels or vesselname in uservessels:
            longname = host+":"+str(port)+":"+vesselname
            # no need to set the vesselname, we did so above...
            id = add_vessel(longname,currentkeyname,thishandle)
            newidlist.append('%'+str(id)+"("+longname+")")
          else:
            raise UserError("Error, cannot access vessel '"+vesselname+"'")

        # we should add anything we can access
        else:
          for vesselname in ownervessels:
            longname = host+":"+str(port)+":"+vesselname
            if longname not in targets:
              # set the vesselname
              # NOTE: we leak handles (no cleanup of thishandle).   
              # I think we don't care...
              newhandle = nmclient_duplicatehandle(thishandle)
              handleinfo = nmclient_get_handle_info(newhandle)
              handleinfo['vesselname'] = vesselname
              nmclient_set_handle_info(newhandle, handleinfo)

              id = add_vessel(longname,currentkeyname,newhandle)
              newidlist.append('%'+str(id)+"("+longname+")")

          for vesselname in uservessels:
            longname = host+":"+str(port)+":"+vesselname
            if longname not in targets:
              # set the vesselname
              # NOTE: we leak handles (no cleanup of thishandle).   
              # I think we don't care...
              newhandle = nmclient_duplicatehandle(thishandle)
              handleinfo = nmclient_get_handle_info(newhandle)
              handleinfo['vesselname'] = vesselname
              nmclient_set_handle_info(newhandle, handleinfo)

              id = add_vessel(longname,currentkeyname,newhandle)
              newidlist.append('%'+str(id)+"("+longname+")")

        # tell the user what we did...
        if len(newidlist) == 0:
          print "Could not add any targets."
        else:
          print "Added targets: "+", ".join(newidlist)
            
        continue
  





# browse                               -- Find experiments I can control
      elif userinputlist[0] == 'browse':
        if currentkeyname == None or not keys[currentkeyname]['publickey']:
          raise UserError("Error, must browse as an identity with a public key")
  
        # they are trying to only do some types of lookup...
        if len(userinputlist) > 1:
          nodelist = advertise.lookup(keys[currentkeyname]['publickey'],lookuptype=userinputlist[1:])
        else:
          nodelist = advertise.lookup(keys[currentkeyname]['publickey'])

        # If there are no vessels for a user, the lookup may return ''
        for nodename in nodelist[:]:
          if nodename == '':
            nodelist.remove(nodename)

        # we'll output a message about the new keys later...
        newidlist = []

        faillist = []

        targets['browsegood'] = []

        print nodelist
        # currently, if I browse more than once, I look up everything again...
        retdict = contact_targets(nodelist,browse_target, currentkeyname)

        # parse the output so we can print out something intelligible
        for nodename in retdict:
          
          if retdict[nodename][0]:
            newidlist = newidlist + retdict[nodename][1]
          else:
            print "Error '",retdict[nodename][1],"' on "+nodename
            faillist.append(nodename)


        # tell the user what we did...
        if len(faillist) > 0:
          print "Failed to contact: "+ ", ".join(faillist)

        if len(newidlist) == 0:
          print "Could not add any new targets."
        else:
          print "Added targets: "+", ".join(newidlist)

        if len(targets['browsegood']) > 0:
          print "Added group 'browsegood' with "+str(len(targets['browsegood']))+" targets"
              
        continue





# genkeys filename [len] [as identity]          -- creates keys
      elif userinputlist[0] == 'genkeys':
        if len(userinputlist)==2:
          keylength = 1024
          # expand '~'
          fileandpath = os.path.expanduser(userinputlist[1])
          keyname = os.path.basename(fileandpath)
          pubkeyfn = fileandpath+'.publickey'
          privkeyfn = fileandpath+'.privatekey'
        elif len(userinputlist)==3:
          keylength = int(userinputlist[2])
          # expand '~'
          fileandpath = os.path.expanduser(userinputlist[1])
          keyname = os.path.basename(fileandpath)
          pubkeyfn = fileandpath+'.publickey'
          privkeyfn = fileandpath+'.privatekey'
        elif len(userinputlist)==4:
          if userinputlist[2] != 'as':
            raise UserError("Usage: genkeys filename [len] [as identity]")
          keylength = 1024
          keyname = userinputlist[3]
          pubkeyfn = userinputlist[1]+'.publickey'
          privkeyfn = userinputlist[1]+'.privatekey'
        elif len(userinputlist)==5:
          if userinputlist[3] != 'as':
            raise UserError("Usage: genkeys filename [len] [as identity]")
          keylength = int(userinputlist[2])
          keyname = userinputlist[4]
          pubkeyfn = userinputlist[1]+'.publickey'
          privkeyfn = userinputlist[1]+'.privatekey'
        else:
          raise UserError("Usage: genkeys filename [len] [as identity]")
  

        # do the actual generation (will take a while)
        newkeys = rsa_gen_pubpriv_keys(keylength)
        
        rsa_privatekey_to_file(newkeys[1],privkeyfn)
        rsa_publickey_to_file(newkeys[0],pubkeyfn)
        keys[keyname] = {'publickey':newkeys[0], 'privatekey':newkeys[1]}

        print "Created identity '"+keyname+"'"
        continue
  




# loadpub filename [as identity]                    -- loads a public key
      elif userinputlist[0] == 'loadpub':
        if len(userinputlist)==2:
          # they typed 'loadpub foo.publickey'
          if userinputlist[1].endswith('.publickey'):
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            keyname = os.path.basename(fileandpath[:len('.publickey')])
            pubkeyfn = fileandpath
          else:
            # they typed 'loadpub foo'
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            keyname = os.path.basename(fileandpath)
            pubkeyfn = fileandpath+'.publickey'
        elif len(userinputlist)==4:
          if userinputlist[2] != 'as':
            raise UserError("Usage: loadpub filename [as identity]")

          # they typed 'loadpub foo.publickey'
          if userinputlist[1].endswith('.publickey'):
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            pubkeyfn = fileandpath
          else:
            # they typed 'loadpub foo'
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            pubkeyfn = fileandpath+'.publickey'
          keyname = userinputlist[3]
        else:
          raise UserError("Usage: loadpub filename [as identity]")

        # load the key and update the table...
        pubkey = rsa_file_to_publickey(pubkeyfn)
        if keyname not in keys:
          keys[keyname] = {'publickey':pubkey, 'privatekey':None}
        else:
          keys[keyname]['publickey'] = pubkey
          
          # Check the keys, on error reverse the change and re-raise
          try:
            check_key_set(keyname)
          except:
            keys[keyname]['publickey'] = None
            raise

        continue
  




# loadpriv filename [as identity]                    -- loads a private key
      elif userinputlist[0] == 'loadpriv':
        if len(userinputlist)==2:
          # they typed 'loadpriv foo.privatekey'
          if userinputlist[1].endswith('.privatekey'):
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            privkeyfn = fileandpath+'.privatekey'
            keyname = os.path.basename(fileandpath[:len('.privatekey')])
          else:
            # they typed 'loadpriv foo'
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            privkeyfn = fileandpath+'.privatekey'
            keyname = os.path.basename(fileandpath)
        elif len(userinputlist)==4:
          if userinputlist[2] != 'as':
            raise UserError("Usage: loadpriv filename [as identity]")

          # they typed 'loadpriv foo.privatekey'
          if userinputlist[1].endswith('.privatekey'):
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            privkeyfn = fileandpath
          else:
            # they typed 'loadpriv foo'
            # handle '~'
            fileandpath = os.path.expanduser(userinputlist[1])
            privkeyfn = fileandpath+'.publickey'
          keyname = userinputlist[3]
        else:
          raise UserError("Usage: loadpriv filename [as identity]")

        # load the key and update the table...
        privkey = rsa_file_to_privatekey(privkeyfn)
        if keyname not in keys:
          keys[keyname] = {'privatekey':privkey, 'publickey':None}
        else:
          keys[keyname]['privatekey'] = privkey
          
          # Check the keys, on error reverse the change and re-raise
          try:
            check_key_set(keyname)
          except:
            keys[keyname]['privatekey'] = None
            raise
          
        continue




# loadkeys filename [as identity]                    -- loads a private key
      elif userinputlist[0] == 'loadkeys':
        if len(userinputlist)==2:

          # they typed 'loadpriv foo'

          # the user input may have a directory or tilde in it.   The key name 
          # shouldn't have either.
          fileandpath = os.path.expanduser(userinputlist[1])
          keyname = os.path.basename(fileandpath)
          privkeyfn = fileandpath+'.privatekey'
          pubkeyfn = fileandpath+'.publickey'


        elif len(userinputlist)==4:
          if userinputlist[2] != 'as':
            raise UserError("Usage: loadkeys filename [as identity]")

          # the user input may have a directory or tilde in it.   The key name 
          # shouldn't have either.
          fileandpath = os.path.expanduser(userinputlist[1])
          privkeyfn = fileandpath+'.privatekey'
          pubkeyfn = fileandpath+'.publickey'

          keyname = userinputlist[3]
        else:
          raise UserError("Usage: loadkeys filename [as identity]")

        # load the keys and update the table...
        privkey = rsa_file_to_privatekey(privkeyfn)
        pubkey = rsa_file_to_publickey(pubkeyfn)
        keys[keyname] = {'privatekey':privkey, 'publickey':pubkey}
        
        # Check the keys, on error reverse the change and re-raise
        try:
          check_key_set(keyname)
        except:
          del keys[keyname]
          raise
          
        continue




# list               -- Update and display information about the vessels

# output looks similar to:
#  ID Own                       Name     Status              Owner Information
#  %1  *       128.208.3.173:1224:v5      Fresh                               
#  %2  *        128.208.3.86:1224:v2      Fresh                               
#  %3          234.17.98.23:53322:v5    Stopped               Chord experiment
#
      elif userinputlist[0] == 'list':
        if len(userinputlist)>1:
          raise UserError("Usage: list")

        if not currenttarget:
          raise UserError("Must specify a target")
        
        # update information about the vessels...
        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],list_or_update_target)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Error '"+retdict[longname][1]+"' on "+longname
            faillist.append(longname)

        # and display it...
        if faillist:
          print "Failures on "+str(len(faillist))+" targets: "+", ".join(faillist)
        if goodlist:
          print "%4s %3s %25s %10s %30s" % ('ID','Own','Name','Status','Owner Information')

        # walk through target to print instead of the good list so that the
        # names are printed in order...
        for longname in targets[currenttarget]:
          if longname in goodlist:  
            if keys[currentkeyname]['publickey'] == vesselinfo[longname]['ownerkey']:
              owner = '*'
            else:
              owner = ''
            print "%4s  %1s  %25s %10s %30s" % (vesselinfo[longname]['ID'],owner,fit_string(longname,25),vesselinfo[longname]['status'],fit_string(vesselinfo[longname]['ownerinfo'],30))

        # add groups for fail and good (if there is a difference in what nodes do)
        if goodlist and faillist:
          targets['listgood'] = goodlist
          targets['listfail'] = faillist
          print "Added group 'listgood' with "+str(len(targets['listgood']))+" targets and 'listfail' with "+str(len(targets['listfail']))+" targets"


        statusdict = {}
        # add status groups (if there is a difference in vessel state)
        for longname in goodlist:
          if vesselinfo[longname]['status'] not in statusdict:
            # create a list with this element...
            statusdict[vesselinfo[longname]['status']] = []
          statusdict[vesselinfo[longname]['status']].append(longname)

        if len(statusdict) > 1:
          print "Added group",
          for statusname in statusdict:
            targets['list'+statusname] = statusdict[statusname]
            print "'"+statusname+"' with "+str(len(targets['list'+statusname]))+" targets",
          print
          
        continue
  
# reset                  -- Reset the vessel (clear the log and files and stop)
      elif userinputlist[0] == 'reset':
        if len(userinputlist)>1:
          raise UserError("Usage: reset")

        if not currenttarget:
          raise UserError("Must specify a target")
        
        # reset the vessels...
        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],reset_target)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Error '"+retdict[longname][1]+"' on "+longname
            faillist.append(longname)

        # and display it...
        if faillist:
          print "Failures on "+str(len(faillist))+" targets: "+", ".join(faillist)
        if goodlist and faillist:
          targets['resetgood'] = goodlist
          targets['resetfail'] = faillist
          print "Added group 'resetgood' with "+str(len(targets['resetgood']))+" targets and 'resetfail' with "+str(len(targets['resetfail']))+" targets"

        continue
  



# update
      elif userinputlist[0] == 'update':
        if len(userinputlist)>1:
          raise UserError("Usage: update")

        if not currenttarget:
          raise UserError("Must specify a target")
        
        # update information about the vessels...
        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],list_or_update_target)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Error '"+retdict[longname][1]+"' on "+longname
            faillist.append(longname)

        # and display it...
        if faillist:
          print "Failures on "+str(len(faillist))+" targets: "+", ".join(faillist)
        if goodlist and faillist:
          targets['updategood'] = goodlist
          targets['updatefail'] = faillist
          print "Added group 'updategood' with "+str(len(targets['updategood']))+" targets and 'updatefail' with "+str(len(targets['updatefail']))+" targets"

        continue
  




# upload localfn (remotefn)   -- Upload a file 
      elif userinputlist[0] == 'upload':
        if len(userinputlist)==2:
          # expand '~'
          fileandpath = os.path.expanduser(userinputlist[1])
          remotefn = os.path.basename(fileandpath)
          localfn = fileandpath
        elif len(userinputlist)==3:
          # expand '~'
          fileandpath = os.path.expanduser(userinputlist[1])
          localfn = fileandpath
          remotefn = userinputlist[2]
        else:
          raise UserError("Usage: upload localfn (remotefn)")

        if not currenttarget:
          raise UserError("Must specify a target")
  

        # read the local file...
        fileobj = open(localfn,"r")
        filedata = fileobj.read()
        fileobj.close()

        # add the file to the vessels...
        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],upload_target, remotefn, filedata)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Failure '"+retdict[longname][1]+"' uploading to",longname
            faillist.append(longname)

        # update the groups
        if goodlist and faillist:
          targets['uploadgood'] = goodlist
          targets['uploadfail'] = faillist
          print "Added group 'uploadgood' with "+str(len(targets['uploadgood']))+" targets and 'uploadfail' with "+str(len(targets['uploadfail']))+" targets"

  
        continue
  


# download remotefn (localfn) -- Download a file 
      elif userinputlist[0] == 'download':
        if len(userinputlist)==2:
          # handle '~'
          fileandpath = os.path.expanduser(userinputlist[1])
          remotefn = os.path.basename(fileandpath)
          localfn = fileandpath
        elif len(userinputlist)==3:
          remotefn = userinputlist[1]
          # handle '~'
          fileandpath = os.path.expanduser(userinputlist[2])
          localfn = fileandpath
        else:
          raise UserError("Usage: download localfn (remotefn)")

        if not currenttarget:
          raise UserError("Must specify a target")
  


        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],download_target,localfn,remotefn)

        writestring = ''
        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
            # for output...
            writestring = writestring + retdict[longname][1]+ " "
          else:
            print "Failure '"+retdict[longname][1]+"' downloading from",longname
            faillist.append(longname)

        if writestring:
          print "Wrote files: "+writestring

        # add groups if needed...
        if goodlist and faillist:
          targets['downloadgood'] = goodlist
          targets['downloadfail'] = faillist
          print "Added group 'downloadgood' with "+str(len(targets['downloadgood']))+" targets and 'downloadfail' with "+str(len(targets['downloadfail']))+" targets"

  
        continue
  



# delete remotefn             -- Delete a file
      elif userinputlist[0] == 'delete':
        if len(userinputlist)==2:
          remotefn = userinputlist[1]
        else:
          raise UserError("Usage: delete remotefn")

        if not currenttarget:
          raise UserError("Must specify a target")
  

        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],delete_target, remotefn)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else: 
            print "Failure '"+retdict[longname][1]+"' deleting on",longname
            faillist.append(longname)

        # add groups if needed...
        if goodlist and faillist:
          targets['deletegood'] = goodlist
          targets['deletefail'] = faillist
          print "Added group 'deletegood' with "+str(len(targets['deletegood']))+" targets and 'deletefail' with "+str(len(targets['deletefail']))+" targets"

  
        continue
  

  
# start file [args ...]  -- Start an experiment
      elif userinputlist[0] == 'start':
        if len(userinputlist)>1:
          argstring = ' '.join(userinputlist[1:])
        else:
          raise UserError("Usage: start file [args ...]")

        if not currenttarget:
          raise UserError("Must specify a target")
  
        # need to get the status, etc (or do I just try to start them all?)
        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],start_target, argstring)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Failure '"+retdict[longname][1]+"' starting ",longname
            faillist.append(longname)

        # add groups if needed...
        if goodlist and faillist:
          targets['startgood'] = goodlist
          targets['startfail'] = faillist
          print "Added group 'startgood' with "+str(len(targets['startgood']))+" targets and 'startfail' with "+str(len(targets['startfail']))+" targets"

  

# stop               -- Stop an experiment
      elif userinputlist[0] == 'stop':
        if len(userinputlist)>1:
          raise UserError("Usage: stop")

        if not currenttarget:
          raise UserError("Must specify a target")
  
        # need to get the status, etc (or do I just try to stop them all?)
        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],stop_target)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Failure '"+retdict[longname][1]+"' stopping ",longname
            faillist.append(longname)



        # add groups if needed...
        if goodlist and faillist:
          targets['stopgood'] = goodlist
          targets['stopfail'] = faillist
          print "Added group 'stopgood' with "+str(len(targets['stopgood']))+" targets and 'stopfail' with "+str(len(targets['stopfail']))+" targets"



# run file [args...]    -- Shortcut for upload a file and start
      elif userinputlist[0] == 'run':
        if len(userinputlist)>1:
          # Handle '~' in file names
          fileandpath = os.path.expanduser(userinputlist[1])
          onlyfilename = os.path.basename(fileandpath)
          argstring = " ".join([onlyfilename] + userinputlist[2:])
        else:
          raise UserError("Usage: run file [args ...]")

        if not currenttarget:
          raise UserError("Must specify a target")
  

        # read the local file...
        fileobj = open(fileandpath,"r")
        filedata = fileobj.read()
        fileobj.close()

        faillist = []
        goodlist = []

        retdict = contact_targets(targets[currenttarget],run_target,onlyfilename,filedata, argstring)

        for longname in retdict:
          if retdict[longname][0]:
            goodlist.append(longname)
          else:
            print "Failure '"+retdict[longname][1]+"' on ",longname
            faillist.append(longname)


        # update the groups
        if goodlist and faillist:
          targets['rungood'] = goodlist
          targets['runfail'] = faillist
          print "Added group 'rungood' with "+str(len(targets['rungood']))+" targets and 'runfail' with "+str(len(targets['runfail']))+" targets"

  
        continue
  





#split resourcefn            -- Split off of each vessel another vessel

      elif userinputlist[0] == 'split':
        if len(userinputlist)==2:
          # expand ~
          fileandpath = os.path.expanduser(userinputlist[1])
          resourcefn = fileandpath
        else:
          raise UserError("Usage: split resourcefn")

        if not currenttarget:
          raise UserError("Must specify a target")

        resourcefo = open(resourcefn)
        resourcedata = resourcefo.read()
        resourcefo.close() 
  

        faillist = []
        goodlist1 = []
        goodlist2 = []

        retdict = contact_targets(targets[currenttarget],split_target,resourcedata)

        for longname in retdict:
          if retdict[longname][0]:
            newname1, newname2 = retdict[longname][1]
            goodlist1.append(newname1)
            goodlist2.append(newname2)
            print longname+" -> ("+newname1+", "+newname2+")"
          else:
            print "Failure '"+retdict[longname][1]+"' splitting",longname
            faillist.append(longname)

        # update the groups
        if goodlist1 and goodlist2 and faillist:
          targets['split1'] = goodlist1
          targets['split2'] = goodlist2
          targets['splitfail'] = faillist
          print "Added group 'split1' with "+str(len(targets['split1']))+" targets, 'split2' with "+str(len(targets['split2']))+" targets and 'splitfail' with "+str(len(targets['splitfail']))+" targets"
        elif goodlist1 and goodlist2:
          targets['split1'] = goodlist1
          targets['split2'] = goodlist2
          print "Added group 'split1' with "+str(len(targets['split1']))+" targets and 'split2' with "+str(len(targets['split2']))+" targets"

  
        continue




#join                        -- Join vessels on the same node

      elif userinputlist[0] == 'join':
        if len(userinputlist)!=1:
          raise UserError("Usage: join")

        if not currenttarget:
          raise UserError("Must specify a target")

        if not currentkeyname or not keys[currentkeyname]['publickey'] or not keys[currentkeyname]['privatekey']:
          raise UserError("Must specify an identity with public and private keys...")

        nodedict = {}
        skipstring = ''
        # Need to group vessels by node...
        for longname in targets[currenttarget]:
          if keys[currentkeyname]['publickey'] != vesselinfo[longname]['ownerkey']:
            skipstring = skipstring + longname+" "
            continue

          nodename = vesselinfo[longname]['IP']+":"+str(vesselinfo[longname]['port'])
          if nodename not in nodedict:
            nodedict[nodename] = []

          nodedict[nodename].append(longname)

        # if we skip nodes, explain why
        if skipstring:
          print "Skipping "+skipstring+" because the current identity is not the owner."
          print "If you are trying to join vessels with different owners, you need"
          print "to change ownership to the same owner first"


        faillist = []
        goodlist = []

        retdict = contact_targets(nodedict.keys(),join_target,nodedict)

        for nodename in retdict:
 
          if retdict[nodename][0]:
            print retdict[nodename][1][0],"<- ("+", ".join(nodedict[nodename])+")"
            goodlist = goodlist + nodedict[nodename]
          else:
            if retdict[nodename][1]:
              print "Failure '"+retdict[nodename][1]+"' on",nodename
              faillist = faillist + nodedict[nodename]
            # Nodes that I only have one vessel on don't get added to a list...

        # update the groups
        if goodlist and faillist:
          targets['joingood'] = goodlist
          targets['joinfail'] = faillist
          print "Added group 'joingood' with "+str(len(targets['joingood']))+" targets and 'joinfail' with "+str(len(targets['joinfail']))+" targets"
        elif goodlist:
          targets['joingood'] = goodlist
          targets['joinfail'] = faillist
          print "Added group 'joingood' with "+str(len(targets['joingood']))+" targets"

  
        continue














# set                 -- Changes the state of the targets (use 'help set')
      elif userinputlist[0] == 'set':
      
  
        if len(userinputlist) == 1:
          # what do I do here?
          pass

        
# set owner identity        -- Change a vessel's owner
        elif userinputlist[1] == 'owner':
          if len(userinputlist)==3:
            newowner = userinputlist[2]
          else:
            raise UserError("Usage: set owner identity")
  
          if not currenttarget:
            raise UserError("Must specify a target")
  
          if newowner not in keys:
            raise UserError("Unknown identity: '"+newowner+"'")

          if not keys[newowner]['publickey']:
            raise UserError("No public key for '"+newowner+"'")

          faillist = []
          goodlist = []
          retdict = contact_targets(targets[currenttarget],setowner_target,newadvert)

          for longname in retdict:
            if retdict[longname][0]:
              goodlist.append(longname)
            else:
              print "Failure '"+retdict[longname][1]+"' on ",longname
              faillist.append(longname)


  
          # update the groups
          if goodlist and faillist:
            targets['ownergood'] = goodlist
            targets['ownerfail'] = faillist
            print "Added group 'ownergood' with "+str(len(targets['ownergood']))+" targets and 'ownerfail' with "+str(len(targets['ownerfail']))+" targets"
  
    
          continue
  


# set advertise [ on | off ] -- Change advertisement of vessels
        elif userinputlist[1] == 'advertise':
          if len(userinputlist)==3:
            if userinputlist[2] == 'on':
              newadvert = True
            elif userinputlist[2] == 'off':
              newadvert = False
            else:
              raise UserError("Usage: set advertise [ on | off ]")
          else:
            raise UserError("Usage: set advertise [ on | off ]")
  
          if not currenttarget:
            raise UserError("Must specify a target")
  

          faillist = []
          goodlist = []
          retdict = contact_targets(targets[currenttarget],setadvertise_target,newadvert)

          for longname in retdict:
            if retdict[longname][0]:
              goodlist.append(longname)
            else:
              print "Failure '"+retdict[longname][1]+"' on ",longname
              faillist.append(longname)


          # update the groups
          if goodlist and faillist:
            targets['advertisegood'] = goodlist
            targets['advertisefail'] = faillist
            print "Added group 'advertisegood' with "+str(len(targets['advertisegood']))+" targets and 'advertisefail' with "+str(len(targets['advertisefail']))+" targets"
  
    
          continue
  

# set ownerinfo [ data ... ]    -- Change owner information for the vessels
        elif userinputlist[1] == 'ownerinfo':
          newdata = " ".join(userinputlist[2:])
  
          if not currenttarget:
            raise UserError("Must specify a target")
  
          faillist = []
          goodlist = []
          retdict = contact_targets(targets[currenttarget],setownerinformation_target,newdata)

          for longname in retdict:
            if retdict[longname][0]:
              goodlist.append(longname)
            else:
              print "Failure '"+retdict[longname][1]+"' on ",longname
              faillist.append(longname)


          # update the groups
          if goodlist and faillist:
            targets['ownerinfogood'] = goodlist
            targets['ownerinfofail'] = faillist
            print "Added group 'ownerinfogood' with "+str(len(targets['ownerinfogood']))+" targets and 'ownerinfofail' with "+str(len(targets['ownerinfofail']))+" targets"
  
    
          continue
  

# set users [ identity ... ]  -- Change a vessel's users
        elif userinputlist[1] == 'users':
          userkeys = []

          for identity in userinputlist[2:]:
            if identity not in keys:
              raise UserError("Unknown identity: '"+identity+"'")

            if not keys[identity]['publickey']:
              raise UserError("No public key for '"+identity+"'")
          
            userkeys.append(rsa_publickey_to_string(keys[identity]['publickey']))
          # this is the format the NM expects...
          userkeystring = '|'.join(userkeys)
  
          if not currenttarget:
            raise UserError("Must specify a target")
  

          faillist = []
          goodlist = []
          retdict = contact_targets(targets[currenttarget],setusers_target,userkeystring)

          for longname in retdict:
            if retdict[longname][0]:
              goodlist.append(longname)
            else:
              print "Failure '"+retdict[longname][1]+"' on ",longname
              faillist.append(longname)
  
          # update the groups
          if goodlist and faillist:
            targets['usersgood'] = goodlist
            targets['usersfail'] = faillist
            print "Added group 'usersgood' with "+str(len(targets['usersgood']))+" targets and 'usersfail' with "+str(len(targets['usersfail']))+" targets"
  
    
          continue


# set timeout count  -- Sets the time that seash is willing to wait on a node
        elif userinputlist[1] == 'timeout':

          if len(userinputlist) != 3:
            raise UserError("set timeout takes exactly one argument")

          # I need to set the timeout for new handles...
          try:
            globalseashtimeout = int(userinputlist[2])
          except ValueError:
            raise UserError("The timeout value must be a number")

          # let's reset the timeout for existing handles...
          for longname in vesselinfo:
            thisvesselhandle = vesselinfo[longname]['handle']
            thisvesselhandledict = nmclient_get_handle_info(thisvesselhandle)
            thisvesselhandledict['timeout'] = globalseashtimeout
            nmclient_set_handle_info(thisvesselhandle,thisvesselhandledict)
    
          continue







# set ???  -- Bad command for set...
        else:

          print "Error: set command not understood, try 'help set'"

  

  
  


  
  

  
  
# else unknown
      else:
        print "Error: command not understood"
  

# handle errors
    except KeyboardInterrupt:
      # print or else their prompt will be indented
      print
      # Make sure the user understands why we exited
      print 'Exiting due to user interrupt'
      return
    except EOFError:
      # print or else their prompt will be indented
      print
      # Make sure the user understands why we exited
      print 'Exiting due to EOF (end-of-file) keystroke'
      return
    except UserError, e:
      print e
    except:
      traceback.print_exc()
      
  
  
if __name__=='__main__':
  time_updatetime(34612)
  command_loop()

